#include "Pixel.h"

// Pixel class constructor, sets all bgr values to 0 initially.
Pixel::Pixel()
{
    blue = 0;
    green = 0;
    red = 0;
}