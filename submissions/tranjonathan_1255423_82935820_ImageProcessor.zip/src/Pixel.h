#pragma once

// Pixel class info
class Pixel
{
public:
    unsigned char blue;
    unsigned char green;
    unsigned char red;
    Pixel();
};