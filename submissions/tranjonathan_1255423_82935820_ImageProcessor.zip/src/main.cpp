#include <iostream>
#include <fstream>
#include "Pixel.h"

// Header structure that holds the header data
struct Header
{
    char idLength = 0;
    char colorMapType = 0;
    char dataTypeCode = 0;
    short colorMapOrigin = 0;
    short colorMapLength = 0;
    char colorMapDepth = 0;
    short xOrigin = 0;
    short yOrigin = 0;
    short width = 0;
    short height = 0;
    char bitsPerPixel = 0;
    char imageDescriptor = 0;
};

// Loads the given file's header data into a header object
void loadHeader(const std::string &name, Header& header)
{
    std::ifstream inStream(name, std::ios::binary);

    inStream.read(reinterpret_cast<char*> (&header.idLength), sizeof(header.idLength));
    inStream.read(reinterpret_cast<char*> (&header.colorMapType), sizeof(header.colorMapType));
    inStream.read(reinterpret_cast<char*> (&header.dataTypeCode), sizeof(header.dataTypeCode));
    inStream.read(reinterpret_cast<char*> (&header.colorMapOrigin), sizeof(header.colorMapOrigin));
    inStream.read(reinterpret_cast<char*> (&header.colorMapLength), sizeof(header.colorMapLength));
    inStream.read(reinterpret_cast<char*> (&header.colorMapDepth), sizeof(header.colorMapDepth));
    inStream.read(reinterpret_cast<char*> (&header.xOrigin), sizeof(header.xOrigin));
    inStream.read(reinterpret_cast<char*> (&header.yOrigin), sizeof(header.yOrigin));
    inStream.read(reinterpret_cast<char*> (&header.width), sizeof(header.width));
    inStream.read(reinterpret_cast<char*> (&header.height), sizeof(header.height));
    inStream.read(reinterpret_cast<char*> (&header.bitsPerPixel), sizeof(header.bitsPerPixel));
    inStream.read(reinterpret_cast<char*> (&header.imageDescriptor), sizeof(header.imageDescriptor));
}

// Loads a file's pixel data into an array of pixel objects, each holding the bgr value
void loadPixels(const std::string& name, Header& header, Pixel data[])
{
    std::ifstream inStream(name, std::ios::binary);
    Pixel temp;
    int count = 0;
    for(int i = 0; i < header.width * header.height; i++)
    {
        inStream.seekg(18 + count);
        inStream.read(reinterpret_cast<char*> (&temp.blue), sizeof(unsigned char));
        inStream.seekg(18 + count + 1);
        inStream.read(reinterpret_cast<char*> (&temp.green), sizeof(unsigned char));
        inStream.seekg(18 + count + 2);
        inStream.read(reinterpret_cast<char*> (&temp.red), sizeof(unsigned char));
        data[i].blue = temp.blue;
        data[i].green = temp.green;
        data[i].red = temp.red;
        count+=3;
    }
}

// Writes out the given header and pixel data to a file of the given name
void writeHD(const std::string &name, Header& header, Pixel data[])
{
    std::ofstream outStream(name, std::ios::binary);

    outStream.write(reinterpret_cast<char*> (&header.idLength), sizeof(header.idLength));
    outStream.write(reinterpret_cast<char*> (&header.colorMapType), sizeof(header.colorMapType));
    outStream.write(reinterpret_cast<char*> (&header.dataTypeCode), sizeof(header.dataTypeCode));
    outStream.write(reinterpret_cast<char*> (&header.colorMapOrigin), sizeof(header.colorMapOrigin));
    outStream.write(reinterpret_cast<char*> (&header.colorMapLength), sizeof(header.colorMapLength));
    outStream.write(reinterpret_cast<char*> (&header.colorMapDepth), sizeof(header.colorMapDepth));
    outStream.write(reinterpret_cast<char*> (&header.xOrigin), sizeof(header.xOrigin));
    outStream.write(reinterpret_cast<char*> (&header.yOrigin), sizeof(header.yOrigin));
    outStream.write(reinterpret_cast<char*> (&header.width), sizeof(header.width));
    outStream.write(reinterpret_cast<char*> (&header.height), sizeof(header.height));
    outStream.write(reinterpret_cast<char*> (&header.bitsPerPixel), sizeof(header.bitsPerPixel));
    outStream.write(reinterpret_cast<char*> (&header.imageDescriptor), sizeof(header.imageDescriptor));

    for(int i = 0; i < header.width * header.height; i++)
    {
        outStream.write(reinterpret_cast<char*> (&data[i].blue), sizeof(unsigned char));
        outStream.write(reinterpret_cast<char*> (&data[i].green), sizeof(unsigned char));
        outStream.write(reinterpret_cast<char*> (&data[i].red), sizeof(unsigned char));
    }
}

// Multiplies two data sets
void multiplyPixels(Header &header, Pixel data[], Pixel data2[])
{
    for(int i = 0; i < header.height * header.width; i++)
    {
        data[i].blue = (data[i].blue / float(255)) * (data2[i].blue / float(255)) * float(255) + 0.5f;
        data[i].green = (data[i].green / float(255)) * (data2[i].green / float(255)) * float(255) + 0.5f;
        data[i].red = (data[i].red / float(255)) * (data2[i].red / float(255)) * float(255) + 0.5f;
    }
}

// Screens two data sets
void screenPixels(Header &header, Pixel data[], Pixel data2[])
{
    for(int i = 0; i < header.height * header.width; i++)
    {
        data2[i].blue = (1 - (1 - (data[i].blue / float(255))) * (1 - (data2[i].blue / float(255)))) * float(255) + 0.5f;
        data2[i].green = (1 - (1 - (data[i].green / float(255))) * (1 - (data2[i].green / float(255)))) * float(255) + 0.5f;
        data2[i].red = (1 - (1 - (data[i].red / float(255))) * (1 - (data2[i].red / float(255)))) * float(255) + 0.5f;
    }
}

int main() {
    // Creating all 4 header and data sets we will need.
    Header header;
    loadHeader("input/layer1.tga", header);
    auto data = new Pixel[header.width * header.height];
    loadPixels("input/layer1.tga", header, data);

    Header header2;
    loadHeader("input/pattern1.tga", header2);
    auto data2 = new Pixel[header2.width * header2.height];
    loadPixels("input/pattern1.tga", header2, data2);


    Header header3;
    loadHeader("input/circles.tga", header3);
    auto data3 = new Pixel[header3.width * header3.height];
    loadPixels("input/circles.tga", header3, data3);

    Header header4;
    loadHeader("input/circles.tga", header3);
    auto data4 = new Pixel[header3.width * header3.height];
    loadPixels("input/circles.tga", header3, data3);

    // Part 1: Multiply: Used multiply function on the data.

    multiplyPixels(header, data, data2);
    writeHD("output/part1.tga", header, data);



    // Part 2: Subtract: Subtracted second data set from first data set, capping it at a value of 0.

    loadHeader("input/car.tga", header);
    loadHeader("input/layer2.tga", header2);
    loadPixels("input/car.tga", header, data);
    loadPixels("input/layer2.tga", header2, data2);
    for(int i = 0; i < header.height * header.width; i++)
    {
        if(data[i].blue - data2[i].blue < 0)
        {
            data[i].blue = 0;
        }
        else
        {
            data[i].blue = data[i].blue - data2[i].blue;
        }
        if(data[i].green - data2[i].green < 0)
        {
            data[i].green = 0;
        }
        else
        {
            data[i].green = data[i].green - data2[i].green;
        }
        if(data[i].red - data2[i].red < 0)
        {
            data[i].red = 0;
        }
        else
        {
            data[i].red = data[i].red - data2[i].red;
        }
    }
    writeHD("output/part2.tga", header, data);



    // Part 3: Multiply and Screen: Used multiply and screen functions on the two data sets.

    loadHeader("input/layer1.tga", header);
    loadHeader("input/pattern2.tga", header2);
    loadPixels("input/layer1.tga", header, data);
    loadPixels("input/pattern2.tga", header2, data2);
    loadHeader("input/text.tga", header3);
    loadPixels("input/text.tga", header3, data3);
    multiplyPixels(header, data, data2);
    screenPixels(header, data, data3);
    writeHD("output/part3.tga", header3, data3);



    // Part 4: Multiply and Subtract: Used multiply function and then subtracted the second data set
    //         from the first data set.

    loadHeader("input/layer2.tga", header);
    loadHeader("input/circles.tga", header2);
    loadPixels("input/layer2.tga", header, data);
    loadPixels("input/circles.tga", header2, data2);
    multiplyPixels(header, data, data2);
    loadHeader("input/pattern2.tga", header2);
    loadPixels("input/pattern2.tga", header2, data2);
    for(int i = 0; i < header.height * header.width; i++)
    {
        if(data[i].blue - data2[i].blue < 0)
        {
            data[i].blue = 0;
        }
        else
        {
            data[i].blue = data[i].blue - data2[i].blue;
        }
        if(data[i].green - data2[i].green < 0)
        {
            data[i].green = 0;
        }
        else
        {
            data[i].green = data[i].green - data2[i].green;
        }
        if(data[i].red - data2[i].red < 0)
        {
            data[i].red = 0;
        }
        else
        {
            data[i].red = data[i].red - data2[i].red;
        }
    }
    writeHD("output/part4.tga", header, data);



    // Part 5: Overlay: Loaded the two data sets and then used the overlay formula to
    //                  combine the two, calling multiply or screen depending on the
    //                  greyness of the pixel.

    loadHeader("input/layer1.tga", header);
    loadHeader("input/pattern1.tga", header2);
    loadPixels("input/layer1.tga", header, data);
    loadPixels("input/pattern1.tga", header2, data2);
    for(int i = 0; i < header.height * header.width; i++)
    {
        if((data2[i].blue + data2[i].green + data2[i].red) / 3 < 128)
        {
            data[i].blue = 2 * ((data[i].blue / float(255)) * (data2[i].blue / float(255)) * float(255) + 0.25f);
            data[i].green = 2 * ((data[i].green / float(255)) * (data2[i].green / float(255)) * float(255) + 0.25f);
            data[i].red = 2 * ((data[i].red / float(255)) * (data2[i].red / float(255)) * float(255) + 0.25f);
        }
        else
        {
            data[i].blue = ((1 - 2*(1 - (data[i].blue / float(255))) * (1 - (data2[i].blue / float(255)))) * float(255) + 0.5f);
            data[i].green = ((1 - 2*(1 - (data[i].green / float(255))) * (1 - (data2[i].green / float(255)))) * float(255) + 0.5f);
            data[i].red = ((1 - 2*(1 - (data[i].red / float(255))) * (1 - (data2[i].red / float(255)))) * float(255) + 0.5f);
        }
    }
    writeHD("output/part5.tga", header, data);



    // Part 6: Added 200 points of green to each pixel, capping it at 255.

    loadHeader("input/car.tga", header);
    loadPixels("input/car.tga", header, data);
    for(int i = 0; i < header.height * header.width; i++)
    {
        if(data[i].green + 200 > 255)
        {
            data[i].green = 255;
        }
        else
        {
            data[i].green += 200;
        }
    }
    writeHD("output/part6.tga", header, data);



    // Part 7: Multiplied the redness of each pixel by 4 and the blueness by 0.

    loadHeader("input/car.tga", header);
    loadPixels("input/car.tga", header, data);
    for(int i = 0; i < header.height * header.width; i++)
    {
        if(data[i].red * 4 > 255)
        {
            data[i].red = 255;
        }
        else
        {
            data[i].red *= 4;
        }
        data[i].blue = 0;
    }
    writeHD("output/part7.tga", header, data);



    // Part 8: Separated each channel of the car file into a different data set.

    loadHeader("input/car.tga", header);
    loadPixels("input/car.tga", header, data);
    loadHeader("input/car.tga", header2);
    loadPixels("input/car.tga", header2, data2);
    for(int i = 0; i < header.height * header.width; i++)
    {
        data2[i].blue = data[i].blue;
        data2[i].green = data[i].blue;
        data2[i].red = data[i].blue;
    }
    writeHD("output/part8_b.tga", header2, data2);
    for(int i = 0; i < header.height * header.width; i++)
    {
        data2[i].blue = data[i].green;
        data2[i].green = data[i].green;
        data2[i].red = data[i].green;
    }
    writeHD("output/part8_g.tga", header2, data2);
    for(int i = 0; i < header.height * header.width; i++)
    {
        data2[i].blue = data[i].red;
        data2[i].green = data[i].red;
        data2[i].red = data[i].red;
    }
    writeHD("output/part8_r.tga", header2, data2);



    // Part 9: Loaded the three data sets, and then made the red and green values
    //         of the blue data set match the ones from the red and green.

    loadHeader("input/layer_blue.tga", header);
    loadPixels("input/layer_blue.tga", header, data);
    loadHeader("input/layer_green.tga", header2);
    loadPixels("input/layer_green.tga", header2, data2);
    loadHeader("input/layer_red.tga", header3);
    loadPixels("input/layer_red.tga", header3, data3);
    for(int i = 0; i < header.height * header.width; i++)
    {
        data[i].red = data3[i].red;
        data[i].green = data2[i].green;
    }
    writeHD("output/part9.tga", header, data);


    // Part 10: Flipped the image 180 degrees by printing the data out backwards.

    loadHeader("input/text2.tga", header);
    loadPixels("input/text2.tga", header, data);
    loadHeader("input/text2.tga", header2);
    loadPixels("input/text2.tga", header2, data2);
    int temp = header.width * header.height - 1;
    for(int i = 0; i < header.width * header.height; i++)
    {
        data2[i].blue = data[temp].blue;
        data2[i].green = data[temp].green;
        data2[i].red = data[temp].red;
        temp--;
    }
    writeHD("output/part10.tga", header2, data2);

    // Extra Credit: Combined all four images into one by writing out the header with the
    //               width and height multiplied by 2, and writing each file's pixel data
    //               in by row to make it look like the example.

    loadHeader("input/car.tga", header);
    loadPixels("input/car.tga", header, data);
    loadHeader("input/circles.tga", header2);
    loadPixels("input/circles.tga", header2, data2);
    loadHeader("input/pattern1.tga", header3);
    loadPixels("input/pattern1.tga", header3, data3);
    loadHeader("input/text.tga", header4);
    loadPixels("input/text.tga", header4, data4);


    std::ofstream outStream("output/extracredit.tga", std::ios::binary);

    header.width *= 2;
    header.height *= 2;
    outStream.write(reinterpret_cast<char*> (&header.idLength), sizeof(header.idLength));
    outStream.write(reinterpret_cast<char*> (&header.colorMapType), sizeof(header.colorMapType));
    outStream.write(reinterpret_cast<char*> (&header.dataTypeCode), sizeof(header.dataTypeCode));
    outStream.write(reinterpret_cast<char*> (&header.colorMapOrigin), sizeof(header.colorMapOrigin));
    outStream.write(reinterpret_cast<char*> (&header.colorMapLength), sizeof(header.colorMapLength));
    outStream.write(reinterpret_cast<char*> (&header.colorMapDepth), sizeof(header.colorMapDepth));
    outStream.write(reinterpret_cast<char*> (&header.xOrigin), sizeof(header.xOrigin));
    outStream.write(reinterpret_cast<char*> (&header.yOrigin), sizeof(header.yOrigin));
    outStream.write(reinterpret_cast<char*> (&header.width), sizeof(header.width));
    outStream.write(reinterpret_cast<char*> (&header.height), sizeof(header.height));
    outStream.write(reinterpret_cast<char*> (&header.bitsPerPixel), sizeof(header.bitsPerPixel));
    outStream.write(reinterpret_cast<char*> (&header.imageDescriptor), sizeof(header.imageDescriptor));

    int count = 0;
    int count2 = 0;
    int count3 = 0;
    int count4 = 0;
    for(int i = 0; i < header2.height; i++)
    {
        for(int j = 0; j < header2.width; j++)
        {
            outStream.write(reinterpret_cast<char*> (&data4[count3].blue), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data4[count3].green), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data4[count3].red), sizeof(unsigned char));
            count3++;
        }
        for(int k = 0; k < header2.width; k++)
        {
            outStream.write(reinterpret_cast<char*> (&data3[count4].blue), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data3[count4].green), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data3[count4].red), sizeof(unsigned char));
            count4++;
        }
    }
    for(int i = 0; i < header2.height; i++)
    {
        for(int j = 0; j < header2.width; j++)
        {
            outStream.write(reinterpret_cast<char*> (&data[count].blue), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data[count].green), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data[count].red), sizeof(unsigned char));
            count++;
        }
        for(int k = 0; k < header2.width; k++)
        {
            outStream.write(reinterpret_cast<char*> (&data2[count2].blue), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data2[count2].green), sizeof(unsigned char));
            outStream.write(reinterpret_cast<char*> (&data2[count2].red), sizeof(unsigned char));
            count2++;
        }
    }

    // Deleting all dynamically allocated memory.
    delete[] data;
    delete[] data2;
    delete[] data3;
    delete[] data4;
    return 0;
}