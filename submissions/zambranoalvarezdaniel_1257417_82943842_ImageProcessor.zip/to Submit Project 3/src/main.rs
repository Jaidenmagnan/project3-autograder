use std::fs;
use std::fs::File;
use std::io::{BufReader, Read};
use std::io::Write;
use std::io::{self};

fn multiply(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8>    //returns a vector that is the result of multiplying the parameters
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_channel_count: usize = top_layer.len();
    for i in 0..pixel_channel_count
    {
        let index: usize = i as usize;
        let current_top_pixel: f32 = top_layer[index] as f32;
        let current_bottom_pixel: f32 = bottom_layer[index] as f32;
        let mut new_pixel: f32 = current_top_pixel * current_bottom_pixel / 255.0;
        new_pixel += 0.5;    //rounding up
        result.push(new_pixel as u8);    //when casting, rust automatically rounds to max value or min value if the value surpasses the capabilities of u8
    }

    return result;
}

fn screen(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8>    //returns a vector of the screened image data
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_channel_count: usize = top_layer.len();
    for i in 0..pixel_channel_count
    {
        let index: usize = i as usize;
        let current_top_pixel_standardized: f32 = top_layer[index] as f32 / 255.0;
        let current_bottom_pixel_standardized: f32 = bottom_layer[index] as f32 / 255.0;
        let mut new_pixel: f32 = 1.0 - (1.0 - current_top_pixel_standardized) * (1.0 - current_bottom_pixel_standardized);    //calculations done with standardized values
        new_pixel *= 255.0;    //returning value to char representation
        new_pixel += 0.5;    //rounding up
        result.push(new_pixel as u8);
    }

    return result
}

fn subtract(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8>    //returns a vector of the subtracted image data; result pixels = bottom layer pixels - top layer pixels; subtracts top layer FROM bottom layer
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_channel_count : usize = top_layer.len();
    for i in 0..pixel_channel_count
    {
        let current_top_pixel : i32 = top_layer[i] as i32;
        let current_bottom_pixel : i32 = bottom_layer[i] as i32;
        let mut new_pixel:i32 = current_bottom_pixel - current_top_pixel;
        if new_pixel < 0  //explicitly rounding to zero just in case rust tries to write a negative number
        {
            new_pixel = 0;
        }
        result.push(new_pixel as u8);
    }

    return result;    
}

fn rotatate180(image_data : &Vec<u8>) -> Vec<u8>    //returns the given image rotated 180 degrees
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_count:usize = image_data.len() / 3;
    for i in 0..pixel_count
    {
        let blue_to_add: u8 = image_data[pixel_count * 3 - i * 3 - 2 - 1];
        let green_to_add: u8 = image_data[pixel_count * 3 - i * 3 - 1 - 1];
        let red_to_add: u8 = image_data[pixel_count * 3 - i * 3 - 1];
        result.push(blue_to_add);
        result.push(green_to_add);
        result.push(red_to_add);
    }

    return result;
}

fn change(image_data : &mut Vec<u8>, operator : char, channel : char,  factor : i32)    //mutates given data, can scale or add (subtract) values from channel
{
    let mut channel_factor: usize = 0;
    let pixel_channel_count: usize = image_data.len();
    if channel == 'G'    //creates offset so that for loop iterates through correct pixel color
    {
        channel_factor = 1;
    }
    else if channel == 'R'
    {
        channel_factor = 2;
    }
    if operator == '+'
    {
        for i in (channel_factor..pixel_channel_count).step_by(3)
        {
            let mut current_pixel: i32 = image_data[i] as i32;
            current_pixel += factor;
            if current_pixel < 0
            {
                current_pixel = 0;
            }
            else if current_pixel > 255
            {
                current_pixel = 255;
            }
            image_data[i] = current_pixel as u8;
        }
    }
    else if operator == '*'
    {
        for i in (channel_factor..pixel_channel_count).step_by(3)
        {
            let mut current_pixel: i32 = image_data[i] as i32;
            current_pixel *= factor;
            if current_pixel < 0
            {
                current_pixel = 0;
            }
            else if current_pixel > 255
            {
                current_pixel = 255;
            }
            image_data[i] = current_pixel as u8;
        }
    }
}

fn overlay(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8>    //returns the result of the overlay blending method between the two layers
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_channel_count : usize = top_layer.len();
    for i in 0..pixel_channel_count
    {
        let current_top_pixel_standardized: f32 = top_layer[i] as f32 / 255.0;
        let current_bottom_pixel_standardized: f32 = bottom_layer[i] as f32 / 255.0;
        if current_bottom_pixel_standardized <= 0.5
        {
            let mut new_pixel: f32 = 2.0 * current_top_pixel_standardized * current_bottom_pixel_standardized;
            new_pixel *= 255.0;    //returning value to char representation
            new_pixel += 0.5;    //rounding up
            result.push(new_pixel as u8);
        }
        else 
        {
            let mut new_pixel: f32 = 1.0 - 2.0 * (1.0-current_top_pixel_standardized) * (1.0-current_bottom_pixel_standardized);    //calculations done with standardized values
            new_pixel *= 255.0;    //returning value to char representation
            new_pixel += 0.5;    //rounding up
            result.push(new_pixel as u8);
        }
    }
    
    return result;
}

fn channel_separate_red(image_data : &Vec<u8>) -> Vec<u8>    //returns just the red channel of an image
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_count:usize = image_data.len() / 3;
    for i in 0..pixel_count
    {
        let red_pixel_to_add: u8 = image_data[i * 3 + 2];
        result.push(red_pixel_to_add);
        result.push(red_pixel_to_add);
        result.push(red_pixel_to_add);
    }

    return result;
}

fn channel_separate_green(image_data : &Vec<u8>) -> Vec<u8>    //returns just the green channel of an image
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_count:usize = image_data.len() / 3;
    for i in 0..pixel_count
    {
        let green_pixel_to_add: u8 = image_data[i * 3 + 1];
        result.push(green_pixel_to_add);
        result.push(green_pixel_to_add);
        result.push(green_pixel_to_add);
    }

    return result;
}

fn channel_separate_blue(image_data : &Vec<u8>) -> Vec<u8>    //returns just the blue channel of an image
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_count:usize = image_data.len() / 3;
    for i in 0..pixel_count
    {
        let blue_pixel_to_add: u8 = image_data[i * 3];
        result.push(blue_pixel_to_add);
        result.push(blue_pixel_to_add);
        result.push(blue_pixel_to_add);
    }

    return result;
}

fn channel_combine(blue_image_data : &Vec<u8>, green_image_data : &Vec<u8>, red_image_data: &Vec<u8>) -> Vec<u8>    //combines the BGR channel data from 3 images into 1
{
    let mut result : Vec<u8> = Vec::new();
    let pixel_count:usize = blue_image_data.len() / 3;
    for i in 0..pixel_count
    {
        let blue_pixel_to_add: u8 = blue_image_data[i * 3];
        let green_pixel_to_add: u8 = green_image_data[i * 3 + 1];
        let red_pixel_to_add: u8 = red_image_data[i * 3 + 2];

        result.push(blue_pixel_to_add);
        result.push(green_pixel_to_add);
        result.push(red_pixel_to_add);
    }

    return result;
}

fn extra_credit_image_combine(bottom_left_image_data: &Vec<u8>, bottom_right_image_data : &Vec<u8>, top_left_image_data : &Vec<u8>, top_right_image_data : &Vec<u8>, old_width : usize, old_height: usize) -> Vec<u8>    //combines 4 images into 1 larger one
{
    let row_length: usize = old_width * 3;
    let mut result : Vec<u8> = Vec::with_capacity(old_height * old_width * 3 * 2);
    
    for row in 0..old_height 
    {
        let start_index: usize = row * row_length;
        let end_index: usize = start_index + row_length;
        
        result.extend_from_slice(&bottom_left_image_data[start_index..end_index]);
        result.extend_from_slice(&bottom_right_image_data[start_index..end_index]);
    }

    for row in 0..old_height 
    {
        let start_index: usize = row * row_length;
        let end_index: usize = start_index + row_length;
        
        result.extend_from_slice(&top_left_image_data[start_index..end_index]);
        result.extend_from_slice(&top_right_image_data[start_index..end_index]);
    }

    return result;
}

fn write_data_to_file(path: &str, header_vector: &Vec<u8>, data_vector: &Vec<u8>) -> Result<(), Box<dyn std::error::Error>>    //writes that header and image data to a given file
{
    let mut file: File = fs::OpenOptions::new().create(true).append(true).open(&path).expect("failed");

    file.write_all(&header_vector)?;
    file.write_all(&data_vector)?;

   Ok(())
}

fn read_file(path: &str, header_vector: &mut Vec<u8>, data_vector: &mut Vec<u8>) -> Result<(), Box<dyn std::error::Error>>    //writes image header and data values into the given vectors from the given file
{   
    let file: File = File::open(&path)?;
    let reader: BufReader<File> = BufReader::new(file);
    let mut counter: i32 = 0;
    for byte in reader.bytes()
    {
        if counter == 18    //when done reading header, write to image data vector
        {
            match byte
            {
                Ok(b) => 
                {
                    data_vector.push(b);
                }
                Err(err) => 
                {
                    eprintln!("Error reading byte: {}", err);
                }
            }
        }
        else 
        {
            match byte
            {
                Ok(b) => 
                {
                    header_vector.push(b);
                    counter += 1;
                }
                Err(err) => 
                {
                    eprintln!("Error reading byte: {}", err);
                }
            }
        }
    }
    Ok(())
}

fn are_files_equal(path1 : &str, path2 : &str) -> io::Result<bool>    //checks if two files are equal
{
    let mut file1: File = File::open(path1)?;
    let mut file2: File = File::open(path2)?;

    let mut file1_data: Vec<u8> = Vec::new();
    let mut file2_data: Vec<u8> = Vec::new();

    file1.read_to_end(&mut file1_data)?;
    file2.read_to_end(&mut file2_data)?;

    Ok(file1_data == file2_data)
}

fn main() -> Result<(), Box<dyn std::error::Error>>
{       
    //task1
    {
        let mut layer1_header: Vec<u8> = Vec::new();
        let mut layer1_data: Vec<u8> = Vec::new();
        read_file("input/layer1.tga", &mut layer1_header, &mut layer1_data)?;

        let mut pattern1_header: Vec<u8> = Vec::new();
        let mut pattern1_data: Vec<u8> = Vec::new();
        read_file("input/pattern1.tga", &mut pattern1_header, &mut pattern1_data)?;

        let new_image_data : Vec<u8> = multiply(&layer1_data, &pattern1_data);
        write_data_to_file("output/part1.tga", &layer1_header, &new_image_data)?;
    }
    
    //task2
    {
        let mut layer2_header: Vec<u8> = Vec::new();
        let mut layer2_data: Vec<u8> = Vec::new();
        read_file("input/layer2.tga", &mut layer2_header, &mut layer2_data)?;

        let mut car_header: Vec<u8> = Vec::new();
        let mut car_data: Vec<u8> = Vec::new();
        read_file("input/car.tga", &mut car_header, &mut car_data)?;

        let new_image_data : Vec<u8> = subtract(&layer2_data, &car_data);
        write_data_to_file("output/part2.tga", &layer2_header, &new_image_data)?;
    }

    //task3
    {
        let mut layer1_header: Vec<u8> = Vec::new();
        let mut layer1_data: Vec<u8> = Vec::new();
        read_file("input/layer1.tga", &mut layer1_header, &mut layer1_data)?;

        let mut pattern2_header: Vec<u8> = Vec::new();
        let mut pattern2_data: Vec<u8> = Vec::new();
        read_file("input/pattern2.tga", &mut pattern2_header, &mut pattern2_data)?;

        let temporary_new_image_data: Vec<u8> = multiply(&layer1_data, &pattern2_data);

        let mut text_header: Vec<u8> = Vec::new();
        let mut text_data: Vec<u8> = Vec::new();
        read_file("input/text.tga", &mut text_header, &mut text_data)?;

        let final_new_image_data: Vec<u8> = screen(&text_data, &temporary_new_image_data);

        write_data_to_file("output/part3.tga", &layer1_header, &final_new_image_data)?;
    }

    //task4
    {
        let mut layer2_header: Vec<u8> = Vec::new();
        let mut layer2_data: Vec<u8> = Vec::new();
        read_file("input/layer2.tga", &mut layer2_header, &mut layer2_data)?;

        let mut circles_header: Vec<u8> = Vec::new();
        let mut circles_data: Vec<u8> = Vec::new();
        read_file("input/circles.tga", &mut circles_header, &mut circles_data)?;

        let temporary_new_image_data: Vec<u8> = multiply(&layer2_data, &circles_data);

        let mut pattern2_header: Vec<u8> = Vec::new();
        let mut pattern2_data: Vec<u8> = Vec::new();
        read_file("input/pattern2.tga", &mut pattern2_header, &mut pattern2_data)?;

        let final_image_data: Vec<u8> = subtract(&pattern2_data, &temporary_new_image_data);
        write_data_to_file("output/part4.tga", &layer2_header, &final_image_data)?;
    }

    //task5
    {
        let mut layer1_header: Vec<u8> = Vec::new();
        let mut layer1_data: Vec<u8> = Vec::new();
        read_file("input/layer1.tga", &mut layer1_header, &mut layer1_data)?;

        let mut pattern1_header: Vec<u8> = Vec::new();
        let mut pattern1_data: Vec<u8> = Vec::new();
        read_file("input/pattern1.tga", &mut pattern1_header, &mut pattern1_data)?;

        let new_image_data: Vec<u8> = overlay(&layer1_data, &pattern1_data);
        write_data_to_file("output/part5.tga", &layer1_header, &new_image_data)?;
    }
    
    //task6
    {
        let mut car_header: Vec<u8> = Vec::new();
        let mut car_data: Vec<u8> = Vec::new();
        read_file("input/car.tga", &mut car_header, &mut car_data)?;

        change(&mut car_data, '+', 'G', 200);

        write_data_to_file("output/part6.tga", &car_header, &car_data)?;
    }

    //task7
    {
        let mut car_header: Vec<u8> = Vec::new();
        let mut car_data: Vec<u8> = Vec::new();
        read_file("input/car.tga", &mut car_header, &mut car_data)?;

        change(&mut car_data, '*', 'R', 4);
        change(&mut car_data, '*', 'B', 0);

        write_data_to_file("output/part7.tga", &car_header, &car_data)?;
    }

    //task8
    {
        let mut car_header: Vec<u8> = Vec::new();
        let mut car_data: Vec<u8> = Vec::new();
        read_file("input/car.tga", &mut car_header, &mut car_data)?;

        let car_blue_data: Vec<u8> = channel_separate_blue(&car_data);
        let car_green_data: Vec<u8> = channel_separate_green(&car_data);
        let car_red_data: Vec<u8> = channel_separate_red(&car_data);
    
        write_data_to_file("output/part8_b.tga", &car_header, &car_blue_data)?;
        write_data_to_file("output/part8_g.tga", &car_header, &car_green_data)?;
        write_data_to_file("output/part8_r.tga", &car_header, &car_red_data)?;
    }

    //task9
    {
        let mut layer_blue_header: Vec<u8> = Vec::new();
        let mut layer_blue_data: Vec<u8> = Vec::new();
        read_file("input/layer_blue.tga", &mut layer_blue_header, &mut layer_blue_data)?;

        let mut layer_green_header: Vec<u8> = Vec::new();
        let mut layer_green_data: Vec<u8> = Vec::new();
        read_file("input/layer_green.tga", &mut layer_green_header, &mut layer_green_data)?;

        let mut layer_red_header: Vec<u8> = Vec::new();
        let mut layer_red_data: Vec<u8> = Vec::new();
        read_file("input/layer_red.tga", &mut layer_red_header, &mut layer_red_data)?;

        let new_image_data: Vec<u8> = channel_combine(&layer_blue_data, &layer_green_data, &layer_red_data);
        write_data_to_file("output/part9.tga", &layer_blue_header, &new_image_data)?;
    }

    //task10
    {
        let mut text2_header: Vec<u8> = Vec::new();
        let mut text2_data: Vec<u8> = Vec::new();
        read_file("input/text2.tga", &mut text2_header, &mut text2_data)?;

        let new_image_data: Vec<u8> = rotatate180(&text2_data);
        write_data_to_file("output/part10.tga", &text2_header, &new_image_data)?;
    }

    //extra credit task
    {
        let mut car_header: Vec<u8> = Vec::new();
        let mut car_data: Vec<u8> = Vec::new();
        read_file("input/car.tga", &mut car_header, &mut car_data)?;

        let mut circles_header: Vec<u8> = Vec::new();
        let mut circles_data: Vec<u8> = Vec::new();
        read_file("input/circles.tga", &mut circles_header, &mut circles_data)?;

        let mut pattern1_header: Vec<u8> = Vec::new();
        let mut pattern1_data: Vec<u8> = Vec::new();
        read_file("input/pattern1.tga", &mut pattern1_header, &mut pattern1_data)?;

        let mut text_header: Vec<u8> = Vec::new();
        let mut text_data: Vec<u8> = Vec::new();
        read_file("input/text.tga", &mut text_header, &mut text_data)?;

        let new_image_data: Vec<u8> = extra_credit_image_combine(&text_data, &pattern1_data, &car_data, &circles_data, 512, 512);

        car_header[13] = 4 as u8;
        car_header[15] = 4 as u8;
        
        write_data_to_file("output/extracredit.tga", &car_header, &new_image_data)?;
    }

    //test check
    {
        match are_files_equal("output/part1.tga", "examples/EXAMPLE_part1.tga") 
        {
            Ok(true) => println!("Test 1 passed!"),
            Ok(false) => println!("Test 1 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part2.tga", "examples/EXAMPLE_part2.tga") 
        {
            Ok(true) => println!("Test 2 passed!"),
            Ok(false) => println!("Test 2 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part3.tga", "examples/EXAMPLE_part3.tga") 
        {
            Ok(true) => println!("Test 3 passed!"),
            Ok(false) => println!("Test 3 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part4.tga", "examples/EXAMPLE_part4.tga") 
        {
            Ok(true) => println!("Test 4 passed!"),
            Ok(false) => println!("Test 4 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part5.tga", "examples/EXAMPLE_part5.tga") 
        {
            Ok(true) => println!("Test 5 passed!"),
            Ok(false) => println!("Test 5 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part6.tga", "examples/EXAMPLE_part6.tga") 
        {
            Ok(true) => println!("Test 6 passed!"),
            Ok(false) => println!("Test 6 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part7.tga", "examples/EXAMPLE_part7.tga") 
        {
            Ok(true) => println!("Test 7 passed!"),
            Ok(false) => println!("Test 7 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

            let compare_files: [(&str, &str); 3] = [
        ("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga"), 
        ("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga"), 
        ("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga")];

        let mut success = false;
        for &(file1, file2) in &compare_files {
            match are_files_equal(file1, file2) {
                Ok(true) => success = true,
                Ok(false) => success = false,
                Err(e) => eprintln!("Error: {}", e),
            }
        }

        if success == true {
            println!("Test 8 passed!")
        } else {
            println!("Test 8 failed.")
        }

        match are_files_equal("output/part9.tga", "examples/EXAMPLE_part9.tga") 
        {
            Ok(true) => println!("Test 9 passed!"),
            Ok(false) => println!("Test 9 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/part10.tga", "examples/EXAMPLE_part10.tga") 
        {
            Ok(true) => println!("Test 10 passed!"),
            Ok(false) => println!("Test 10 failed."),
            Err(e) => eprintln!("Error: {}", e),
        }

        match are_files_equal("output/extracredit.tga", "examples/EXAMPLE_extracredit.tga") 
        {
            Ok(true) => println!("Extra Credit passed!"),
            Ok(false) => println!("Extra Credit failed."),
            Err(e) => eprintln!("Error: {}", e),
        }
    }
    Ok(())
}