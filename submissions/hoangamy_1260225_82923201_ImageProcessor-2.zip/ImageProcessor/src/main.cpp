#include <iostream>
#include <fstream>
#include "TGA.h"

int main() {

    std::cout << "Program Start" << std::endl;


    //Multiply blending mode to combine “layer1.tga” (top layer) with “pattern1.tga” (bottom)
    //objects for convenience
    TGA imageOne = TGA();
    TGA imageTwo = TGA();
    TGA imageThree = TGA();


    //loads in the objects
    imageOne.loadFile("input/layer1.tga");
    imageTwo.loadFile("input/pattern1.tga");
    imageThree.loadHeader("input/layer1.tga");

    //performs multiply blending mode and writes the file
    imageThree.multiplyImage(imageOne, imageTwo);

    //tests the TGA file to the example
    //imageThree.compareImages("examples/EXAMPLE_part1.tga");

    imageThree.writeFile("output/part1.tga");


    // Subtract blending mode to combine “layer2.tga” (top layer) with “car.tga” (bottom layer
    //objects for convenience
    TGA subtractFile1 = TGA();
    TGA subtractFile2= TGA();
    TGA subtractFile3 = TGA();

    //loads in the objects
    subtractFile1.loadFile("input/layer2.tga");
    subtractFile2.loadFile("input/car.tga");
    subtractFile3.loadHeader("input/layer2.tga");

    //performs subtract blending mode and writes the file
    subtractFile3.subtractImage(subtractFile1, subtractFile2);

    //tests the TGA file to the example
    //subtractFile3.compareImages("examples/EXAMPLE_part2.tga");

    subtractFile3.writeFile("output/part2.tga");


    //Multiply blending mode to combine “layer1.tga” with “pattern2.tga”, and store the
    //results temporarily. Load the image “text.tga” and, using that as the top layer, combine it with
    //the previous results of layer1/pattern2 using the Screen blending mode
    //objects for convenience
    TGA screenFile1 = TGA();
    TGA screenFile2 = TGA();
    TGA screenFile3 = TGA();
    TGA screenFile4 = TGA();
    TGA screenFile5 = TGA();

    //loads in the objects
    screenFile1.loadFile("input/layer1.tga");
    screenFile2.loadFile("input/pattern2.tga");
    screenFile3.loadHeader("input/layer1.tga");
    screenFile4.loadFile("input/text.tga");
    screenFile5.loadHeader("input/layer1.tga");

    //performs multiply and screen blending modes and writes the file
    screenFile3.multiplyImage(screenFile1, screenFile2);
    screenFile5.screenImage(screenFile3, screenFile4);

    //tests the TGA file to the example
    //screenFile5.compareImages("examples/EXAMPLE_part3.tga");

    screenFile5.writeFile("output/part3.tga");

    //Multiply “layer2.tga” with “circles.tga”, and store it. Load “pattern2.tga” and, using that as the
    //top layer, combine it with the previous result using the Subtract blending mode.
    //objects for convenience
    TGA multiSubtractFile1 = TGA();
    TGA multiSubtractFile2 = TGA();
    TGA multiSubtractFile3 = TGA();
    TGA multiSubtractFile4 = TGA();
    TGA multiSubtractFile5 = TGA();

    //loads in the objects
    multiSubtractFile1.loadFile("input/layer2.tga");
    multiSubtractFile2.loadFile("input/circles.tga");
    multiSubtractFile3.loadHeader("input/layer2.tga");
    multiSubtractFile4.loadFile("input/pattern2.tga");
    multiSubtractFile5.loadHeader("input/layer2.tga");

    //performs multiply and subtract blending modes and writes the file
    multiSubtractFile3.multiplyImage(multiSubtractFile1, multiSubtractFile2);
    multiSubtractFile5.subtractImage(multiSubtractFile4, multiSubtractFile3);

    //tests the TGA file to the example
    //multiSubtractFile5.compareImages("examples/EXAMPLE_part4.tga");

    multiSubtractFile5.writeFile("output/part4.tga");


    //Combine “layer1.tga” (as the top layer) with “pattern1.tga” using the Overlay blending mode.
    //objects for convenience
    TGA overlayFile1;
    TGA overlayFile2;
    TGA overlayFile3;

    //loads in the objects
    overlayFile1.loadFile("input/layer1.tga");
    overlayFile2.loadFile("input/pattern1.tga");
    overlayFile3.loadHeader("input/layer1.tga");

    //performs overlay blending mode and writes the file
    overlayFile3.overlayImage(overlayFile2, overlayFile1);

    //tests the TGA file to the example
    //overlayFile3.compareImages("examples/EXAMPLE_part5.tga");

    overlayFile3.writeFile("output/part5.tga");

    //Load “car.tga” and add 200 to the green channel
    //objects for convenience
    TGA greenChannelAdd;
    TGA greenChannelAdd2;

    //loads in the objects
    greenChannelAdd.loadFile("input/car.tga");
    greenChannelAdd2.loadHeader("input/car.tga");

    //added 200 to the green channel of the image and writes the file
    greenChannelAdd2.channelAdd(greenChannelAdd, 0, 200, 0);

    //tests the TGA file to the example
    //greenChannelAdd2.compareImages("examples/EXAMPLE_part6.tga");

    greenChannelAdd2.writeFile("output/part6.tga");


    //Load “car.tga” and scale (multiply) the red channel by 4, and the blue channel by 0. This will
    //increase the intensity of any red in the image, while negating any blue it may have.
    //objects for convenience
    TGA rbChannelScale1;
    TGA rbChannelScale2;

    //loads in the objects
    rbChannelScale1.loadFile("input/car.tga");
    rbChannelScale2.loadHeader("input/car.tga");

    //scales the red channel by 5, green by 1, and blue by 0; then writes the file
    rbChannelScale2.channelScale(rbChannelScale1, 0, 1, 4);

    //tests the TGA file to the example
    //rbChannelScale2.compareImages("examples/EXAMPLE_part7.tga");

    rbChannelScale2.writeFile("output/part7.tga");


    //Load “car.tga” and write each channel to a separate file: the red channel should be “part8_r.tga”,
    //the green channel should be “part8_g.tga”, and the blue channel should be “part8_b.tga”
    //objects for convenience
    TGA seperateChannels1;
    TGA seperateChannelsBlue;
    TGA seperateChannelsGreen;
    TGA seperateChannelsRed;

    //loads in the objects
    seperateChannels1.loadFile("input/car.tga");
    seperateChannelsBlue.loadHeader("input/car.tga");
    seperateChannelsGreen.loadHeader("input/car.tga");
    seperateChannelsRed.loadHeader("input/car.tga");

    //seperates the channels of the car.tga and puts them into seperate TGA objects
    seperateChannels1.channelSeperate(seperateChannelsBlue, seperateChannelsGreen, seperateChannelsRed);

    //tests the TGA file to the example
    //seperateChannelsBlue.compareImages("examples/EXAMPLE_part8_b.tga");
    //seperateChannelsGreen.compareImages("examples/EXAMPLE_part8_g.tga");
    //seperateChannelsRed.compareImages("examples/EXAMPLE_part8_r.tga");

    //writes the files
    seperateChannelsBlue.writeFile("output/part8_b.tga");
    seperateChannelsGreen.writeFile("output/part8_g.tga");
    seperateChannelsRed.writeFile("output/part8_r.tga");


    //Load “layer_red.tga”, “layer_green.tga” and “layer_blue.tga”, and combine the three files into
    //one file. The data from “layer_red.tga” is the red channel of the new image, layer_green is
    //green, and layer_blue is blue.
    //objects for convenience
    TGA combinedFile;
    TGA combineChannelsBlue;
    TGA combineChannelsGreen;
    TGA combineChannelsRed;

    //loads in the objects
    combinedFile.loadHeader("input/layer_blue.tga");
    combineChannelsBlue.loadFile("input/layer_blue.tga");
    combineChannelsGreen.loadFile("input/layer_green.tga");
    combineChannelsRed.loadFile("input/layer_red.tga");

    //combines the red, green, and blue channel files into one
    combinedFile.channelCombination(combineChannelsBlue, combineChannelsGreen, combineChannelsRed);

    //tests the TGA file to the example
    //combinedFile.compareImages("examples/EXAMPLE_part9.tga");

    //writes file
    combinedFile.writeFile("output/part9.tga");

    //variables for convenience
    TGA flipFile1;
    TGA flipFile2;

    //loads the files, flipFile1 has the original image, flipFile2 will just load the header
    //and have an empty imageData array
    flipFile1.loadFile("input/text2.tga");
    flipFile2.loadHeader("input/text2.tga");

    //flips flipFile1 and stores it in flipFile2
    flipFile2.flipOneEighty(flipFile1);

    //flipFile2.compareImages("examples/EXAMPLE_part10.tga");

    //writes flipFile2 to output folder
    flipFile2.writeFile("output/part10.tga");

    std::cout << "Program is definitely done" << std::endl;

    return 0;
}
