//
// Created by amyho on 11/5/2023.
//
#include <fstream>
#include <iostream>

#ifndef PROJECTTHREE_TGA_H
#define PROJECTTHREE_TGA_H

//from Image Processing proj PDF
//takes the header data and stores it
struct Header
{
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
};
//From image processing proj PDF
//stores the pixel data in the appropriate variable
struct Pixel{
    unsigned char blue;
    unsigned char green;
    unsigned char red;
};

//TGA object to store TGA file information
class TGA{
    //variables for convenience
    Header header;
    Pixel* imageData;
    int imageDataSize;

public:
    //constructor set to default, only the object is made just all the values are blank
    TGA() = default;

    //loads data in to a TGA object
    void loadFile(const std::string& filename);
    //writes the TGA data into a file
    void writeFile(const std::string& filename);
    //compares the TGA data to another TGA file to see if they match or are the same image
    bool compareImages(const std::string& fileOne);
    //prints the header data
    void printHeader() const;
    //uses 2 TGA files and uses multiplying blending mode
    void multiplyImage(const TGA& imageA, const TGA& imageB);
    //loads only header information into the TGA object
    void loadHeader(const std::string& filename);
    //checks if the potential RGB values are over 255 or under 0, having a normalized and non-normalized
    //version of the calculation
    float pixelMinMax(float& colorVal, bool isNormalized);
    //uses 2 TGA files and uses subtract blending mode
    void subtractImage(const TGA& source, const TGA& target);
    //uses 2 TGA files and uses screen blending mode
    void screenImage(const TGA& imageA, const TGA& imageB);
    //uses 2 TGA files and uses overlay blending mode
    void overlayImage(const TGA& topLayer, const TGA& bottomLayer);
    //takes the data of a TGA obj, and adds the requested amount to a specified value
    void channelAdd(const TGA& image, int blue, int green, int red);
    //takes the data of a TGA obj, and scales the requested amount to a specified value
    void channelScale(const TGA& image, int blue, int green, int red);
    //takes the data of a TGA obj, and separates them by channel into 3 different files
    void channelSeperate(TGA& blueFile, TGA& greenFile, TGA& redFile);
    //takes the data of 3 TGA objs and combines their channels together into one image.
    void channelCombination(const TGA& blueFile, const TGA& greenFile, const TGA& redFile);
    //flips the image 180 degrees
    void flipOneEighty(const TGA& toFlip);
    //destructor
    ~TGA();
};

#endif //PROJECTTHREE_TGA_H
