//
// Created by amyho on 11/5/2023.
//
#include "TGA.h"


void TGA::loadFile(const std::string& filename) {
    //fstream to read files
    std::fstream inFile;

    //opens a file in read mode and in binary and assigns it to inFile
    inFile.open(filename, std::ios::in | std::ios::binary);

    //if the file was able to open, it will start to read the file
    if (inFile){

        //this entire block is just to read the header information and put it in a header struct
        inFile.read(&header.idLength, sizeof(header.idLength));
        inFile.read(&header.colorMapType, sizeof(header.colorMapType));
        inFile.read(&header.dataTypeCode, sizeof(header.dataTypeCode));
        inFile.read(reinterpret_cast<char*>(&header.colorMapOrigin), sizeof(header.colorMapOrigin));
        inFile.read(reinterpret_cast<char*>(&header.colorMapLength), sizeof(header.colorMapLength));
        inFile.read(&header.colorMapDepth, sizeof(header.colorMapDepth));
        inFile.read(reinterpret_cast<char*>(&header.xOrigin), sizeof(header.xOrigin));
        inFile.read(reinterpret_cast<char*>(&header.yOrigin), sizeof(header.yOrigin));
        inFile.read(reinterpret_cast<char*>(&header.width), sizeof(header.width));
        inFile.read(reinterpret_cast<char*>(&header.height), sizeof(header.height));
        inFile.read(&header.bitsPerPixel, sizeof(header.bitsPerPixel));
        inFile.read(&header.imageDescriptor, sizeof(header.imageDescriptor));

        //stores the size of the image data
        imageDataSize = static_cast<int>(header.width * header.height);

        //creates the array that stores the image data (array of pixels)
        imageData = new Pixel[imageDataSize];

        //sets up a temporary pixel
        Pixel tmpPixel;

        //sets up a loo[ to iterate through the array and have it store a pixel
        for(int i = 0; i < imageDataSize ; i++){
            inFile.read(reinterpret_cast<char*>(&tmpPixel.blue), sizeof(tmpPixel.blue));
            inFile.read(reinterpret_cast<char*>(&tmpPixel.green), sizeof(tmpPixel.green));
            inFile.read(reinterpret_cast<char*>(&tmpPixel.red), sizeof(tmpPixel.red));

            imageData[i] = tmpPixel;

        }
        //closes file for safety
        inFile.close();
    }

    //if the file could not open, error message printed
    else{
        std::cout << "File issue: Could not open file (read) " << std::endl;
    }
}

void TGA::writeFile(const std::string& filename) {
    //ofstream to write files
    std::ofstream outputFile;

    //opens a file in out mode and in binary and assigns it to outputFile
    outputFile.open(filename, std::ios::out | std::ios::binary);

    //if output file opens, write into the file
    if(outputFile) {
        //writes header information
        outputFile.write(&header.idLength, sizeof(header.idLength));
        outputFile.write(&header.colorMapType, sizeof(header.colorMapType));
        outputFile.write(&header.dataTypeCode, sizeof(header.dataTypeCode));
        outputFile.write(reinterpret_cast<char *>(&header.colorMapOrigin), sizeof(header.colorMapOrigin));
        outputFile.write(reinterpret_cast<char *>(&header.colorMapLength), sizeof(header.colorMapLength));
        outputFile.write(&header.colorMapDepth, sizeof(header.colorMapDepth));
        outputFile.write(reinterpret_cast<char *>(&header.xOrigin), sizeof(header.xOrigin));
        outputFile.write(reinterpret_cast<char *>(&header.yOrigin), sizeof(header.yOrigin));
        outputFile.write(reinterpret_cast<char *>(&header.width), sizeof(header.width));
        outputFile.write(reinterpret_cast<char *>(&header.height), sizeof(header.height));
        outputFile.write(&header.bitsPerPixel, sizeof(header.bitsPerPixel));
        outputFile.write(&header.imageDescriptor, sizeof(header.imageDescriptor));

        //writes image data
        for (int i = 0; i < imageDataSize; i++) {
            outputFile.write(reinterpret_cast<char *>(&((imageData + i)->blue)), sizeof((imageData + i)->blue));
            outputFile.write(reinterpret_cast<char *>(&((imageData + i)->green)), sizeof((imageData + i)->green));
            outputFile.write(reinterpret_cast<char *>(&((imageData + i)->red)), sizeof((imageData + i)->red));;
        }
        //closes file
        outputFile.close();
    }
    else
        //if the file doesnt open, file error message
        std::cout << "File issue: Could not open file (write) " << std::endl;
}

//prints the header out for testing
void TGA::printHeader() const {
    std::cout << header.idLength << " possibly idlength" << std::endl;
    std::cout << header.colorMapType << " possibly colorMapType" << std::endl;
    std::cout << header.dataTypeCode << " possibly dataTypeCode" << std::endl;
    std::cout << header.colorMapOrigin << " possibly colorMapOrigin" << std::endl;
    std::cout << header.colorMapLength << " possibly colorMapLength" << std::endl;
    std::cout << header.colorMapDepth << " possibly colorMapDepth" << std::endl;
    std::cout << header.xOrigin << " possibly xOrigin" << std::endl;
    std::cout << header.yOrigin << " possibly yOrigin" << std::endl;
    std::cout << header.width << " possibly width" << std::endl;
    std::cout << header.height << " possibly height" << std::endl;
    std::cout << header.bitsPerPixel << " possibly bitsPerPixel" << std::endl;
    std::cout << header.imageDescriptor << " possibly imageDescriptor" << std::endl;
}

bool TGA::compareImages(const std::string &exampleFile) {

    //fstream variable
    std::fstream inFile;
    //temporary TGA object for convenience
    TGA tmpFile;

    //loads the example file in tmpFile
    tmpFile.loadFile(exampleFile);

    //checks each part of the header between the two files and compares them
    //if any part of the header is not the same, then it is not the same image
    if(header.idLength != tmpFile.header.idLength) {
        std::cout << "Something wrong with header idLength" << std::endl;
        return false;
    }
    if(header.colorMapType != tmpFile.header.colorMapType) {
        std::cout << "Something wrong with header colour map type" << std::endl;
        return false;
    }
    if(header.dataTypeCode != tmpFile.header.dataTypeCode) {
        std::cout << "Something wrong with header data type code" << std::endl;
        return false;
    }
    if(header.colorMapOrigin != tmpFile.header.colorMapOrigin) {
        std::cout << "Something wrong with header color map origin" << std::endl;
        return false;
    }
    if(header.colorMapLength != tmpFile.header.colorMapLength) {
        std::cout << "Something wrong with header colour map length" << std::endl;
        return false;
    }
    if(header.colorMapDepth != tmpFile.header.colorMapDepth) {
        std::cout << "Something wrong with header colour map depth" << std::endl;
        return false;
    }
    if(header.xOrigin != tmpFile.header.xOrigin) {
        std::cout << "Something wrong with header xOrigin" << std::endl;
        return false;
    }
    if(header.yOrigin != tmpFile.header.yOrigin) {
        std::cout << "Something wrong with header yOrigin" << std::endl;
        return false;
    }
    if(header.width != tmpFile.header.width) {
        std::cout << "Something wrong with header width" << std::endl;
        return false;
    }
    if(header.height != tmpFile.header.height) {
        std::cout << "Something wrong with header height" << std::endl;
        return false;
    }
    if(header.bitsPerPixel != tmpFile.header.bitsPerPixel) {
        std::cout << "Something wrong with header bitsPerPixel" << std::endl;
        return false;
    }
    if(header.imageDescriptor != tmpFile.header.imageDescriptor) {
        std::cout << "Something wrong with header Image Descriptor" << std::endl;
        return false;
    }

    //loops through both files and compares their image data
    //if any pixel is wrong, it will say what value is wrong and then exit the loop.
    for(int i = 0; i < tmpFile.imageDataSize; i++){
        if(this->imageData[i].blue != tmpFile.imageData[i].blue){
            std::cout << "definitely blue pixel false " << i << std::endl;
            std::cout << "mine: " << static_cast<int>(this->imageData[i].blue) << " example: " << static_cast<int>(tmpFile.imageData[i].blue) << std::endl;

            return false;
        }
        if(this->imageData[i].green != tmpFile.imageData[i].green){
            std::cout << "definitely green pixel false " << i << std::endl;
            std::cout << "mine: " << static_cast<int>(this->imageData[i].green) << " example: " << static_cast<int>(tmpFile.imageData[i].green) << std::endl;
            return false;
        }
        if(this->imageData[i].red != tmpFile.imageData[i].red){
            std::cout << "definitely red pixel false " << i << std::endl;
            std::cout << "mine: " << static_cast<int>(this->imageData[i].red) << " example: " << static_cast<int>(tmpFile.imageData[i].red) << std::endl;
            return false;
        }
    }
    //if it can pass all of these tests, then the files are likely the same
    std::cout << "definitely true" << std::endl;
    return true;

}

TGA::~TGA(){
    //deletes the only thing in a TGA object that is on the heap
    delete[] imageData;
}

void TGA::multiplyImage(const TGA& imageA, const TGA& imageB) {
    //variable for convenience
    float tmpPixelData;

    //loop that loops through each individual pixel of both files and then multiplies them together
    //The values are normalized for convenience.
    for(int i = 0; i < this->imageDataSize; i++){

        tmpPixelData = ((imageA.imageData[i].blue))/255.0 * ((imageB.imageData[i].blue))/255.0;
        this->imageData[i].blue = pixelMinMax(tmpPixelData, true);

        tmpPixelData = ((imageA.imageData[i].green))/255.0 * ((imageB.imageData[i].green))/255.0;
        this->imageData[i].green = pixelMinMax(tmpPixelData, true);

        tmpPixelData = ((imageA.imageData[i].red))/255.0 * ((imageB.imageData[i].red))/255.0;
        this->imageData[i].red = pixelMinMax(tmpPixelData, true);
    }
}

void TGA::loadHeader(const std::string &filename) {
    //fstream variable
    std::fstream inFile;

    //opens the file in binary read mode
    inFile.open(filename, std::ios::in | std::ios::binary);

    //if the file cane open, it will load only the header and assigns an empty
    //array and its size
    if (inFile) {
        inFile.read(&header.idLength, sizeof(char));
        inFile.read(&header.colorMapType, sizeof(char));
        inFile.read(&header.dataTypeCode, sizeof(char));
        inFile.read(reinterpret_cast<char *>(&header.colorMapOrigin), sizeof(short));
        inFile.read(reinterpret_cast<char *>(&header.colorMapLength), sizeof(short));
        inFile.read(&header.colorMapDepth, sizeof(char));
        inFile.read(reinterpret_cast<char *>(&header.xOrigin), sizeof(short));
        inFile.read(reinterpret_cast<char *>(&header.yOrigin), sizeof(short));
        inFile.read(reinterpret_cast<char *>(&header.width), sizeof(short));
        inFile.read(reinterpret_cast<char *>(&header.height), sizeof(short));
        inFile.read(&header.bitsPerPixel, sizeof(char));
        inFile.read(&header.imageDescriptor, sizeof(char));

        imageDataSize = static_cast<int>(header.width * header.height);

        imageData = new Pixel[imageDataSize];
    }
    //if opening the file fails
    else
        std::cout << "Loading header function failed" << std::endl;
}


float TGA::pixelMinMax(float& colorVal, bool isNormalized) {

    //operation that only runs if the values given are normalized
    //unnormalizes them and checks if it's greater than 255 or less than 0
    // greater than 255 has it capped at 255
    // less than 0 has it put to the minimum of 0
    if (isNormalized) {
        if (colorVal * 255.0f > 255)
            return 255;
        else if (colorVal * 255.0f < 0)
            return 0;
        else
            //fixes any rounding issues
            return (colorVal * 255.0f) + .5f;
    }

    //if it is not normalized, it will do the same thing as above but without the extra math
    else
        if(colorVal > 255)
            return 255;
        else if(colorVal < 0)
            return 0;
        else
            return colorVal;
}

void TGA::subtractImage(const TGA& source, const TGA& target) {
    //variable for convenience
    float tmpPixelData;

    //loop that goes through the imageData of both files and iterates through each pixel (and their values)
    //and subtracts them
    for (int i = 0; i < this->imageDataSize; i++) {

        tmpPixelData = ((target.imageData[i].blue)) - ((source.imageData[i].blue));
        this->imageData[i].blue = pixelMinMax(tmpPixelData, false);

        tmpPixelData = ((target.imageData[i].green)) - ((source.imageData[i].green));
        this->imageData[i].green = pixelMinMax(tmpPixelData, false);

        tmpPixelData = ((target.imageData[i].red)) - ((source.imageData[i].red));
        this->imageData[i].red = pixelMinMax(tmpPixelData, false);
    }
}

void TGA::screenImage(const TGA &imageA, const TGA &imageB) {
    //var for convenience
    float tmpPixelData;

    //loop that goes through the imageData of both files and iterates through each pixel (and their values)
    //and applies the screen blending mode
    for (int i = 0; i < this->imageDataSize; i++) {

        tmpPixelData = (((1 - imageA.imageData[i].blue/255.0)) * ((1 - imageB.imageData[i].blue/255.0)));
        tmpPixelData = 1 - tmpPixelData;
        this->imageData[i].blue = pixelMinMax(tmpPixelData, true);

        tmpPixelData = (((1 - imageA.imageData[i].green/255.0)) * ((1 - imageB.imageData[i].green/255.0)));
        tmpPixelData = 1 - tmpPixelData;
        this->imageData[i].green = pixelMinMax(tmpPixelData, true);

        tmpPixelData = (((1 - imageA.imageData[i].red/255.0)) * ((1 - imageB.imageData[i].red/255.0)));
        tmpPixelData = 1 - tmpPixelData;
        this->imageData[i].red = pixelMinMax(tmpPixelData, true);
    }
}

void TGA::overlayImage(const TGA &topLayer, const TGA &bottomLayer) {
    //var for convenience
    float tmpPixelData;

    //loop that goes through the imageData of both files and iterates through each pixel (and their values)
    //and applies the overlay blending mode
    //it first checks if its darker or lighter than 50% gray to decide which operation to do.
    for (int i = 0; i < this->imageDataSize; i++){

        if((topLayer.imageData[i].blue/255.0) > .5){
            tmpPixelData = (((1.0 - topLayer.imageData[i].blue/255.0)) * ((1.0 - bottomLayer.imageData[i].blue/255.0)));
            tmpPixelData = 1.0 - (2.0 * tmpPixelData);
            this->imageData[i].blue = pixelMinMax(tmpPixelData, true);
        }
        else{
            tmpPixelData = 2.0 * ((topLayer.imageData[i].blue)/255.0) * ((bottomLayer.imageData[i].blue)/255.0);
            this->imageData[i].blue = pixelMinMax(tmpPixelData, true);
        }

        if((topLayer.imageData[i].green/255.0) > .5){
            tmpPixelData = (((1.0 - topLayer.imageData[i].green/255.0)) * ((1.0 - bottomLayer.imageData[i].green/255.0)));
            tmpPixelData = 1.0 - (2.0 * tmpPixelData);
            this->imageData[i].green = pixelMinMax(tmpPixelData, true);
        }
        else{
            tmpPixelData = 2.0 * ((topLayer.imageData[i].green)/255.0) * ((bottomLayer.imageData[i].green)/255.0);
            this->imageData[i].green = pixelMinMax(tmpPixelData, true);
        }

        if((topLayer.imageData[i].red/255.0) > .5){
            tmpPixelData = (((1.0 - topLayer.imageData[i].red/255.0)) * ((1.0 - bottomLayer.imageData[i].red/255.0)));
            tmpPixelData = 1.0 - (2.0 * tmpPixelData);
            this->imageData[i].red = pixelMinMax(tmpPixelData, true);
        }
        else{
            tmpPixelData = 2.0 * ((topLayer.imageData[i].red)/255.0) * ((bottomLayer.imageData[i].red)/255.0);
            this->imageData[i].red = pixelMinMax(tmpPixelData, true);
        }
    }
}

void TGA::channelAdd(const TGA& image, int blue, int green, int red) {
    //variable for convenience
    float tmpPixelData;

    //adds to the channel of the chosen image (and its pixels) by the values in the parameters
    for (int i = 0; i < this->imageDataSize; i++) {

        tmpPixelData = ((image.imageData[i].blue) + blue);
        this->imageData[i].blue = pixelMinMax(tmpPixelData, false);

        tmpPixelData = ((image.imageData[i].green) + green);
        this->imageData[i].green = pixelMinMax(tmpPixelData, false);

        tmpPixelData = ((image.imageData[i].red) +red);
        this->imageData[i].red = pixelMinMax(tmpPixelData, false);
    }
}

void TGA::channelScale(const TGA &image, int blue, int green, int red) {
    //var for convenience
    float tmpPixelData;

    //loop for the chosen image that scales the values in a pixel by the parameters inputted
    for(int i = 0; i < this->imageDataSize; i++) {

        tmpPixelData = (((image.imageData[i].blue) / 255.0) * blue);
        this->imageData[i].blue = pixelMinMax(tmpPixelData, true);

        tmpPixelData = (((image.imageData[i].green) / 255.0) * green);
        this->imageData[i].green = pixelMinMax(tmpPixelData, true);

        tmpPixelData = (((image.imageData[i].red) / 255.0) * red);
        this->imageData[i].red = pixelMinMax(tmpPixelData, true);
    }
}

void TGA::channelSeperate(TGA& blueFile, TGA& greenFile, TGA& redFile){
    //loops through the imageData of the chosen file and separates the channels and
    //puts them into separate files
    for(int i = 0; i < this->imageDataSize; i++){
        blueFile.imageData[i].blue = this->imageData[i].blue;
        blueFile.imageData[i].green = this->imageData[i].blue;
        blueFile.imageData[i].red = this->imageData[i].blue;

        greenFile.imageData[i].blue = this->imageData[i].green;
        greenFile.imageData[i].green = this->imageData[i].green;
        greenFile.imageData[i].red = this->imageData[i].green;

        redFile.imageData[i].blue = this->imageData[i].red;
        redFile.imageData[i].green = this->imageData[i].red;
        redFile.imageData[i].red = this->imageData[i].red;
    }
}

void TGA::channelCombination(const TGA &blueFile, const TGA &greenFile, const TGA &redFile) {
    //loops through the files that are seperated by files and combines them together
    //into one image
    for(int i = 0; i < blueFile.imageDataSize; i++){
        this->imageData[i].blue = blueFile.imageData[i].red;
        this->imageData[i].green = greenFile.imageData[i].red;
        this->imageData[i].red = redFile.imageData[i].red ;
    }
}

void TGA::flipOneEighty(const TGA& toFlip) {
    //flips a file by iterating backwards on one of them and iterating forwards on the other
    for(int i = (toFlip.imageDataSize - 1); i >= 0; i--){
        this->imageData[i].blue = toFlip.imageData[toFlip.imageDataSize - 1 - i].blue;
        this->imageData[i].green = toFlip.imageData[toFlip.imageDataSize - 1 - i].green;
        this->imageData[i].red = toFlip.imageData[toFlip.imageDataSize - 1 - i].red;
    }
}


