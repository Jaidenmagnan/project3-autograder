using namespace std;
#ifndef IMAGE_PROCESSOR_PIXELDATA_H
#define IMAGE_PROCESSOR_PIXELDATA_H
//Holds the pixel data of the image.
//RGB values
struct pixelData{
public:
    unsigned char redValue;
    unsigned char blueValue;
    unsigned char greenValue;
};
#endif //IMAGE_PROCESSOR_PIXELDATA_H
