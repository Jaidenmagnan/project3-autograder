#pragma once
#include <string>
#include <fstream>
#include <vector>
using namespace std;
//Header struct to store header info
struct Header{
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
};
//creates an image class
class image{
    //header object
    Header headerObject;
    int imageSize;
    //vectors to store pixel info
    vector<unsigned char> blue_pixels;
    vector<unsigned char> green_pixels;
    vector<unsigned char> red_pixels;
public:
    image();
    //different image methods
    void read_file(const string& filename);
    void write_file(const string& filename);
    void multiply(const image& image1, const image& image2);
    void subtract(const image& image1, const image& image2);
    void screen(const image& image1, const image& image2);
    void overlay(const image& image1, const image& image2);
    void add_green(int amt);
    void scale(int bscale, int gscale, int rscale);
    void seperate_colors(int color);
    void combine(const image& blue, const image& green, const image& red);
    void rotate180();

    vector<unsigned char> getBluePixels();
    vector<unsigned char> getGreenPixels();
    vector<unsigned char> getRedPixels();
};