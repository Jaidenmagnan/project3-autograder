#include "image.h"
#include <fstream>
#include <vector>
using namespace std;
//image constructor
image::image(){

}
//reads files in order
void image::read_file(const string &filename) {
    ifstream inStream(filename, std::ios::binary);

    if (inStream){
        inStream.read(&headerObject.idLength, sizeof(headerObject.idLength));
        inStream.read(&headerObject.colorMapType, sizeof(headerObject.colorMapType));
        inStream.read(&headerObject.dataTypeCode, sizeof(headerObject.dataTypeCode));
        inStream.read((char*)&headerObject.colorMapOrigin, sizeof(headerObject.colorMapOrigin));
        inStream.read((char*)&headerObject.colorMapLength, sizeof(headerObject.colorMapLength));
        inStream.read(&headerObject.colorMapDepth, sizeof(headerObject.colorMapDepth));
        inStream.read((char*)&headerObject.xOrigin, sizeof(headerObject.xOrigin));
        inStream.read((char*)&headerObject.yOrigin, sizeof(headerObject.yOrigin));
        inStream.read((char*)&headerObject.width, sizeof(headerObject.width));
        inStream.read((char*)&headerObject.height, sizeof(headerObject.height));
        inStream.read(&headerObject.bitsPerPixel, sizeof(headerObject.bitsPerPixel));
        inStream.read(&headerObject.imageDescriptor, sizeof(headerObject.imageDescriptor));

        this->imageSize = (int)headerObject.height*headerObject.width;
        int i;
        int j;
        //gathers pixel data
        for(i = 0; i < this->imageSize; i++){
            unsigned char pixb = 0;
            unsigned char pixg = 0;
            unsigned char pixr = 0;

            inStream.read((char*)&pixb, sizeof(unsigned char));
            inStream.read((char*)&pixg, sizeof(unsigned char));
            inStream.read((char*)&pixr, sizeof(unsigned char));

            blue_pixels.push_back(pixb);
            green_pixels.push_back(pixg);
            red_pixels.push_back(pixr);
        }

    }else{
        throw std::ifstream::failure("Cannot open file");
    }

}
//writes file
void image::write_file(const string& filename) {
    ofstream oStream(filename, std::ios::binary);

    if (oStream) {
        oStream.write(&headerObject.idLength, sizeof(headerObject.idLength));
        oStream.write(&headerObject.colorMapType, sizeof(headerObject.colorMapType));
        oStream.write(&headerObject.dataTypeCode, sizeof(headerObject.dataTypeCode));
        oStream.write((char *) &headerObject.colorMapOrigin, sizeof(headerObject.colorMapOrigin));
        oStream.write((char *) &headerObject.colorMapLength, sizeof(headerObject.colorMapLength));
        oStream.write(&headerObject.colorMapDepth, sizeof(headerObject.colorMapDepth));
        oStream.write((char *) &headerObject.xOrigin, sizeof(headerObject.xOrigin));
        oStream.write((char *) &headerObject.yOrigin, sizeof(headerObject.yOrigin));
        oStream.write((char *) &headerObject.width, sizeof(headerObject.width));
        oStream.write((char *) &headerObject.height, sizeof(headerObject.height));
        oStream.write(&headerObject.bitsPerPixel, sizeof(headerObject.bitsPerPixel));
        oStream.write(&headerObject.imageDescriptor, sizeof(headerObject.imageDescriptor));
        //writes pixel data
        int i;
        for(i = 0; i < imageSize; i++){
            oStream.write((char*)&blue_pixels[i], sizeof(unsigned char));
            oStream.write((char*)&green_pixels[i], sizeof(unsigned char));
            oStream.write((char*)&red_pixels[i], sizeof(unsigned char));

        }
    }else{
        throw std::ofstream::failure("Cannot write to file");
    }

}
//multiply method, uses normalization
void image::multiply(const image& image1, const image& image2) {
    int i;
    for (i = 0; i < imageSize; i++){
        float pixb = (image1.blue_pixels[i]/255.0f)*(image2.blue_pixels[i]/255.0f);
        float pixg = (image1.green_pixels[i]/255.0f)*(image2.green_pixels[i]/255.0f);
        float pixr = (image1.red_pixels[i]/255.0f)*(image2.red_pixels[i]/255.0f);

        this->blue_pixels[i] = (unsigned char)(pixb*255.0f+0.5f);
        this->green_pixels[i] = (unsigned char)(pixg*255.0f+0.5f);
        this->red_pixels[i] = (unsigned char)(pixr*255.0f+0.5f);
    }
}
//subtract method
void image::subtract(const image &image1, const image &image2) {
    int i;
    for(i = 0; i < imageSize; i++){
        float pixb = (image1.blue_pixels[i]/255.0f)-(image2.blue_pixels[i]/255.0f);
        float pixg = (image1.green_pixels[i]/255.0f)-(image2.green_pixels[i]/255.0f);
        float pixr = (image1.red_pixels[i]/255.0f)-(image2.red_pixels[i]/255.0f);

        this->blue_pixels[i] = (unsigned char)(max(0, (int)(pixb*255.0f+0.5f)));
        this->green_pixels[i] = (unsigned char)(max(0, (int)(pixg*255.0f+0.5f)));
        this->red_pixels[i] = (unsigned char)(max(0, (int)(pixr*255.0f+0.5f)));
    }
}
//screen method
void image::screen(const image& image1, const image& image2) {
    int i;
    for (i = 0; i < imageSize; i++){
        float pixb = 1-(1-image1.blue_pixels[i]/255.0f)*(1-image2.blue_pixels[i]/255.0f);
        float pixg = 1-(1-image1.green_pixels[i]/255.0f)*(1-image2.green_pixels[i]/255.0f);
        float pixr = 1-(1-image1.red_pixels[i]/255.0f)*(1-image2.red_pixels[i]/255.0f);

        this->blue_pixels[i] = (unsigned char)(pixb*255.0f+0.5f);
        this->green_pixels[i] = (unsigned char)(pixg*255.0f+0.5f);
        this->red_pixels[i] = (unsigned char)(pixr*255.0f+0.5f);
    }
}
//overlay method
void image::overlay(const image& image1, const image& image2) {
    int i;
    for (i = 0; i < imageSize; i++){
        float pixb1 = (image1.blue_pixels[i]/255.0f);
        float pixg1 = (image1.green_pixels[i]/255.0f);
        float pixr1 = (image1.red_pixels[i]/255.0f);
        float pixb2 = (image2.blue_pixels[i]/255.0f);
        float pixg2 = (image2.green_pixels[i]/255.0f);
        float pixr2 = (image2.red_pixels[i]/255.0f);

        float pixb, pixg, pixr;

        if(pixb2 <= 0.5f){
            pixb = 2*pixb1*pixb2;
        }else{
            pixb = 1-2*(1-pixb1)*(1-pixb2);
        }
        if(pixg2 <= 0.5f){
            pixg = 2*pixg1*pixg2;
        }else{
            pixg = 1-2*(1-pixg1)*(1-pixg2);
        }
        if(pixr2 <= 0.5f){
            pixr = 2*pixr1*pixr2;
        }else{
            pixr = 1-2*(1-pixr1)*(1-pixr2);
        }

        this->blue_pixels[i] = (unsigned char)(pixb*255.0f+0.5f);
        this->green_pixels[i] = (unsigned char)(pixg*255.0f+0.5f);
        this->red_pixels[i] = (unsigned char)(pixr*255.0f+0.5f);
    }
}
//adds a certain amount to the green pixels
void image::add_green(int amt) {
    int i;
    for (i = 0; i < imageSize; i++) {
        float pixg = (this->green_pixels[i]/255.0f)+(amt/255.0f);
        this->green_pixels[i] = (unsigned char)(max(min((int)(pixg*255.0f+0.5f), 255), 0));
    }
}
//scales the pixels of each color
void image::scale(int bscale, int gscale, int rscale) {
    int i;
    for (i = 0; i < imageSize; i++) {
        float pixb = (this->blue_pixels[i]/255.0f)*bscale;
        float pixg = (this->green_pixels[i]/255.0f)*gscale;
        float pixr = (this->red_pixels[i]/255.0f)*rscale;

        this->blue_pixels[i] = (unsigned char)(min((int)(pixb*255.0f+0.5f), 255));
        this->green_pixels[i] = (unsigned char)(min((int)(pixg*255.0f+0.5f), 255));
        this->red_pixels[i] = (unsigned char)(min((int)(pixr*255.0f+0.5f), 255));
    }
}
//separates the color indicated
void image::seperate_colors(int color) {
    //color = 1: blue, 2: green, 3: red
    int i;
    for (i = 0; i < imageSize; i++){
        int pixb = (this->blue_pixels[i]);
        int pixg = (this->green_pixels[i]);
        int pixr = (this->red_pixels[i]);
        if (color == 1) {
            this->green_pixels[i] = (unsigned char) pixb;
            this->red_pixels[i] = (unsigned char) pixb;
        } else if(color == 2){
            this->blue_pixels[i] = (unsigned char) pixg;
            this->red_pixels[i] = (unsigned char) pixg;
        } else if(color == 3){
            this->blue_pixels[i] = (unsigned char) pixr;
            this->green_pixels[i] = (unsigned char) pixr;
        }
    }
}
//combines 3 color stream images
void image::combine(const image &blue, const image &green, const image &red) {
    int i;
    for (i = 0; i < imageSize; i++) {
        int pixb = (blue.blue_pixels[i]);
        int pixg = (green.green_pixels[i]);
        int pixr = (red.red_pixels[i]);

        this->blue_pixels[i] = pixb;
        this->green_pixels[i] = pixg;
        this->red_pixels[i] = pixr;
    }
}
//rotates an image 180
void image::rotate180() {
    vector<unsigned char> orig_b = blue_pixels;
    vector<unsigned char> orig_g = green_pixels;
    vector<unsigned char> orig_r = red_pixels;

    int i;
    for (i = 0; i < imageSize; i++) {
        int pixb = (orig_b[i]);
        int pixg = (orig_g[i]);
        int pixr = (orig_r[i]);

        this->blue_pixels[(int)orig_b.size()-i-1] = (unsigned char)pixb;
        this->green_pixels[(int)orig_g.size()-i-1] = (unsigned char)pixg;
        this->red_pixels[(int)orig_b.size()-i-1] = (unsigned char)pixr;

    }
}
//returns blue pixels
vector<unsigned char> image::getBluePixels() {
    return blue_pixels;
}
//returns green pixels
vector<unsigned char> image::getGreenPixels() {
    return green_pixels;
}
//returns red pixels
vector<unsigned char> image::getRedPixels() {
    return red_pixels;
}