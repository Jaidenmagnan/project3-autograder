#include <iostream>
#include "image.h"
#include <string>
using namespace std;

//part one method
void part_one(){
    image layerOne;
    image patternOne;
    //reads tga files
    layerOne.read_file("input/layer1.tga");
    patternOne.read_file("input/pattern1.tga");

    //initializes new image to a placeholder image
    image partOneImg = layerOne;

    //multiplies images
    partOneImg.multiply(layerOne, patternOne);

    //writes new image
    partOneImg.write_file("output/part1.tga");
}

//part two method
void part_two(){
    image layerTwo;
    image car;
    //reads tga files
    layerTwo.read_file("input/layer2.tga");
    car.read_file("input/car.tga");

    //initializes new image to a placeholder image
    image partTwoImg = car;

    //multiplies images
    partTwoImg.subtract(car, layerTwo);

    //writes new image
    partTwoImg.write_file("output/part2.tga");
}

//part three method
void part_three(){
    image layerOne;
    image patternTwo;
    //reads tga files
    layerOne.read_file("input/layer1.tga");
    patternTwo.read_file("input/pattern2.tga");

    //initializes new image to a placeholder image
    image placeHolder = layerOne;

    image text;
    text.read_file("input/text.tga");

    //multiplies images
    placeHolder.multiply(layerOne, patternTwo);

    image partThreeImg = placeHolder;
    partThreeImg.screen(placeHolder, text);

    //writes new image
    partThreeImg.write_file("output/part3.tga");
}

//part four method
void part_four(){
    image layerTwo;
    image circles;
    //reads tga files
    layerTwo.read_file("input/layer2.tga");
    circles.read_file("input/circles.tga");

    //initializes new image to a placeholder image
    image placeHolder = layerTwo;

    //multiplies images
    placeHolder.multiply(layerTwo, circles);

    image patternTwo;
    patternTwo.read_file("input/pattern2.tga");

    image partFourImage = placeHolder;
    partFourImage.subtract(placeHolder, patternTwo);
    //writes new image
    partFourImage.write_file("output/part4.tga");
}

//part five method
void part_five(){
    image layerOne;
    image patternOne;
    //reads tga files
    layerOne.read_file("input/layer1.tga");
    patternOne.read_file("input/pattern1.tga");

    //initializes new image to a placeholder image
    image partFiveImg = layerOne;

    //multiplies images
    partFiveImg.overlay(layerOne, patternOne);

    //writes new image
    partFiveImg.write_file("output/part5.tga");
}

//part one method
void part_six(){
    image car;
    //reads tga files
    car.read_file("input/car.tga");

    //initializes new image to a placeholder image
    image partSixImg = car;

    //multiplies images
    partSixImg.add_green(200);

    //writes new image
    partSixImg.write_file("output/part6.tga");
}

//part seven method
void part_seven(){
    image car;

    //reads tga files
    car.read_file("input/car.tga");


    //initializes new image to a placeholder image
    image partSevenImg = car;

    //multiplies images
    partSevenImg.scale(0, 1, 4);

    //writes new image
    partSevenImg.write_file("output/part7.tga");
}

//part one method
void part_eight(){
    image car;
    //reads tga files
    car.read_file("input/car.tga");


    //initializes new image to a placeholder image
    image partEightImgB = car;
    image partEightImgG = car;
    image partEightImgR = car;

    //multiplies images
    partEightImgB.seperate_colors(1);
    partEightImgG.seperate_colors(2);
    partEightImgR.seperate_colors(3);

    //writes new image
    partEightImgB.write_file("output/part8_b.tga");
    partEightImgG.write_file("output/part8_g.tga");
    partEightImgR.write_file("output/part8_r.tga");
}

//part nine method
void part_nine(){
    image layerRed;
    image layerGreen;
    image layerBlue;
    //reads tga files
    layerRed.read_file("input/layer_red.tga");
    layerGreen.read_file("input/layer_green.tga");
    layerBlue.read_file("input/layer_blue.tga");

    //initializes new image to a placeholder image
    image partNineImg = layerRed;

    //multiplies images
    partNineImg.combine(layerBlue, layerGreen, layerRed);

    //writes new image
    partNineImg.write_file("output/part9.tga");
}

//part ten method
void part_ten(){
    image text2;
    //reads tga files
    text2.read_file("input/text2.tga");

    //initializes new image to a placeholder image
    image partTenImg = text2;

    //multiplies images
    partTenImg.rotate180();

    //writes new image
    partTenImg.write_file("output/part10.tga");
}

void test(const string& img1,const string& img2, int partNum){
    image image1;
    image image2;

    image1.read_file(img1);
    image2.read_file(img2);

    if(image1.getBluePixels() == image2.getBluePixels()
    && image1.getGreenPixels() == image1.getGreenPixels()
    && image1.getRedPixels() == image1.getRedPixels()){
        cout << "Test #" << partNum << "...... Passed!" << endl;
    } else{
        cout << "Test #" << partNum << "...... Failed!" << endl;
    }

}

int main() {
    part_one();
    part_two();
    part_three();
    part_four();
    part_five();
    part_six();
    part_seven();
    part_eight();
    part_nine();
    part_ten();

    test("examples/EXAMPLE_part1.tga", "output/part1.tga", 1);
    test("examples/EXAMPLE_part2.tga", "output/part2.tga", 2);
    test("examples/EXAMPLE_part3.tga", "output/part3.tga", 3);
    test("examples/EXAMPLE_part4.tga", "output/part4.tga", 4);
    test("examples/EXAMPLE_part5.tga", "output/part5.tga", 5);
    test("examples/EXAMPLE_part6.tga", "output/part6.tga", 6);
    test("examples/EXAMPLE_part7.tga", "output/part7.tga", 7);
    test("examples/EXAMPLE_part8_b.tga", "output/part8_b.tga", 81);
    test("examples/EXAMPLE_part8_g.tga", "output/part8_g.tga", 82);
    test("examples/EXAMPLE_part8_r.tga", "output/part8_r.tga", 83);
    test("examples/EXAMPLE_part9.tga", "output/part9.tga", 9);
    test("examples/EXAMPLE_part10.tga", "output/part10.tga", 10);

    return 0;
}
