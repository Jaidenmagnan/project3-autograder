#pragma once
#include "string"
#include "fstream"
#include "filesystem"

#ifndef __has_include
static_assert(false, "__has_include not supported");
#else
#  if __cplusplus >= 201703L && __has_include(<filesystem>)
#    include <filesystem>
     namespace fs = fs;
#  elif __has_include(<experimental/filesystem>)
#    include <experimental/filesystem>
namespace fs = std::experimental::filesystem;
#  elif __has_include(<boost/filesystem.hpp>)
#    include <boost/filesystem.hpp>
     namespace fs = boost::filesystem;
#  endif
#endif

class Image {
private:
    // header
    struct Header {
        char idLength;
        char colorMapType;
        char dataTypeCode;
        char colorMapDepth;
        short colorMapOrigin;
        short colorMapLength;
        short xOrigin;
        short yOrigin;
        short width;
        short height;
        char bitsPerPixel;
        char imageDescriptor;
    } header;

    // body
    char* body = nullptr;
    unsigned char* r = nullptr;
    unsigned char* g = nullptr;
    unsigned char* b = nullptr;

    std::streamsize bodySize;
    std::string fileName;

public:
    Image(std::string iName, const std::string& = "input");
    Image(Header& newHeader, std::streamsize& bodySize);
    ~Image();

    // save the image
    void save(std::string oName);

    short& getWidth();
    short& getHeight();

    Image multiply (Image& imageB);
    Image subtract (Image& imageB);
    Image screen (Image& imageB);
    Image overlay (Image& imageB);
    Image combine (Image& imageB, Image &imageC);

    Image add (int ra, int ga, int ba);
    Image scale (int rs, int gs, int bs);
    Image set (int rs, int gs, int bs);     // set to -1 to ignore
    Image separate(bool rs, bool gs, bool bs);
    Image flip();
    void swap(char* a, char* b);

    Image combineFour(Image& imageB, Image& imageC, Image& imageD);

    inline int max (int a, int b) {return a > b ? a : b;}
    inline int min (int a, int b) {return a < b ? a : b;}

    void setBody(); // use rgb to set body

    void testExample();

};
