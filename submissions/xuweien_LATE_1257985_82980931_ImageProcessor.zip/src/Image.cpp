#include <iostream>
#include "Image.h"

Image::Image(std::string iName, const std::string& folderName) {
    fs::path currentPath = fs::current_path().parent_path();
    fs::path iPath = currentPath / fs::path(folderName) / fs::path(iName);

    std::ifstream inFile(iPath.string(), std::ios::binary);
    if (!inFile)
        std::cerr << "Failed to create ifstream: " << iPath << std::endl;

    inFile.read(reinterpret_cast<char*>(&header), sizeof(header));

    // header
    // determine the size of the rest
    std::streampos currentPos = inFile.tellg();
    inFile.seekg(0, std::ios::end);
    std::streampos endPos = inFile.tellg();
    inFile.seekg(currentPos);

    bodySize = endPos - currentPos;
    body = new char[bodySize];
    r = new unsigned char[bodySize / 3];
    g = new unsigned char[bodySize / 3];
    b = new unsigned char[bodySize / 3];

    inFile.read(body, bodySize);
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        r[i] = body[i * 3];
        g[i] = body[i * 3 + 1];
        b[i] = body[i * 3 + 2];
    }
//    setBody();
}

Image::Image(Image::Header &newHeader, std::streamsize& bodySize) {
    header = newHeader;
    this->bodySize = bodySize;
    body = new char[bodySize];
    r = new unsigned char[bodySize / 3];
    g = new unsigned char[bodySize / 3];
    b = new unsigned char[bodySize / 3];
}

Image::~Image() {
    delete[] body;
    delete[] r, g, b;
}

short& Image::getWidth() {
    return header.width;
}

short& Image::getHeight() {
    return header.height;
}

void Image::save(std::string oName) {
    fileName = oName;
    fs::path currentPath = fs::current_path().parent_path();
    fs::path oPath = currentPath / fs::path("output") / fs::path(oName);
    std::ofstream oImage(oPath.string(), std::ios::binary);
    if (!oImage)
        std::cerr << "Failed to create ofstream: " << oPath << std::endl;

    oImage.write(reinterpret_cast<char*>(&header), sizeof(header));
    oImage.write(body, bodySize);
}

Image Image::multiply(Image& imageB) {
    Image imageC = Image(header, bodySize);
    if(getHeight() != imageB.getHeight() || getWidth() != imageB.getWidth())
        std::cerr << "Multiply error: size different." << std::endl;

    // for each pixel, multiply
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = r[i] * imageB.r[i] / 255.f + 0.5f;
        imageC.g[i] = g[i] * imageB.g[i] / 255.f + 0.5f;
        imageC.b[i] = b[i] * imageB.b[i] / 255.f + 0.5f;
    }
    imageC.setBody();

    return imageC;
}

Image Image::subtract(Image &imageB) {
    if(getHeight() != imageB.getHeight() || getWidth() != imageB.getWidth())
        std::cerr << "Subtract error: size different." << std::endl;

    Image imageC = Image(header, bodySize);

    // for each pixel, subtract
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = imageB.r[i] > r[i] ? 0 : r[i] - imageB.r[i];
        imageC.g[i] = imageB.g[i] > g[i] ? 0 : g[i] - imageB.g[i];
        imageC.b[i] = imageB.b[i] > b[i] ? 0 : b[i] - imageB.b[i];
    }
    imageC.setBody();

    return imageC;
}

Image Image::screen(Image &imageB) {
    Image imageC = Image(header, bodySize);
    if(getHeight() != imageB.getHeight() || getWidth() != imageB.getWidth())
        std::cerr << "Screen error: size different." << std::endl;

    // for each pixel, screen
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = 255 - ((255 - r[i]) * (255 - imageB.r[i]) / 255.f - 0.5f);
        imageC.b[i] = 255 - ((255 - b[i]) * (255 - imageB.b[i]) / 255.f - 0.5f);
        imageC.g[i] = 255 - ((255 - g[i]) * (255 - imageB.g[i]) / 255.f - 0.5f);
        if (imageC.r[i] < 0 || imageC.b[i] < 0 || imageC.g[i] < 0)
            std::cerr << "negative" << std::endl;
    }
    imageC.setBody();

    return imageC;
}

Image Image::overlay(Image &imageB) {
    Image imageC = Image(header, bodySize);
    if(getHeight() != imageB.getHeight() || getWidth() != imageB.getWidth())
        std::cerr << "Overlay error: size different." << std::endl;

    // for each pixel, screen
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        if (imageB.r[i] <= 127)
            imageC.r[i] = 2 * (r[i] * imageB.r[i] / 255.f) + 0.5f;
        else
            imageC.r[i] = 255 - (2 * (255 - r[i]) * (255 - imageB.r[i]) / 255.f) + 0.5f;
        if (imageB.g[i] <= 127)
            imageC.g[i] = 2 * (g[i] * imageB.g[i] / 255.f) + 0.5f;
        else
            imageC.g[i] = 255 - (2 * (255 - g[i]) * (255 - imageB.g[i]) / 255.f) + 0.5f;
        if (imageB.b[i] <= 127)
            imageC.b[i] = 2 * (b[i] * imageB.b[i] / 255.f) + 0.5f;
        else
            imageC.b[i] = 255 - (2 * (255 - b[i]) * (255 - imageB.b[i]) / 255.f) + 0.5f;
        if (imageC.r[i] < 0 || imageC.b[i] < 0 || imageC.g[i] < 0)
            std::cerr << "negative" << std::endl;
    }
    imageC.setBody();

    return imageC;
}

Image Image::combine(Image &imageB, Image &imageC) {
    Image imageD = Image(header, bodySize);
    if(getHeight() != imageB.getHeight() || getWidth() != imageB.getWidth())
        std::cerr << "Combine error: size different." << std::endl;

    // for each pixel, combine
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageD.r[i] = imageC.r[i];
        imageD.g[i] = imageB.g[i];
        imageD.b[i] = b[i];
    }
    imageD.setBody();

    return imageD;
}

Image Image::add(int ra, int ga, int ba) {
    // the order are switched
    int temp = ra;
    ra = ba;
    ba = temp;

    Image imageC = Image(header, bodySize);

    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = min(r[i] + ra, 255);
        imageC.g[i] = min(g[i] + ga, 255);
        imageC.b[i] = min(b[i] + ba, 255);
    }
    imageC.setBody();

    return imageC;
}

Image Image::scale(int rs, int gs, int bs) {
    // the order are switched
    int temp = rs;
    rs = bs;
    bs = temp;

    Image imageC = Image(header, bodySize);

    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = min(r[i] * rs, 255);
        imageC.g[i] = min(g[i] * gs, 255);
        imageC.b[i] = min(b[i] * bs, 255);
    }
    imageC.setBody();

    return imageC;
}

Image Image::set(int rs, int gs, int bs) {
    // the order are switched
    int temp = gs;
    gs = bs;
    bs = temp;

    Image imageC = Image(header, bodySize);

    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = (rs == -1)? r[i] : rs;
        imageC.g[i] = (gs == -1)? g[i] : gs;
        imageC.b[i] = (bs == -1)? b[i] : bs;
    }
    imageC.setBody();

    return imageC;
}

Image Image::separate(bool rs, bool gs, bool bs) {
    // the order are switched
//    int temp = gs;
//    gs = bs;
//    bs = temp;

    Image imageC = Image(header, bodySize);
    unsigned char* targetChannel = nullptr;

    // which channel to separate
    if (rs) targetChannel = b;
    else if (gs) targetChannel = g;
    else targetChannel = r;

    for (unsigned int i = 0; i < bodySize / 3; i++) {
        imageC.r[i] = targetChannel[i];
        imageC.g[i] = targetChannel[i];
        imageC.b[i] = targetChannel[i];
    }
    imageC.setBody();

    return imageC;
}

Image Image::flip() {
    Image imageC = Image(header, bodySize);
    char* start = imageC.body;
    char* end = body + bodySize - 1;

    char temp;
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        *start = *(end - 2);
        *(start + 1) = *(end - 1);
        *(start + 2) = *(end - 0);

        start += 3;
        end -= 3;
    }

    return imageC;
}

void Image::setBody() {
    for (unsigned int i = 0; i < bodySize / 3; i++) {
        body[i * 3] = r[i];
        body[i * 3 + 1] = g[i];
        body[i * 3 + 2] = b[i];
    }
}

void Image::testExample() {
    Image exampleImage("EXAMPLE_" + fileName, "examples");
//    int sum = 0;
//    int count = 0;
    for (unsigned int i = 0; i < bodySize; i++) {
        if (body[i] != exampleImage.body[i]) {
//            count += 1;
//            sum += ((int)body[i] - (int)exampleImage.body[i]);
            std::cout << "Test " << fileName << " Failed." << std::endl << std::endl;
            return;
        }
    }
//    std::cout << "sum: " << sum << std::endl;
//    std::cout << "count: " << count << std::endl;
    std::cout << "Test " << fileName << " Passed." << std::endl << std::endl;
}

Image Image::combineFour(Image &imageB, Image &imageC, Image &imageD) {
    Image imageE(header, bodySize);
    imageE.header.width *= 2;
    imageE.header.height *= 2;
    imageE.bodySize *= 4;

    std::cout << "created: " << std::endl;

    unsigned int pixelSize = bodySize / 512 / 512 / 4;
    unsigned int blockSize = pixelSize * 512;

    unsigned int index = 0;

    for (unsigned int i = 0; i < imageE.bodySize / 3; i++) {
        imageE.r[i] = 0;
        imageE.g[i] = 0;
        imageE.b[i] = 0;
    }

    return imageE;

    for (unsigned int i = 0; i < imageE.bodySize; i++) {
        if (i % blockSize == blockSize)
            i += blockSize;
        imageE.body[i] = imageC.body[i];
    }

    std::cout << "one.";

    for (unsigned int i = blockSize; i < imageE.bodySize; i++) {
        if (i % blockSize == blockSize)
            i += blockSize;
        imageE.body[i] = imageD.body[i];
    }

    for (unsigned int i = blockSize * 2; i < imageE.bodySize; i++) {
        if (i % blockSize == blockSize)
            i += blockSize;
        imageE.body[i] = body[i];
    }

    for (unsigned int i = blockSize * 3; i < imageE.bodySize; i++) {
        if (i % blockSize == blockSize)
            i += blockSize;
        imageE.body[i] = imageB.body[i];
    }

    return imageE;
}
