#include "Image.h"
//#include "Image.cpp"
#include "iostream"
#include "string"


int main() {
    // set paths
    Image circles("circles.tga");
    Image layer_red("layer_red.tga");
    Image layer_blue("layer_blue.tga");
    Image layer_green("layer_green.tga");
    Image layer1("layer1.tga");
    Image pattern1("pattern1.tga");
    Image pattern2("pattern2.tga");
    Image car("car.tga");
    Image layer2("layer2.tga");
    Image text("text.tga");
    Image text2("text2.tga");


//    // task 0
//    Image task0("text.tga");
//    task0.save("task0.tga");
//    task0.testExample();
//    return 0;

//     task 1
    Image task1 = layer1.multiply(pattern1);
    task1.save("part1.tga");
    task1.testExample();

//     task 2
    Image task2 = car.subtract(layer2);
    task2.save("part2.tga");
    task2.testExample();

//     task 3
    Image buffer = layer1.multiply(pattern2);   // without a buffer, the image breaks - why?
    Image task3 = text.screen(buffer);
    task3.save("part3.tga");
    task3.testExample();

//     task 4
    Image task4 = (layer2.multiply(circles).subtract(pattern2));
    task4.save("part4.tga");
    task4.testExample();

//     task 5
    Image task5 = layer1.overlay(pattern1);
    task5.save("part5.tga");
    task5.testExample();

    // task 6
    Image task6 = car.add(0, 200, 0);
    task6.save("part6.tga");
    task6.testExample();

    // task 7
    Image task7 = car.scale(4, 1, 0);
    task7.save("part7.tga");
    task7.testExample();

    // task 8
    Image task8r = car.separate(1, 0, 0);
    Image task8g = car.separate(0, -1, 0);
    Image task8b = car.separate(0, 0, -1);
    task8r.save("part8_r.tga");
    task8g.save("part8_g.tga");
    task8b.save("part8_b.tga");
    task8r.testExample();
    task8g.testExample();
    task8b.testExample();

    // task 9
    Image task9 = layer_red.combine(layer_green, layer_blue);
    task9.save("part9.tga");
    task9.testExample();

    // task 10
    Image task10 = text2.flip();
    task10.save("part10.tga");
    task10.testExample();

    // extra credit
    Image extraCredit = car.combineFour(circles, pattern1, text);
    extraCredit.save("extracredit.tga");
    extraCredit.testExample();

}
