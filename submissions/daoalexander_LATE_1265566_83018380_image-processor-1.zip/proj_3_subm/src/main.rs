// parts of header that can be hard coded
static HEADER_TOP: [u8; 12] =  [0, 0, 2, 0, 0, 0,
                                0, 0, 0, 0, 0, 0];

static HEADER_BOT: [u8; 2] =  [24, 0];

// read function title to figure what's it's doing
fn read_file(file: &str) -> (Vec<u8>, Vec<u8>) {
    let bytes = std::fs::read(file).unwrap();
    (bytes[18..].to_vec(), bytes[12..16].to_vec())
}

fn write_file(file: &str, color: Vec<u8>, dimensions: Vec<u8>) {
    let data = vec![HEADER_TOP.clone().to_vec(), dimensions, HEADER_BOT.clone().to_vec(), color].concat();
    std::fs::write(file, data).unwrap();
}

fn rotate_layer(top_layer: Vec<u8>, dim: Vec<u8>) -> Vec<u8> {
    let mut tmp: Vec<u8> = vec![0; top_layer.len()];

    let width = ((dim[1] as u16) << 8) | dim[0] as u16;
    let height = ((dim[3] as u16) << 8) | dim[2] as u16;
    let size = ((width as u32 * height as u32 - 1) * 3) as usize;

    // works in chunks of 3 for rgb
    for i in (0..top_layer.len()).step_by(3) {
        // swaps the data by subtracting index from total size
        tmp[size - i + 0] = top_layer[i + 0];
        tmp[size - i + 1] = top_layer[i + 1];
        tmp[size - i + 2] = top_layer[i + 2];
    }

    tmp
}

fn multiply_layer(top_layer: Vec<u8>, bot_layer: Vec<u8>) -> Vec<u8> {
    top_layer.iter()
        .zip(bot_layer.iter())
        .map(|(x, y)| { 
            // multiplying layer logic here
            (*x as f64 / 255.0 * *y as f64 + 0.5) as u8
        }).collect()
}

fn screen_layer(top_layer: Vec<u8>, bot_layer: Vec<u8>) -> Vec<u8> {
    top_layer.iter()
        .zip(bot_layer.iter())
        .map(|(x, y)| { 
            // screening layer logic here
            (255.0 - (1.0 - *x as f64 / 255.0) * (255.0 - *y as f64) + 0.5) as u8
        }).collect()
}

fn overlay_layer(top_layer: Vec<u8>, bot_layer: Vec<u8>) -> Vec<u8> {
    top_layer.iter()
        .zip(bot_layer.iter())
        .map(|(y, x)| { 
            // holds the delta here
            let fractional_x = *x as f64 / 255.0;
            if fractional_x < 0.5 {
                // multiply here
                (2.0 * fractional_x * *y as f64 + 0.5) as u8
            } else { 
                // does overlay here
                (255.0 - 2.0 * (1.0 - fractional_x) * (255.0 - *y as f64) + 0.5) as u8
            }
        }).collect()
}

fn add_layer(top_layer: Vec<u8>, bot_layer: Vec<u8>) -> Vec<u8> {
    top_layer.iter()
        .zip(bot_layer.iter())
        .map(|(x, y)| { 
            // add but with a clamp
            y.saturating_add(*x)
        }).collect()
}

fn subtract_layer(top_layer: Vec<u8>, bot_layer: Vec<u8>) -> Vec<u8> {
    top_layer.iter()
        .zip(bot_layer.iter())
        .map(|(x, y)| { 
            // add but with a sub
            y.saturating_sub(*x)
        }).collect()
}

fn main() {
    // runs test cases
    case_01();
    case_02();
    case_03();
    case_04();
    case_05();
    case_06();
    case_07();
    case_08();
    case_09();
    case_10();
    case_ex();
}

fn compare_file(file_one: &str, file_two: &str) -> bool {
    let ex_1 = std::fs::read(file_one).unwrap();
    let ex_2 = std::fs::read(file_two).unwrap();

    let mut index = 0;
    // limit printing error
    for (byte1, byte2) in ex_1.iter().zip(ex_2.iter()).take(40) {
        if byte1 != byte2 {
            println!("{}: {} | {} ", index, byte1, byte2);
        }
        index += 1;
    }

    // but limit doesn't apply in the actual test value
    ex_1 == ex_2
}

//#[test]
fn file_reader() {
    let (color, _) = read_file("input/layer2.tga");
    let ex_color: Vec<_> = std::iter::repeat([236, 189, 0])
        .take(786432 / 3)
        .flatten()
        .collect();
    //assert_eq!(color, ex_color);
}

//#[test]
fn file_writer() {
    let (color, dim) = read_file("input/layer2.tga");
    write_file("output/layer2.tga", color, dim);

    //assert!(compare_file("input/layer2.tga", "output/layer2.tga"))
}

//#[test]
fn case_01() {
    // reads the inputs here
    let (top_layer, dim) = read_file("input/layer1.tga");
    let (bot_layer, _) = read_file("input/pattern1.tga");

    // applies the logic
    let new_layer = multiply_layer(top_layer, bot_layer);

    // writes the file
    write_file("output/part1.tga", new_layer, dim);

    //assert!(compare_file("output/part1.tga", "examples/EXAMPLE_part1.tga"));
}

//#[test]
// repeats for the remaining cases
fn case_02() {
    let (top_layer, dim) = read_file("input/layer2.tga");
    let (bot_layer, _) = read_file("input/car.tga");

    let new_layer = subtract_layer(top_layer, bot_layer);
    write_file("output/part2.tga", new_layer, dim);

    //assert!(compare_file("output/part2.tga", "examples/EXAMPLE_part2.tga"));
}

//#[test]
fn case_03() {
    let (top_layer, dim) = read_file("input/layer1.tga");
    let (bot_layer, _) = read_file("input/pattern2.tga");

    let top_layer2 = multiply_layer(top_layer, bot_layer);
    // loads next layer to work with
    let (bot_layer2, _) = read_file("input/text.tga");

    let new_layer = screen_layer(top_layer2, bot_layer2);
    write_file("output/part3.tga", new_layer, dim);

    //assert!(compare_file("output/part3.tga", "examples/EXAMPLE_part3.tga"));
}

//#[test]
fn case_04() {
    let (top_layer, dim) = read_file("input/layer2.tga");
    let (bot_layer, _) = read_file("input/circles.tga");

    let (top_layer2, _) = read_file("input/pattern2.tga");
    let bot_layer2 = multiply_layer(top_layer, bot_layer);

    let new_layer = subtract_layer(top_layer2, bot_layer2);
    write_file("output/part4.tga", new_layer, dim);

    //assert!(compare_file("output/part4.tga", "examples/EXAMPLE_part4.tga"));
}

//#[test]
fn case_05() {
    let (top_layer, dim) = read_file("input/layer1.tga");
    let (bot_layer, _) = read_file("input/pattern1.tga");

    let new_layer = overlay_layer(top_layer, bot_layer);
    write_file("output/part5.tga", new_layer, dim);

    //assert!(compare_file("output/part5.tga", "examples/EXAMPLE_part5.tga"));
}

//#[test]
fn case_06() {
    let (top_layer, dim) = read_file("input/car.tga");
    // generate pixel data to then add into img layer
    let bot_layer: Vec<_> = std::iter::repeat([0, 200, 0])
        .take(786432 / 3)
        .flatten()
        .collect();

    let new_layer = add_layer(top_layer, bot_layer);
    write_file("output/part6.tga", new_layer, dim);

    //assert!(compare_file("output/part6.tga", "examples/EXAMPLE_part6.tga"));
}

//#[test]
fn case_07() {
    let (top_layer, dim) = read_file("input/car.tga");

    let new_layer = top_layer.iter()
        // also generate pixel data, but this is for a mapped format
        .zip([0, 1, 4].iter().cycle())
        .map(|(x, y)| { 
            x.saturating_mul(*y)
        }).collect();
    write_file("output/part7.tga", new_layer, dim);

    //assert!(compare_file("output/part7.tga", "examples/EXAMPLE_part7.tga"));
}

//#[test]
fn case_08() {
    let (top_layer, dim) = read_file("input/car.tga");

    let mut red_layer = top_layer.clone();
    for rgb in red_layer.chunks_mut(3) {
        // set all other values to red
        rgb[0] = rgb[2];
        rgb[1] = rgb[2];
    }
    write_file("output/part8_r.tga", red_layer, dim.clone());
    //assert!(compare_file("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga"));

    // repeat process for green
    let mut green_layer = top_layer.clone();
    for rgb in green_layer.chunks_mut(3) {
        rgb[0] = rgb[1];
        rgb[2] = rgb[1];
    }
    write_file("output/part8_g.tga", green_layer, dim.clone());
    //assert!(compare_file("output/part8_g.tga", "examples/EXAMPLE_part8_g.tga"));

    // repeat process for blue
    let mut blue_layer = top_layer.clone();
    for rgb in blue_layer.chunks_mut(3) {
        rgb[1] = rgb[0];
        rgb[2] = rgb[0];
    }
    write_file("output/part8_b.tga", blue_layer, dim);
    //assert!(compare_file("output/part8_b.tga", "examples/EXAMPLE_part8_b.tga"));
}
//#[test]
fn case_09() {
    let (red_layer, dim) = read_file("input/layer_red.tga");
    let (green_layer, _) = read_file("input/layer_green.tga");
    let (blue_layer, _) = read_file("input/layer_blue.tga");

    let mut new_layer = vec![];
    for index in 0..red_layer.len() {
        // based on index determines which file data to read from
        match index % 3 {
            0 => new_layer.push(blue_layer[index]),
            1 => new_layer.push(green_layer[index]),
            _ => new_layer.push(red_layer[index])
        }
    }

    write_file("output/part9.tga", new_layer, dim);
    //assert!(compare_file("output/part9.tga", "examples/EXAMPLE_part9.tga"));
}

//#[test]
fn case_10() {
    let (top_layer, dim) = read_file("input/text2.tga");

    let new_layer = rotate_layer(top_layer, dim.clone());
    write_file("output/part10.tga", new_layer, dim);

    //assert!(compare_file("output/part10.tga", "examples/EXAMPLE_part10.tga"));
}

//#[test]
fn case_ex() {
    // grabs all four files
    let (top_left, _) = read_file("input/car.tga");
    let (top_right, _) = read_file("input/circles.tga");
    let (bot_left, _) = read_file("input/text.tga");
    let (bot_right, _) = read_file("input/pattern1.tga");
    // preset size
    let dim = [0, 4, 0, 4].to_vec();

    // new layer to progressive combine
    let mut new_layer: Vec<u8> = Vec::new();
    let offset = 512 * 3;

    // bottom part
    for i in (0..bot_left.len()).step_by(offset) {
        // left part
        new_layer.extend_from_slice(&bot_left[i..i+offset]);
        // right part
        new_layer.extend_from_slice(&bot_right[i..i+offset]);
    }

    // top part
    for i in (0..top_left.len()).step_by(offset) {
        // left part
        new_layer.extend_from_slice(&top_left[i..i+offset]);
        // right part
        new_layer.extend_from_slice(&top_right[i..i+offset]);
    }

    write_file("output/extracredit.tga", new_layer, dim);
    //assert!(compare_file("output/extracredit.tga", "examples/EXAMPLE_extracredit.tga"));
}
