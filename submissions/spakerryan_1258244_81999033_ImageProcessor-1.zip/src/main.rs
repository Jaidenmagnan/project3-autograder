/******************************************
 *  COP3504C Project 3: Image Processing  *
 *  Author: Ryan Spaker                   *
 ******************************************/

use std::{fs::{File, self}, io::{BufReader, Read, stdin}};
use itertools::Itertools;

/// Stores the data for a single image
pub struct ImageData{
    /// Stores the header data that was present in the source file
    header_bytes: Vec<u8>,
    /// Stores pixels in sets of b, g, r, component values, row by row going from bottom left to top right
    /// pixels are stored as i32's but are clamped to 0-255 after operations
    pixels: Vec<i32>,
    /// Width of the image. must be converted to a u16 when stored
    width: usize,
    /// Height of the image, must be converted to a u16 when stored
    height: usize
}
/// Functionality common to all images such as mutation and saving
impl ImageData{
    /// Writes the image to a file located at path
    pub fn write_to(&self, path: &str){
        let bytes: Vec<u8> = self.header_bytes.iter().map(|byte| *byte).chain(
            self.pixels.iter().map(|value| (*value.clamp(&0, &255)) as u8)
        ).collect();
        fs::write(path, bytes).expect("Couldn't Write Image");
    }
    /// Multiplies two images together, returning the result
    pub fn multiply(layer1: &ImageData, layer2: &ImageData) -> ImageData{
        assert_eq!(layer1.width, layer2.width, "failed to multiply images with different widths");
        assert_eq!(layer1.height, layer2.height, "failed to multiply images with different heights");
        let new_data = layer1.pixels.iter().zip(layer2.pixels.iter())
            .map(|(val_a, val_b)| {
                ((((*val_a) as f32 / 255.0) * ((*val_b) as f32 / 255.0) * 255.0 + 0.5) as i32).clamp(0, 255)
            }).collect::<Vec<i32>>();
        ImageData { header_bytes: layer1.header_bytes.to_owned(), pixels: new_data, width: layer1.width, height: layer1.height }
    }
    /// Mutibly alters an image by multiplying it with another
    pub fn multiply_mut(&mut self, layer2: &ImageData){
        assert_eq!(self.width, layer2.width, "failed to multiply images with different widths");
        assert_eq!(self.height, layer2.height, "failed to multiply images with different heights");
        self.pixels.iter_mut().zip(layer2.pixels.iter()).for_each(
            |(val_a, val_b)| 
        {
            *val_a = ((((*val_a) as f32 / 255.0) * ((*val_b) as f32 / 255.0) * 255.0 + 0.5) as i32).clamp(0, 255)
        });
    }
    /// Subtracts layer1 from layer2 and returns the result
    pub fn subtract(layer1: &ImageData, layer2: &ImageData) -> ImageData{
        assert_eq!(layer1.width, layer2.width, "failed to subtract images with different widths");
        assert_eq!(layer1.height, layer2.height, "failed to subtract images with different heights");
        let new_data = layer1.pixels.iter().zip(layer2.pixels.iter())
            .map(|(val_a, val_b)| {
                (val_b-val_a).clamp(0, 255)
            }).collect::<Vec<i32>>();
        ImageData { header_bytes: layer1.header_bytes.to_owned(), pixels: new_data, width: layer1.width, height: layer1.height }
    }
    /// Multibly alters the image by subtracting it from another image
    pub fn subtract_mut(&mut self, layer2: &ImageData){
        assert_eq!(self.width, layer2.width, "failed to subtract images with different widths");
        assert_eq!(self.height, layer2.height, "failed to subtract images with different heights");
        self.pixels.iter_mut().zip(layer2.pixels.iter()).for_each(
            |(val_a, val_b)| 
        {
            *val_a = (*val_b-*val_a).clamp(0, 255);
        });
    }
    /// Combines two images using the screen algorithm and returns the result
    pub fn screen(layer1: &ImageData, layer2: &ImageData) -> ImageData{
        assert_eq!(layer1.width, layer2.width, "failed to screen images with different widths");
        assert_eq!(layer1.height, layer2.height, "failed to screen images with different heights");
        let new_data = layer1.pixels.iter().zip(layer2.pixels.iter())
            .map(|(val_a, val_b)| {
                ((
                    (1.0 - (1.0 - (*val_a) as f32 / 255.0) * (1.0 - (*val_b) as f32 / 255.0)) * 
                    255.0 + 0.5
                ) as i32).clamp(0, 255)
            }).collect::<Vec<i32>>();
        ImageData { header_bytes: layer1.header_bytes.to_owned(), pixels: new_data, width: layer1.width, height: layer1.height }
    }
    /// Mutibly alters an image by screening it with another image
    pub fn screen_mut(&mut self, layer2: &ImageData){
        assert_eq!(self.width, layer2.width, "failed to screen images with different widths");
        assert_eq!(self.height, layer2.height, "failed to screen images with different heights");
        self.pixels.iter_mut().zip(layer2.pixels.iter()).for_each(
            |(val_a, val_b)| 
        {
            *val_a = ((
                (1.0 - (1.0 - (*val_a) as f32 / 255.0) * (1.0 - (*val_b) as f32 / 255.0)) * 
                255.0 + 0.5
            ) as i32).clamp(0, 255);
        });
    }
    /// Overlays two images returning the result
    pub fn overlay(layer1: &ImageData, layer2: &ImageData) -> ImageData{
        assert_eq!(layer1.width, layer2.width, "failed to overlay images with different widths");
        assert_eq!(layer1.height, layer2.height, "failed to overlay images with different heights");
        let new_data = layer1.pixels.iter().zip(layer2.pixels.iter())
            .map(|(val_a, val_b)| {
                let a = (*val_a) as f32 / 255.0;
                let b = (*val_b) as f32 / 255.0;
                let c: f32;
                if b <= 0.5{
                    c = 2.0*a*b;
                }else{
                    c= 1.0 - 2.0*(1.0-a)*(1.0-b);
                }
                ((c*255.0 + 0.5) as i32).clamp(0, 255)
            }).collect::<Vec<i32>>();
        ImageData { header_bytes: layer1.header_bytes.to_owned(), pixels: new_data, width: layer1.width, height: layer1.height }
    }
    /// Mutibly alters the image by overlaying layer2 on top
    pub fn overlay_mut(&mut self, layer2: &ImageData){
        assert_eq!(self.width, layer2.width, "failed to overlay images with different widths");
        assert_eq!(self.height, layer2.height, "failed to overlay images with different heights");
        self.pixels.iter_mut().zip(layer2.pixels.iter()).for_each(
            |(val_a, val_b)| 
        {
            let a = (*val_a) as f32 / 255.0;
            let b = (*val_b) as f32 / 255.0;
            let c: f32;
            if b <= 0.5{
                c = 2.0*a*b;
            }else{
                c= 1.0 - 2.0*(1.0-a)*(1.0-b);
            }
            *val_a = ((c*255.0 + 0.5) as i32).clamp(0, 255);
        });
    }
    /// Adds a constant to a channel of the image, r, g, or b
    pub fn add_to_channel(&mut self, channel: usize, value: i32){
        assert!(channel == 0 || channel == 1 || channel == 2, "Invalid Channel");
        // go through the list 3 values at a time, skipping over values that dont correspond to our channel
        self.pixels.iter_mut().skip(channel).step_by(3).for_each(|pixel: &mut i32| {
            *pixel = (value+*pixel).clamp(0, 255);
        });
    }
    /// Scales a channel of the image, r, g, or b
    pub fn scale_channel(&mut self, channel: usize, value: f32){
        assert!(channel == 0 || channel == 1 || channel == 2, "Invalid Channel");
        // go through the list 3 values at a time, skipping over values that dont correspond to our channel
        self.pixels.iter_mut().skip(channel).step_by(3).for_each(|pixel: &mut i32| {
            *pixel = ((value*(*pixel) as f32 + 0.5) as i32).clamp(0, 255);
        });
    }
    /// Splits the image into 3 grayscale images of red, green, and blue components
    pub fn split_into_channels(&self) -> (ImageData, ImageData, ImageData){
        let mut r_pixels = vec![0i32; self.pixels.len()];
        let mut g_pixels = vec![0i32; self.pixels.len()];
        let mut b_pixels = vec![0i32; self.pixels.len()];
        for (i, value) in self.pixels.iter().enumerate(){
            if i%3==0 {b_pixels[i] = *value; b_pixels[i+1] = *value; b_pixels[i+2] = *value;}
            else if i%3 == 1 {g_pixels[i] = *value; g_pixels[i-1] = *value; g_pixels[i+1] = *value;}
            else {r_pixels[i] = *value; r_pixels[i-1] = *value; r_pixels[i-2] = *value;}
        }
        let r_image = ImageData{pixels: r_pixels, header_bytes: self.header_bytes.to_owned(), width: self.width, height: self.height};
        let g_image = ImageData{pixels: g_pixels, header_bytes: self.header_bytes.to_owned(), width: self.width, height: self.height};
        let b_image = ImageData{pixels: b_pixels, header_bytes: self.header_bytes.to_owned(), width: self.width, height: self.height};
        (r_image, g_image, b_image)
    }
    /// Rotates an image by 180 degrees
    /// This equates to swapping the first and last pixel, second and second last, and so on.
    pub fn rotate_180(&mut self){
        for i in 0..(self.pixels.len()/2){
            let temp = self.pixels[i];
            let j = self.pixels.len()-1-i;
            self.pixels[i] = self.pixels[j];
            self.pixels[j] = temp;
        }
        for i in 0..self.pixels.len()/3{
            let temp = self.pixels[i*3];
            self.pixels[i*3] = self.pixels[i*3+2];
            self.pixels[i*3+2] = temp;
        }
    }
}
/// Creates an image treating the tuple of images as seperate red, green, and blue channels
impl From<(&ImageData, &ImageData, &ImageData)> for ImageData{
    fn from(value: (&ImageData, &ImageData, &ImageData)) -> Self {
        let mut pixels: Vec<i32> = vec![0i32; value.0.pixels.len()];
        for i in 0..value.0.pixels.len(){
            if i % 3 == 0{
                pixels[i] = value.2.pixels[i];
            }
            if i % 3 == 1{
                pixels[i] = value.1.pixels[i];
            }
            if i % 3 == 2{
                pixels[i] = value.0.pixels[i];
            }
        }
        ImageData { header_bytes: value.0.header_bytes.to_owned(), pixels, width: value.0.width, height: value.0.height }
    }
}
/// Creates an image from a string, assumes the string is a path to a tga file
impl From<&str> for ImageData{
    fn from(path: &str) -> Self {
        let file = File::open(path).expect("Couldn't read file");
        let mut reader = BufReader::new(file);
        let mut bytes: Vec<u8> = vec![];
        reader.read_to_end(&mut bytes).expect("Coulnd't read Bytes");
        let header_bytes: Vec<u8> = bytes[0..18].to_vec();
        // Bit shifts to get width and height
        let width: usize = ((header_bytes[13] as u16)<<8 | (header_bytes[12] as u16)) as usize;
        let height: usize = ((header_bytes[15] as u16)<<8 | (header_bytes[14] as u16)) as usize;
        let mut pixel_bytes = bytes[18..].to_vec();
        reader.read_to_end(&mut pixel_bytes).expect("Couldn't read pixel data");
        let pixels = pixel_bytes
            .iter().map(|byte| (*byte) as i32).collect_vec();
        ImageData { header_bytes, pixels, width, height }
    }
}
/// First task: multiply layer1 and pattern1
pub fn task_1(){
    let start = std::time::Instant::now();
    let mut layer1 = ImageData::from("input/layer1.tga");
    let pattern1 = ImageData::from("input/pattern1.tga");
    layer1.multiply_mut(&pattern1);
    layer1.write_to("output/part1.tga");
    let end = std::time::Instant::now();
    println!("Finished task 1 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 2: Subtract layer2 from car
pub fn task_2(){
    let start = std::time::Instant::now();
    let mut layer2 = ImageData::from("input/layer2.tga");
    let car = ImageData::from("input/car.tga");
    layer2.subtract_mut(&car);
    layer2.write_to("output/part2.tga");
    let end = std::time::Instant::now();
    println!("Finished task 2 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 3: Multiply layer1 and pattern2, then screen with text
pub fn task_3(){
    let start = std::time::Instant::now();
    let layer1 = ImageData::from("input/layer1.tga");
    let pattern2 = ImageData::from("input/pattern2.tga");
    let mut text = ImageData::from("input/text.tga");
    text.screen_mut(&ImageData::multiply(&layer1, &pattern2));
    text.write_to("output/part3.tga");
    let end = std::time::Instant::now();
    println!("Finished task 3 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 4: multiply layer2 and circles, then subtract pattern2
pub fn task_4(){
    let start = std::time::Instant::now();
    let layer2 = ImageData::from("input/layer2.tga");
    let circles = ImageData::from("input/circles.tga");
    let mut pattern2 = ImageData::from("input/pattern2.tga");
    pattern2.subtract_mut(&ImageData::multiply(&layer2, &circles));
    pattern2.write_to("output/part4.tga");
    let end = std::time::Instant::now();
    println!("Finished task 4 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 5: Overlay pattern1 over layer1
pub fn task_5(){
    let start = std::time::Instant::now();
    let mut layer1 = ImageData::from("input/layer1.tga");
    let pattern1 = ImageData::from("input/pattern1.tga");
    layer1.overlay_mut(&pattern1);
    layer1.write_to("output/part5.tga");
    let end = std::time::Instant::now();
    println!("Finished task 5 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 6: add 200 to the green channel of car
pub fn task_6(){
    let start = std::time::Instant::now();
    let mut car = ImageData::from("input/car.tga");
    car.add_to_channel(1, 200);
    car.write_to("output/part6.tga");
    let end = std::time::Instant::now();
    println!("Finished task 6 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 7: scale the blue channel to 0 and red channel by 4 of car
pub fn task_7(){
    let start = std::time::Instant::now();
    let mut car = ImageData::from("input/car.tga");
    car.scale_channel(0, 0.0);
    car.scale_channel(2, 4.0);
    car.write_to("output/part7.tga");
    let end = std::time::Instant::now();
    println!("Finished task 7 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 8: Split car into r, g, and b component
pub fn task_8(){
    let start = std::time::Instant::now();
    let car: ImageData = ImageData::from("input/car.tga");
    let (r, g, b) = car.split_into_channels();
    r.write_to("output/part8_r.tga");
    g.write_to("output/part8_g.tga");
    b.write_to("output/part8_b.tga");
    let end = std::time::Instant::now();
    println!("Finished task 8 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 9: combine r, g, and b components into one image
pub fn task_9(){
    let start = std::time::Instant::now();
    let r = ImageData::from("input/layer_red.tga");
    let g = ImageData::from("input/layer_green.tga");
    let b = ImageData::from("input/layer_blue.tga");
    let combined = ImageData::from((&r, &g, &b));
    combined.write_to("output/part9.tga");
    let end = std::time::Instant::now();
    println!("Finished task 9 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Task 10: rotate text2 by 180 degrees
pub fn task_10(){
    let start = std::time::Instant::now();
    let mut text2 = ImageData::from("input/text2.tga");
    text2.rotate_180();
    text2.write_to("output/part10.tga");
    let end = std::time::Instant::now();
    println!("Finished task 10 in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Combine 4 images into one big image
pub fn extra_credit(){
    let start = std::time::Instant::now();
    let car = ImageData::from("input/car.tga");
    let pattern1 = ImageData::from("input/pattern1.tga");
    let circles = ImageData::from("input/circles.tga");
    let text = ImageData::from("input/text.tga");
    let new_width = car.width + circles.width;
    let new_height = car.height + text.height;
    let mut new_header = car.header_bytes.to_owned();
    new_header[12] = (((new_width as u16) << 8) >> 8) as u8;
    new_header[13] = ((new_width as u16) >> 8) as u8;
    new_header[14] = (((new_height as u16) << 8) >> 8) as u8;
    new_header[15] = ((new_height as u16) >> 8) as u8;
    let new_pixels = text.pixels.chunks(3*text.width)
        .zip(pattern1.pixels.chunks(3*pattern1.width))
        .map(|(text_row, pattern_row)| {
            text_row.iter().chain(pattern_row.iter())
        }).chain(
            car.pixels.chunks(3*car.width).zip(circles.pixels.chunks(3*circles.width))
            .map(|(car_row, circle_row)| {
                car_row.iter().chain(circle_row.iter())
            })
        ).flatten().map(|val| *val).collect::<Vec<i32>>();
    let output = ImageData{
        pixels: new_pixels, 
        header_bytes: new_header, 
        width: new_width, 
        height: new_height
    };
    output.write_to("output/extracredit.tga");
    let end = std::time::Instant::now();
    println!("Finished extra credit in: {} milliseconds", end.duration_since(start).as_millis());
}
/// Main app, runs each task, times them, and pauses
fn main() {
    let _ = fs::create_dir("output/").is_err();
    let start = std::time::Instant::now();
    task_1();
    task_2();
    task_3();
    task_4();
    task_5();
    task_6();
    task_7();
    task_8();
    task_9();
    task_10();
    extra_credit();
    let end = std::time::Instant::now();
    println!("Finished all tasks in: {} milliseconds", end.duration_since(start).as_millis());
    println!("Press Enter to Exit...");
    stdin().read(&mut[0]).unwrap();
}

/// Tests used to ensure each task works
/// They each read in the tasks output, and the example output
/// it then makes sure the files match
/// Run with cargo test
#[cfg(test)]
mod test{
    use std::fs;

    use crate::ImageData;

    #[test]
    fn task_1(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_1();
        let our_image = ImageData::from("output/part1.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part1.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 1 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 1 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 1 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 1 failed! Headers are different");
    }

    #[test]
    fn task_2(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_2();
        let our_image = ImageData::from("output/part2.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part2.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 2 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 2 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 2 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 2 failed! Headers are different");
    }

    #[test]
    fn task_3(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_3();
        let our_image = ImageData::from("output/part3.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part3.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 3 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 3 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 3 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 3 failed! Headers are different");
    }
    
    #[test]
    fn task_4(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_4();
        let our_image = ImageData::from("output/part4.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part4.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 4 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 4 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 4 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 4 failed! Headers are different");
    }
    
    #[test]
    fn task_5(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_5();
        let our_image = ImageData::from("output/part5.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part5.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 5 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 5 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 5 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 5 failed! Headers are different");
    }
    
    #[test]
    fn task_6(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_6();
        let our_image = ImageData::from("output/part6.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part6.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 6 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 6 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 6 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 6 failed! Headers are different");
    }
    
    #[test]
    fn task_7(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_7();
        let our_image = ImageData::from("output/part7.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part7.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 7 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 7 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 7 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 7 failed! Headers are different");
    }
    
    #[test]
    fn task_8(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_8();
        let our_image = ImageData::from("output/part8_r.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part8_r.tga");
        let pixel_test = our_image.pixels == test_image.pixels;
        assert!(pixel_test, "Task 8 failed! Red Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 8 failed! Red Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 8 failed! Red Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 8 failed! Red Headers are different");
        let our_image = ImageData::from("output/part8_g.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part8_g.tga");
        let pixel_test = our_image.pixels == test_image.pixels;
        assert!(pixel_test, "Task 8 failed! Green Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 8 failed! Green Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 8 failed! Green Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 8 failed! Green Headers are different");
        let our_image = ImageData::from("output/part8_b.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part8_b.tga");
        let pixel_test = our_image.pixels == test_image.pixels;
        assert!(pixel_test, "Task 8 failed! Blue Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 8 failed! Blue Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 8 failed! Blue Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 8 failed! Blue Headers are different");
    }
    
    #[test]
    fn task_9(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_9();
        let our_image = ImageData::from("output/part9.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part9.tga");
        assert_eq!(our_image.pixels, test_image.pixels, "Task 9 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 9 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 9 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 9 failed! Headers are different");
    }
    
    #[test]
    fn task_10(){
        let _ = fs::create_dir("output/").is_err();
        crate::task_10();
        let our_image = ImageData::from("output/part10.tga");
        let test_image = ImageData::from("examples/EXAMPLE_part10.tga");
        let pixel_test = our_image.pixels == test_image.pixels;
        assert!(pixel_test, "Task 10 failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "Task 10 failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "Task 10 failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "Task 10 failed! Headers are different");
    }

    #[test]
    fn extra_credit(){
        let _ = fs::create_dir("output/").is_err();
        crate::extra_credit();
        let our_image = ImageData::from("output/extracredit.tga");
        let test_image = ImageData::from("examples/EXAMPLE_extracredit.tga");
        let pixel_test = our_image.pixels == test_image.pixels;
        assert!(pixel_test, "ExtraCredit failed! Pixels are different");
        assert_eq!(our_image.width, test_image.width, "ExtraCredit failed! Widths are different");
        assert_eq!(our_image.height, test_image.height, "ExtraCredit failed! Heights are different");
        assert_eq!(our_image.header_bytes, test_image.header_bytes, "ExtraCredit failed! Headers are different");
    }
}
