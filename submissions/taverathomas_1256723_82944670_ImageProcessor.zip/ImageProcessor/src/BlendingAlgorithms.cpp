
#include "BlendingAlgorithms.h"
#include "cmath" // For rounding purposes

// Function to blend two images using Multiply algorithm
std::vector<unsigned char> multiply(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer)
{
    // Initializes resulting pixel data
    std::vector<unsigned char> resultingData(topLayer.size());

    for (size_t i = 0; i < topLayer.size(); i++) // size_t --> unsigned int type; good practice for container indexing. Source: https://en.cppreference.com/w/cpp/types/size_t
        resultingData[i] = (unsigned char)round(((float)topLayer[i] * (float)bottomLayer[i]) / 255.0);
    return resultingData;
}

// Function to blend two images using Subtract algorithm
std::vector<unsigned char> subtract(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer)
{
    std::vector<unsigned char> resultingData(topLayer.size());

    for (size_t i = 0; i < topLayer.size(); i++)
    {
        int value = static_cast<int>(bottomLayer[i]) - static_cast<int>(topLayer[i]);  // static_cast = converts the unsigned char into an int in order to subtract the two values. Source: https://www.geeksforgeeks.org/static_cast-in-cpp/
        resultingData[i] = static_cast<unsigned char>(value < 0 ? 0 : value); // Limits value to zero
        // After getting the result I use static_cast again to convert it back to an unsigned char
    }
    return resultingData;
}

// Function to blend two images using Screen algorithm
std::vector<unsigned char> screen(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer)
{
    std::vector<unsigned char> resultingData(topLayer.size());

    for (size_t i = 0; i < topLayer.size(); i++)
        resultingData[i] = (unsigned char)round((float)255 - ((float)(255 - topLayer[i]) * (float)(255 - bottomLayer[i]) / 255.0));
    return resultingData;
}

// Function to blend two images together using overlay algorithm
std::vector<unsigned char> overlay(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer)
{
    std::vector<unsigned char> resultingData(topLayer.size());

    for (size_t i = 0; i < topLayer.size(); i++)
    {
        if (bottomLayer[i] < 128)
            resultingData[i] = (unsigned char)(round((2 * (float)topLayer[i] * (float)bottomLayer[i]) / 255));
        else
            resultingData[i] = (unsigned char)(round(255 - (2 * (255 - (float)topLayer[i]) * (255 - (float)bottomLayer[i])) / 255));
    }
    return resultingData;
}

// Function that increases green intensity
void addGreen(std::vector<unsigned char>& pixelData)
{
    // Iterate over the pixel data but only affects green channel since we start at index 1 and increment by 3
    for (size_t i = 1; i < pixelData.size(); i += 3)
        // Checks to see if the value will exceed 255, if it does it set the value to 255
        pixelData[i] = std::min(static_cast<int>(pixelData[i] + 200), static_cast<int>(255));
    // std::min --> returns the smaller of the two values,
    // if the current value + 200 is > 255 then it returns 255.
    // Source: https://en.cppreference.com/w/cpp/algorithm/min//
}

// Function that increases red intensity and negates blue intensity
void increaseRedNegateBlue(std::vector<unsigned char>& pixelData)
{
    // Iterate over the pixel data but only affects red channel since we start at index 2 and increment by 3
    for (size_t i = 2; i < pixelData.size(); i += 3)
        // Checks to see if the value will exceed 255, if it does it set the value to 255
        pixelData[i] = std::min(static_cast<int>(pixelData[i] * 4), static_cast<int>(255));
    // Iterate over the pixel data but only affects blue channel since we start at index 0 and increment by 3
    for (size_t i = 0; i < pixelData.size(); i += 3)
        pixelData[i] = pixelData[i] * 0;
}

// Function to rotate the image by 180 degrees
void rotate180(std::vector<unsigned char>& pixelData, const Header& header)
{
    // Vector holding rotated image data
    std::vector<unsigned char> rotatedImageData(pixelData.size());

    // Calculate the size of each row in bytes
    size_t rowSize = header.width * 3;

    // Reversing the order of the data in order to iterate through it
    for (int y = 0; y < header.height; y++)
    {
        for (int x = 0; x < header.width; x++)
        {
            // Calculate the index in the original image; current height index * current width index * row Size * 3(RGB)
            size_t originalIndex = y * rowSize + x * 3;
            // Calculate the index in the rotated image
            size_t rotatedIndex = (header.height - 1 - y) * rowSize + (header.width - 1 - x) * 3;

            // Copying the rotated image data at the rotated index (plus iterator) with the pixel data at the original index (plus iterator)
            for (int i = 0; i < 3; i++)
                rotatedImageData[rotatedIndex + i] = pixelData[originalIndex + i];
        }
    }
    // Iterating over the data and setting the pixel data equal to the rotated data
    for (int i = 0; i < pixelData.size(); i++)
        pixelData[i] = rotatedImageData[i];
}
