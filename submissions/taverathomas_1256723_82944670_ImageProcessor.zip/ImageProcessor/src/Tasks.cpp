
#include "Tasks.h"

// Testing function that checks if the two files are the same
bool testing(std::string fileName, std::string examplePath)
{
    // Loading output image header and pixel data
    std::ifstream inStream(fileName, std::ios::binary);
    Header header = readHeader(inStream);
    std::vector<unsigned char> imageOne;
    loadPixels(inStream, imageOne, header);

    // Loading correct image header and pixel data
    std::ifstream correctFile(examplePath, std::ios::binary);
    Header correctHeader = readHeader(correctFile);
    std::vector<unsigned char> imageTwo;
    loadPixels(correctFile, imageTwo, correctHeader);

    // Closing files
    inStream.close();
    correctFile.close();

    // Comparing content
    for (size_t i = 0; i < imageOne.size(); i++)
    {
        if (imageOne[i] != imageTwo[i])
            return false;
    }
    return true;
}

// Task 1: Blending “layer1.tga” (top layer) with “pattern1.tga” (bottom layer) using multiply blending algorithm
void taskOne()
{
    // Loading “layer1.tga” header and pixel data
    std::vector<unsigned char> layer1Pixels;
    Header layer1Header{};
    loadImageData("input/layer1.tga", layer1Pixels, layer1Header);

    // Loading “pattern1.tga” header and pixel data
    std::vector<unsigned char> pattern1Pixels;
    Header pattern1Header{};
    loadImageData("input/pattern1.tga", pattern1Pixels, pattern1Header);

    // Blending both using multiply algorithm and storing the new pixels in a new vector
    std::vector<unsigned char> newData = multiply(layer1Pixels, pattern1Pixels);

    // Write the blended image to the output file
    std::ofstream outputFile("output/part1.tga", std::ios::binary);
    writeOutput(outputFile, layer1Header, newData);
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part1.tga", "examples/EXAMPLE_part1.tga"))
        std::cout << "Task One Completed!" << std::endl;
    else
        std::cout << "Task One Failed!" << std::endl;
}

// Task 2: Blending “layer2.tga” (top layer) with “car.tga” (bottom layer) using subtract blending algorithm
void taskTwo()
{
    // Loading “layer2.tga” header and pixel data
    std::vector<unsigned char> layer2Pixels;
    Header layer2Header{};
    loadImageData("input/layer2.tga", layer2Pixels, layer2Header);

    // Loading “car.tga” header and pixel data
    std::vector<unsigned char> carPixels;
    Header carHeader{};
    loadImageData("input/car.tga", carPixels, carHeader);

    // Blending both using subtract algorithm and storing the new pixels in a new vector
    std::vector<unsigned char> newData = subtract(layer2Pixels, carPixels);

    // Write the blended image to the output file
    std::ofstream outputFile("output/part2.tga", std::ios::binary);
    writeOutput(outputFile, layer2Header, newData);
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part2.tga", "examples/EXAMPLE_part2.tga"))
        std::cout << "Task Two Completed!" << std::endl;
    else
        std::cout << "Task Two Failed!" << std::endl;
}

// Task 3: Blends “layer1.tga” with “pattern2.tga” using multiply algorithm and then blends “text.tga” with (layer1 & pattern2 result) using the screen blending algorithm.
void taskThree()
{
    // Loading “layer1.tga” header and pixel data
    std::vector<unsigned char> layer1Pixels;
    Header layer1Header{};
    loadImageData("input/layer1.tga", layer1Pixels, layer1Header);

    // Loading “pattern2.tga” header and pixel data
    std::vector<unsigned char> pattern2Pixels;
    Header pattern2Header{};
    loadImageData("input/pattern2.tga", pattern2Pixels, pattern2Header);

    // Loading “text.tga” header and pixel data
    std::vector<unsigned char> textPixels;
    Header textHeader{};
    loadImageData("input/text.tga", textPixels, textHeader);

    // Blending layer1 with pattern2 using multiply algorithm and storing the new pixels in a temporary vector
    std::vector<unsigned char> tempData = multiply(layer1Pixels, pattern2Pixels);

    // Blending tempData using screen algorithm and storing the new pixels in a new vector
    std::vector<unsigned char> newData = screen(tempData, textPixels);

    // Save the final result to a new TGA file
    std::ofstream outputFile("output/part3.tga", std::ios::binary);
    writeOutput(outputFile, layer1Header, newData);
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part3.tga", "examples/EXAMPLE_part3.tga"))
        std::cout << "Task Three Completed!" << std::endl;
    else
        std::cout << "Task Three Failed!" << std::endl;
}

// Task 4: Blends “layer2.tga” with “circles.tga” using multiply algorithm. Then blends “pattern2.tga” using that as the top layer, with the previous result using the subtract algorithm
void taskFour()
{
    // Loading “layer2.tga” header and pixel data
    std::vector<unsigned char> layer2Pixels;
    Header layer2Header{};
    loadImageData("input/layer2.tga", layer2Pixels, layer2Header);

    // Loading “circles.tga” header and pixel data
    std::vector<unsigned char> circlesPixels;
    Header circlesHeader{};
    loadImageData("input/circles.tga", circlesPixels, circlesHeader);

    // Loading “pattern2.tga” header and pixel data
    std::vector<unsigned char> pattern2Pixels;
    Header pattern2Header{};
    loadImageData("input/pattern2.tga", pattern2Pixels, pattern2Header);

    // Blending layer2 with circles using multiply algorithm and storing the new pixels in a temporary vector
    std::vector<unsigned char> tempData = multiply(layer2Pixels, circlesPixels);

    // Blending tempData with pattern2 using subtract algorithm and storing the new pixels in a new vector
    std::vector<unsigned char> newData = subtract(pattern2Pixels, tempData);

    // Write the blended image to the output file
    std::ofstream outputFile("output/part4.tga", std::ios::binary);
    writeOutput(outputFile, pattern2Header, newData);
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part4.tga", "examples/EXAMPLE_part4.tga"))
        std::cout << "Task Four Completed!" << std::endl;
    else
        std::cout << "Task Four Failed!" << std::endl;
}

// Task 5: Blending “layer1.tga” (top layer) with “pattern1.tga” (bottom layer) using overlay blending algorithm
void taskFive()
{
    // Loading “layer1.tga” header and pixel data
    std::vector<unsigned char> layer1Pixels;
    Header layer1Header{};
    loadImageData("input/layer1.tga", layer1Pixels, layer1Header);

    // Loading “pattern1.tga” header and pixel data
    std::vector<unsigned char> pattern1Pixels;
    Header pattern1Header{};
    loadImageData("input/pattern1.tga", pattern1Pixels, pattern1Header);

    // Blending both using overlay algorithm and storing the new pixels in a new vector
    std::vector<unsigned char> newData = overlay(layer1Pixels, pattern1Pixels);

    // Write the blended image to the output file
    std::ofstream outputFile("output/part5.tga", std::ios::binary);
    writeOutput(outputFile, layer1Header, newData);
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part5.tga", "examples/EXAMPLE_part5.tga"))
        std::cout << "Task Five Completed!" << std::endl;
    else
        std::cout << "Task Five Failed!" << std::endl;
}

// Task 6: Load “car.tga” and adds 200 to the green channel
void taskSix()
{
    // Loading “car.tga” header and pixel data
    std::vector<unsigned char> carPixels;
    Header carHeader{};
    loadImageData("input/car.tga", carPixels, carHeader);

    // Increasing green intensity using addGreen() function
    addGreen(carPixels);

    // Write the blended image to the output file
    std::ofstream outputFile("output/part6.tga", std::ios::binary);
    writeOutput(outputFile, carHeader, carPixels);
    //outputFile.write(reinterpret_cast<char*>(carPixels.data()), carPixels.size());
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part6.tga", "examples/EXAMPLE_part6.tga"))
        std::cout << "Task Six Completed!" << std::endl;
    else
        std::cout << "Task Six Failed!" << std::endl;
}

// Task 7: Load “car.tga” and multiply the red channel by 4, and the blue channel by 0, increasing red intensity, while negating any blue it may have.
void taskSeven()
{
    // Loading “car.tga” header and pixel data
    std::vector<unsigned char> carPixels;
    Header carHeader{};
    loadImageData("input/car.tga", carPixels, carHeader);

    // Increasing red intensity and negating blue using increaseRedNegateBlue() function
    increaseRedNegateBlue(carPixels);

    // Write the blended image to the output file
    std::ofstream outputFile("output/part7.tga", std::ios::binary);
    writeOutput(outputFile, carHeader, carPixels);
    outputFile.close();

    // Tests to see if the images are the same
    if (testing("output/part7.tga", "examples/EXAMPLE_part7.tga"))
        std::cout << "Task Seven Completed!" << std::endl;
    else
        std::cout << "Task Seven Failed!" << std::endl;
}

// Task 8: Load “car.tga” and writes each channel into a separate file
void taskEight()
{
    // Loading “car.tga” header and pixel data
    std::ifstream carFile("input/car.tga", std::ios::binary);
    std::vector<unsigned char> carPixels;
    Header carHeader = readHeader(carFile);
    loadPixels(carFile, carPixels, carHeader);

    // Creating the separate color channels
    std::vector<unsigned char> redChannel, greenChannel, blueChannel;
    diffChannels(carPixels, redChannel, greenChannel, blueChannel);

    // Creating the separate filled color channels
    std::vector<unsigned char> redImagePixels, blueImagePixels, greenImagePixels;
    redImagePixels = fillChannel(redChannel);
    blueImagePixels = fillChannel(blueChannel);
    greenImagePixels = fillChannel(greenChannel);

    // Loading channel data
    loadPixels(carFile, redImagePixels, carHeader);
    loadPixels(carFile, blueImagePixels, carHeader);
    loadPixels(carFile, greenImagePixels, carHeader);

    // Initializing the output files that are going to be written to
    std::ofstream outputFileRed("output/part8_r.tga", std::ios::binary);
    std::ofstream outputFileBlue("output/part8_b.tga", std::ios::binary);
    std::ofstream outputFileGreen("output/part8_g.tga", std::ios::binary);

    // Writing the color channels to the output file
    writeOutput(outputFileRed, carHeader, redImagePixels);
    writeOutput(outputFileBlue, carHeader, blueImagePixels);
    writeOutput(outputFileGreen, carHeader, greenImagePixels);

    // Closing files
    outputFileRed.close();
    outputFileGreen.close();
    outputFileBlue.close();

    // Tests to see if the images are the same
    if (testing("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga")
    and testing("output/part8_b.tga", "examples/EXAMPLE_part8_b.tga")
    and testing("output/part8_g.tga", "examples/EXAMPLE_part8_g.tga"))
        std::cout << "Task Eight Completed!" << std::endl;
    else
        std::cout << "Task Eight Failed!" << std::endl;
}

// Task 9: Loads “layer_red.tga”, “layer_green.tga” and “layer_blue.tga”, and combine the three files into one file.
// Layer_red is the red channel, etc...
void taskNine()
{
    // Loading “layer_red.tga” header and pixel data
    std::vector<unsigned char> redChannel;
    Header redHeader{};
    loadImageData("input/layer_red.tga", redChannel, redHeader);

    // Loading “layer_green.tga” header and pixel data
    std::vector<unsigned char> greenChannel;
    Header greenHeader{};
    loadImageData("input/layer_green.tga", greenChannel, greenHeader);

    // Loading “layer_blue.tga” header and pixel data
    std::vector<unsigned char> blueChannel;
    Header blueHeader{};
    loadImageData("input/layer_blue.tga", blueChannel, blueHeader);

    // Combine channels
    std::vector<unsigned char> combinedPixels;
    combineChannels(redChannel, greenChannel, blueChannel, combinedPixels);

    // Write the combined image to the output file
    std::ofstream outputFile("output/part9.tga", std::ios::binary);
    writeOutput(outputFile, redHeader, combinedPixels);

    // Tests to see if the images are the same
    if (testing("output/part9.tga", "examples/EXAMPLE_part9.tga"))
        std::cout << "Task Nine Completed!" << std::endl;
    else
        std::cout << "Task Nine Failed!" << std::endl;
}

// Task 10: Loads “text2.tga”, and rotates it 180 degrees
void taskTen()
{
    // Loading “text2.tga” header and pixel data
    std::vector<unsigned char> text2Pixels;
    Header text2Header{};
    loadImageData("input/text2.tga", text2Pixels, text2Header);

    // Rotate the image by 180 degrees using Rotate180() function and then stores image data in a vector
    rotate180(text2Pixels, text2Header);

    // Write the rotated image to the output file
    std::ofstream outputFile("output/part10.tga", std::ios::binary);
    writeOutput(outputFile, text2Header, text2Pixels);

    // Tests to see if the images are the same
    if (testing("output/part10.tga", "examples/EXAMPLE_part10.tga"))
        std::cout << "Task Ten Completed!" << std::endl;
    else
        std::cout << "Task Ten Failed!" << std::endl;
    // I TRIED TO SOLVE TASK TEN BUT IT KEPT ON SAYING THAT THE IMAGE WASN'T THE SAME,
    // THEY LOOK IDENTICAL BUT I WASN'T ABLE TO FIGURE OUT WHY THE IMAGE DATA WASN'T THE SAME
}
