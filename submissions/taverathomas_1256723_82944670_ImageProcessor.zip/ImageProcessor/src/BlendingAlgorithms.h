
#include "ImageData.h"
#pragma once

// Functions that have to do with blending algorithms: multiplying, subtracting, screening, etc...

// Multiply algorithm
std::vector<unsigned char> multiply(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer);

// Subtract algorithm
std::vector<unsigned char> subtract(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer);

// Screening algorithm
std::vector<unsigned char> screen(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer);

// Overlay algorithm
std::vector<unsigned char> overlay(std::vector<unsigned char>& topLayer, const std::vector<unsigned char>& bottomLayer);

// Increasing green value algorithm
void addGreen(std::vector<unsigned char>& pixelData);

// Increasing red value and decreasing blue value algorithm
void increaseRedNegateBlue(std::vector<unsigned char>& pixelData);

// Rotating the angle algorithm
void rotate180(std::vector<unsigned char>& pixelData, const Header& header);




