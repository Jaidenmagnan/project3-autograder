
#include "TGA File.h"
#pragma once

// Functions that have to do with image properties: reading headers; loading pixels, channels; combining channels

// Reading header
Header readHeader(std::ifstream &inStream);

// Loading pixels
void loadPixels(std::ifstream& inStream, std::vector<unsigned char>& pixels, const Header& header);

// Loading specific color channels
void loadImageData(const std::string& filename, std::vector<unsigned char>& pixels, Header& header);

// Combining the RGB channels into a vector of unsigned char
void combineChannels(const std::vector<unsigned char>& redChannel,
                     const std::vector<unsigned char>& greenChannel,
                     const std::vector<unsigned char>& blueChannel,
                     std::vector<unsigned char>& combinedPixels);

// Gets separate color channels
void diffChannels(std::vector<unsigned char>& pixelData,
                  std::vector<unsigned char>& redChannel,
                  std::vector<unsigned char>& greenChannel,
                  std::vector<unsigned char>& blueChannel);

// Fills the separate color channels
std::vector<unsigned char> fillChannel(std::vector<unsigned char> &channel);

// Writing image data into a new file
void writeOutput(std::ofstream& outStream, const Header& header, const std::vector<unsigned char>& pixels);


