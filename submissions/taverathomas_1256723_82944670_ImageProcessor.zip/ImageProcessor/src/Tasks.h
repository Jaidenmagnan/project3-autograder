
#include "BlendingAlgorithms.h"
#pragma once

// Testing Function
bool testing(std::string fileName, std::string examplePath);

// Individual functions for the tasks specified
void taskOne();
void taskTwo();
void taskThree();
void taskFour();
void taskFive();
void taskSix();
void taskSeven();
void taskEight();
void taskNine();
void taskTen();
