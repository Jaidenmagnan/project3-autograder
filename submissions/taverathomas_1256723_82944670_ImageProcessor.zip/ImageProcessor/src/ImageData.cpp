
#include "ImageData.h"

// Function to read header information from a tga file
Header readHeader(std::ifstream &inStream)
{
    Header header{};
    // reinterpret_cast<char*>(&header) --> This casts the header address to a char pointer (char*) so I can use inStream.read(). Source: https://cplusplus.com/reference/istream/istream/read/
    inStream.read(reinterpret_cast<char *>(&header), sizeof(header));
    return header;
}

// Function to load pixel data from the input file
void loadPixels(std::ifstream &inStream, std::vector<unsigned char> &pixels, const Header &header)
{
    // Allocating space to store pixel data (w * h * 3 = rgb) and then reads the data
    pixels.resize(header.width * header.height * 3);
    inStream.read(reinterpret_cast<char *>(pixels.data()), pixels.size());
}

// Load pixel data from a TGA file into a vector
void loadImageData(const std::string &filename, std::vector<unsigned char> &pixels, Header &header)
{
    std::ifstream inStream(filename, std::ios::binary);
    header = readHeader(inStream);
    loadPixels(inStream, pixels, header);
    inStream.close();
}

// Function to combine three channels into one image
void combineChannels(const std::vector<unsigned char> &redChannel, const std::vector<unsigned char> &greenChannel,
                     const std::vector<unsigned char> &blueChannel, std::vector<unsigned char> &combinedPixels)
{
    // Sets the image data vector equal to the channel's size times 3
    combinedPixels.resize(redChannel.size() * 3);

    // Iterates over red channel and sets the value of the image data (RGB) values
    // Red channel is the index plus 2 since it is the third index in RGB
    // Green channel is the index plus 1 since it is the second index in RGB
    // Blue channel is the index itself
    for (size_t i = 0, j = 0; i < redChannel.size(); i += 3, j += 3)
    {
        combinedPixels[j + 2] = redChannel[i + 2];
        combinedPixels[j + 1] = greenChannel[i + 1];
        combinedPixels[j] = blueChannel[i];
    }
}

// Function to fill color channel
std::vector<unsigned char> fillChannel(std::vector<unsigned char> &channel)
{
    // Initializes vector that is going to hold the full data and resizes it to a channel size times 3
    std::vector<unsigned char> filledData;
    filledData.resize(channel.size() * 3);

    // Iterates over a channel and sets the value of the other channels to that of the current channel to get a gray image
    for (size_t i = 0, j = 0; i < channel.size(); j+= 3, i++)
    {
        filledData[j + 2] = channel[i];
        filledData[j + 1] = channel[i];
        filledData[j] = channel[i];
    }
    return filledData;
}

// Function that separates each channel into a separate vector
void diffChannels(std::vector<unsigned char> &pixelData, std::vector<unsigned char> &redChannel,
                  std::vector<unsigned char> &greenChannel, std::vector<unsigned char> &blueChannel)
{
    // Iterates over pixel data and appends values to respective channel vector data
    for (size_t i = 0; i < pixelData.size(); i += 3)
    {
        redChannel.push_back(pixelData[i + 2]);
        greenChannel.push_back(pixelData[i + 1]);
        blueChannel.push_back(pixelData[i]);
    }
}

// Function that writes the TGA header and pixel data to the specified output file
void writeOutput(std::ofstream &outStream, const Header &header, const std::vector<unsigned char> &pixels)
{
    outStream.write(reinterpret_cast<const char *>(&header), sizeof(header));
    outStream.write(reinterpret_cast<const char *>(pixels.data()), pixels.size());
}