
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm> // For use in std::reverse_copy
#pragma once

// Header Structure - Wasn't working until I used #pragma pack,
// discovered #pragma pack from 'Cenoc' on Stack Overflow.
// Source: https://stackoverflow.com/questions/3318410/pragma-pack-effect

#pragma pack(push, 1)
struct Header
{
    char  idLength;
    char  colorMapType;
    char  dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char  colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char  bitsPerPixel;
    char  imageDescriptor;
};
#pragma pack(pop)
