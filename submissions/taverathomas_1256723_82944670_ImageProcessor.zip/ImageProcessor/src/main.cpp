
#include "TGA File.h"
#include "ImageData.h"
#include "BlendingAlgorithms.h"
#include "Tasks.h"

// Calls all the tasks to be run from the main function
int main()
{
    taskOne();
    taskTwo();
    taskThree();
    taskFour();
    taskFive();
    taskSix();
    taskSeven();
    taskEight();
    taskNine();
    taskTen();
    return 0;
}


