use std::{fs, fs::File};
use std::io::{BufReader, Read, Write, self};

fn multiply(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8> {     //multiplying layers and return a vector
    let mut result: Vec<u8> = Vec::new();
    let num_pixel: usize = top_layer.len();
    for i in 0..num_pixel {
        let idx: usize = i as usize;
        let top_pixel: f32 = top_layer[idx] as f32;
        let bottom_pixel: f32 = bottom_layer[idx] as f32;
        let mut new_pixel: f32 = top_pixel * bottom_pixel / 255.0;

        //rounding up the pixel
        new_pixel += 0.5;

        result.push(new_pixel as u8);
    }
    return result;
}

fn screen(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8> {   //screen the image data and return a vector
    let mut result: Vec<u8> = Vec::new();
    let num_pixel: usize = top_layer.len();
    for i in 0..num_pixel {
        let index: usize = i as usize;
        let standardized_top_pixel: f32 = top_layer[index] as f32 / 255.0;
        let standardized_bottom_pixel: f32 = bottom_layer[index] as f32 / 255.0;
        
        //calculate using standardized values
        let mut new_pixel: f32 = 1.0 - (1.0 - standardized_top_pixel) * (1.0 - standardized_bottom_pixel);
        
        //convert pixel to char representation and round it up
        new_pixel *= 255.0;    
        new_pixel += 0.5;  

        result.push(new_pixel as u8);
    }
    return result;
}

fn subtract(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8> {   //subtracts top layer from bottom layer and return a vector
    let mut result: Vec<u8> = Vec::new();
    let num_pixel: usize = top_layer.len();
    for i in 0..num_pixel {
        let top_pixel: i32 = top_layer[i] as i32;
        let bottom_pixel: i32 = bottom_layer[i] as i32;
        let mut new_pixel: i32 = bottom_pixel - top_pixel;
        
        //round to 0 if pixel is negative
        if new_pixel < 0 { 
            new_pixel = 0;
        }

        result.push(new_pixel as u8);
    }
    return result;    
}

fn rotate_180(image_data: &Vec<u8>) -> Vec<u8> {       //rotate the image 180 degree
    let mut result: Vec<u8> = Vec::new();
    let num_pixel: usize = image_data.len() / 3;
    for i in 0..num_pixel {
        let blue = image_data[num_pixel * 3 - i * 3 - 2 - 1];
        let green = image_data[num_pixel * 3 - i * 3 - 1 - 1];
        let red = image_data[num_pixel * 3 - i * 3 - 1];
        result.push(blue);
        result.push(green);
        result.push(red);
    }
    return result;
}

fn change(image_data: &mut Vec<u8>, operator: char, channel: char,  factor: i32) {      //adjust the image channel
    let pixel_num: usize = image_data.len();

    //Change the index of image depend on what RBG is being changed
    let mut channel_index: usize = 0;
    if channel == 'G' {
        channel_index = 1;
    } else if channel == 'R' {
        channel_index = 2;
    }

    if operator == '+' {    //Add operator
        for i in (channel_index..pixel_num).step_by(3) {
            let mut pixel: i32 = image_data[i] as i32;
            pixel += factor;

            //Change the pixel to min when it becomes negative and max when it is larger than 255
            if pixel < 0 {
                pixel = 0;
            } else if pixel > 255 {
                pixel = 255;
            }
            image_data[i] = pixel as u8;
        }
    } else if operator == '*' {     //Scale operator
        for i in (channel_index..pixel_num).step_by(3) {
            let mut pixel: i32 = image_data[i] as i32;
            pixel *= factor;

            //Change the pixel to min when it becomes negative and max when it is larger than 255
            if pixel < 0 {
                pixel = 0;
            } else if pixel > 255 {
                pixel = 255;
            }
            image_data[i] = pixel as u8;
        }
    }
}

fn overlay(top_layer: &Vec<u8>, bottom_layer: &Vec<u8>) -> Vec<u8> {    //overlay the image data and return a vector
    let mut result: Vec<u8> = Vec::new();
    let pixel_num: usize = top_layer.len();
    for i in 0..pixel_num {
        let standardized_top_pixel: f32 = top_layer[i] as f32 / 255.0;
        let standardized_bottom_pixel: f32 = bottom_layer[i] as f32 / 255.0;
        if standardized_bottom_pixel <= 0.5 {
            let mut pixel: f32 = 2.0 * standardized_top_pixel * standardized_bottom_pixel;

            //convert value to char representation and round it up
            pixel *= 255.0;    
            pixel += 0.5;    
            result.push(pixel as u8);
        } else {
            //calculate using standardized values
            let mut pixel: f32 = 1.0 - 2.0 * (1.0 - standardized_top_pixel) * (1.0 - standardized_bottom_pixel);    
            
            //convert value to char representation and round it up
            pixel *= 255.0;    
            pixel += 0.5;  

            result.push(pixel as u8);
        }
    }    
    return result;
}

fn separate_red_channel(image_data: &Vec<u8>) -> Vec<u8> {     //return the image red channel
    let mut result : Vec<u8> = Vec::new();
    let pixel_num:usize = image_data.len() / 3;
    for i in 0..pixel_num {
        let red = image_data[i*3 + 2];
        result.push(red);
        result.push(red);
        result.push(red);
    }
    return result;
}

fn separate_green_channel(image_data: &Vec<u8>) -> Vec<u8> {       //return the image green channel
    let mut result : Vec<u8> = Vec::new();
    let pixel_num:usize = image_data.len() / 3;
    for i in 0..pixel_num
    {
        let green = image_data[i*3 + 1];
        result.push(green);
        result.push(green);
        result.push(green);
    }
    return result;
}

fn separate_blue_channel(image_data: &Vec<u8>) -> Vec<u8> {        //return the image blue channel
    let mut result : Vec<u8> = Vec::new();
    let pixel_num:usize = image_data.len() / 3;
    for i in 0..pixel_num {
        let blue = image_data[i*3];
        result.push(blue);
        result.push(blue);
        result.push(blue);
    }
    return result;
}

fn channel_combine(red: &Vec<u8>, green: &Vec<u8>, blue: &Vec<u8>) -> Vec<u8> {      //combine RGB elements into a vector and return it
    let mut result : Vec<u8> = Vec::new();
    let pixel_num:usize = blue.len() / 3;
    for i in 0..pixel_num {
        let blue_pixel = blue[i * 3];
        let green_pixel = green[i * 3 + 1];
        let red_pixel = red[i * 3 + 2];

        result.push(blue_pixel);
        result.push(green_pixel);
        result.push(red_pixel);
    }
    return result;
}

fn write_file(path: &str, header: &Vec<u8>, data: &Vec<u8>) -> Result<(), Box<dyn std::error::Error>> {    //write the header and image data to a file
    let mut file: File = fs::OpenOptions::new().write(true).create(true).truncate(true).open(&path)?;

    //write the header then append the data
    let _ = file.write_all(&header);
    let _ = file.write_all(&data);

   Ok(())
}

fn read_file(path: &str, header: &mut Vec<u8>, data: &mut Vec<u8>) -> Result<(), Box<dyn std::error::Error>> {   //read data from a file into header and data   
    let file = File::open(&path)?;
    let reader = BufReader::new(file);
    let mut counter = 0;
    for byte in reader.bytes() {
        //read into the data if done reading the header
        if counter == 18 {   
            match byte {
                Ok(b) => {
                    data.push(b);
                }
                Err(err) => {
                    eprintln!("Error reading byte: {}", err);
                }
            }
        } else {
            match byte {
                Ok(b) => {
                    header.push(b);
                    counter += 1;
                }
                Err(err) => {
                    eprintln!("Error reading byte: {}", err);
                }
            }
        }
    }
    Ok(())
}

fn is_equal_files(path1: &str, path2: &str) -> io::Result<bool> {     //check if two files are similar
    let mut file1 = File::open(path1)?;
    let mut file2 = File::open(path2)?;

    let mut data1 = Vec::new();
    let mut data2 = Vec::new();

    //read all the contents of files
    let _ = file1.read_to_end(&mut data1);
    let _ = file2.read_to_end(&mut data2);

    //compare the data
    Ok(data1 == data2)
}

fn ec_header(header: &Vec<u8>) -> Vec<u8> {       //create new header for the extra credit image
    //copy header into result
    let mut result = header.clone(); 

    //generate new width and height for the result
    let new_width = u16::from_le_bytes([header[12], header[13]]) * 2;
    let new_height = u16::from_le_bytes([header[14], header[15]]) * 2;
    result[12..14].copy_from_slice(&new_width.to_le_bytes());
    result[14..16].copy_from_slice(&new_height.to_le_bytes());

    return result;
}

fn ec_combine(bottom_left: &Vec<u8>, bottom_right: &Vec<u8>, top_left: &Vec<u8>, top_right: &Vec<u8>, width: usize, height: usize) -> Vec<u8> {       //combine four images
    let num_channels = 3;
    let row_length = width * num_channels;

    //create the result image
    let mut result : Vec<u8> = Vec::with_capacity(height * width * num_channels * 2); 

    //append bottom two images
    for row in 0..height {
        let start = row * row_length;
        let end = start + row_length;
        //append bottom left row
        result.extend_from_slice(&bottom_left[start..end]);
        //append bottom right row
        result.extend_from_slice(&bottom_right[start..end]);
    }

    //append top two images
    for row in 0..height {
        let start = row * row_length;
        let end = start + row_length;
        //append top left row
        result.extend_from_slice(&top_left[start..end]);
        //append top right row
        result.extend_from_slice(&top_right[start..end]);
    }

    return result;
}

fn main() {     //building tasks and test cases
    //Task 1
    {
        let mut header_top: Vec<u8> = Vec::new();
        let mut data_top: Vec<u8> = Vec::new();
        let _ = read_file("input/layer1.tga", &mut header_top, &mut data_top);

        let mut header_bot: Vec<u8> = Vec::new();
        let mut data_bot: Vec<u8> = Vec::new();
        let _ = read_file("input/pattern1.tga", &mut header_bot, &mut data_bot);

        let result = multiply(&data_top, &data_bot);
        let _ = write_file("output/part1.tga", &header_top, &result);
    }

    //Task 2
    {
        let mut header_top: Vec<u8> = Vec::new();
        let mut data_top: Vec<u8> = Vec::new();
        let _ = read_file("input/layer2.tga", &mut header_top, &mut data_top);

        let mut header_bot: Vec<u8> = Vec::new();
        let mut data_bot: Vec<u8> = Vec::new();
        let _ = read_file("input/car.tga", &mut header_bot, &mut data_bot);

        let result = subtract(&data_top, &data_bot);
        let _ = write_file("output/part2.tga", &header_top, &result);
    }

    //Task 3
    {
        let mut header_top: Vec<u8> = Vec::new();
        let mut data_top: Vec<u8> = Vec::new();
        let _ = read_file("input/layer1.tga", &mut header_top, &mut data_top);

        let mut header_bot: Vec<u8> = Vec::new();
        let mut data_bot: Vec<u8> = Vec::new();
        let _ = read_file("input/pattern2.tga", &mut header_bot, &mut data_bot);

        let bottom = multiply(&data_top, &data_bot);

        let mut top_head: Vec<u8> = Vec::new();
        let mut top_data: Vec<u8> = Vec::new();
        let _ = read_file("input/text.tga", &mut top_head, &mut top_data);

        let result = screen(&top_data, &bottom);
        let _ = write_file("output/part3.tga", &top_head, &result);
    }

    //Task 4
    {
        let mut header_top: Vec<u8> = Vec::new();
        let mut data_top: Vec<u8> = Vec::new();
        let _ = read_file("input/layer2.tga", &mut header_top, &mut data_top);

        let mut header_bot: Vec<u8> = Vec::new();
        let mut data_bot: Vec<u8> = Vec::new();
        let _ = read_file("input/circles.tga", &mut header_bot, &mut data_bot);

        let bottom = multiply(&data_top, &data_bot);

        let mut top_head: Vec<u8> = Vec::new();
        let mut top_data: Vec<u8> = Vec::new();
        let _ = read_file("input/pattern2.tga", &mut top_head, &mut top_data);

        let result = subtract(&top_data, &bottom);
        let _ = write_file("output/part4.tga", &top_head, &result);
    }

    //Task 5
    {
        let mut header_top: Vec<u8> = Vec::new();
        let mut data_top: Vec<u8> = Vec::new();
        let _ = read_file("input/layer1.tga", &mut header_top, &mut data_top);

        let mut header_bot: Vec<u8> = Vec::new();
        let mut data_bot: Vec<u8> = Vec::new();
        let _ = read_file("input/pattern1.tga", &mut header_bot, &mut data_bot);

        let result = overlay(&data_top, &data_bot);
        let _ = write_file("output/part5.tga", &header_top, &result);
    }

    //Task 6
    {
        let mut header: Vec<u8> = Vec::new();
        let mut data: Vec<u8> = Vec::new();
        let _ = read_file("input/car.tga", &mut header, &mut data);

        let _ = change(&mut data, '+', 'G', 200);
        let _ = write_file("output/part6.tga", &header, &data);
    }
    
    //Task 7
    {
        let mut header: Vec<u8> = Vec::new();
        let mut data: Vec<u8> = Vec::new();
        let _ = read_file("input/car.tga", &mut header, &mut data);

        let _ = change(&mut data, '*', 'B', 0);
        let _ = change(&mut data, '*', 'R', 4);
        let _ = write_file("output/part7.tga", &header, &data);
    }

    //Task 8
    {
        let mut header: Vec<u8> = Vec::new();
        let mut data: Vec<u8> = Vec::new();
        let _ = read_file("input/car.tga", &mut header, &mut data);

        let blue: Vec<u8> = separate_blue_channel(&data);
        let green: Vec<u8> = separate_green_channel(&data);
        let red: Vec<u8> = separate_red_channel(&data);

        let _ = write_file("output/part8_r.tga", &header, &red);
        let _ = write_file("output/part8_g.tga", &header, &green);
        let _ = write_file("output/part8_b.tga", &header, &blue);
    }
    
    //Task 9
    {
        let mut red_head: Vec<u8> = Vec::new();
        let mut red: Vec<u8> = Vec::new();
        let _ = read_file("input/layer_red.tga", &mut red_head, &mut red);

        let mut green_head: Vec<u8> = Vec::new();
        let mut green: Vec<u8> = Vec::new();
        let _ = read_file("input/layer_green.tga", &mut green_head, &mut green);

        let mut blue_head: Vec<u8> = Vec::new();
        let mut blue: Vec<u8> = Vec::new();
        let _ = read_file("input/layer_blue.tga", &mut blue_head, &mut blue);

        let result: Vec<u8> = channel_combine(&red, &green, &blue);
        let _ = write_file("output/part9.tga", &red_head, &result);
    }

    //Task 10
    {
        let mut header: Vec<u8> = Vec::new();
        let mut data: Vec<u8> = Vec::new();
        let _ = read_file("input/text2.tga", &mut header, &mut data);

        let result: Vec<u8> = rotate_180(&data);
        let _ = write_file("output/part10.tga", &header, &result);
    }

    //Extra credit
    {
        let mut header: Vec<u8> = Vec::new();
        let mut final_header : Vec<u8> = Vec::new();

        let mut bottom_left: Vec<u8> = Vec::new();
        let _ = read_file("input/text.tga", &mut header, &mut bottom_left);

        let mut bottom_right: Vec<u8> = Vec::new();
        let _ = read_file("input/pattern1.tga", &mut header, &mut bottom_right);

        let mut top_left: Vec<u8> = Vec::new();
        let _ = read_file("input/car.tga", &mut header, &mut top_left);

        let mut top_right: Vec<u8> = Vec::new();
        let _ = read_file("input/circles.tga", &mut final_header, &mut top_right);

        let width = u16::from_le_bytes([header[12], header[13]]);
        let height = u16::from_le_bytes([header[12], header[13]]);

        final_header = ec_header(&final_header);
        let final_data: Vec<u8>  = ec_combine(&bottom_left, &bottom_right, &top_left, &top_right, width as usize, height as usize);
        let _ = write_file("output/extracredit.tga", &final_header, &final_data);
    }

    //Test cases
    for i in 1..11 {
        if i != 8 {     //test for tasks 1-7 and 9-10
            let file1 = format!("output/part{}.tga",i);
            let file2 = format!("examples/EXAMPLE_part{}.tga", i);
            match is_equal_files(&file1, &file2) {
                Ok(true) => println!("Test {} passed!", i),
                Ok(false) => println!("Test {} failed.", i),
                Err(e) => eprintln!("Error: {}", e),
            }   
            
        } else {    //test for task 8
            let compare_files = [
            ("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga"), 
            ("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga"), 
            ("output/part8_r.tga", "examples/EXAMPLE_part8_r.tga")];

            let mut success = false;
            for &(file1, file2) in &compare_files {
                match is_equal_files(file1, file2) {
                    Ok(true) => success = true,
                    Ok(false) => success = false,
                    Err(e) => eprintln!("Error: {}", e),
                }
            }

            if success == true {
                println!("Test 8 passed!")
            } else {
                println!("Test 8 failed.")
            }
        }
    }
    //extra credit test
    {   
        let file1 = format!("output/extracredit.tga");
        let file2 = format!("examples/EXAMPLE_extracredit.tga");
        match is_equal_files(&file1, &file2) {
            Ok(true) => println!("Extra credit test passed!"),
            Ok(false) => println!("Extra credit test failed."),
            Err(e) => eprintln!("Error: {}", e),
        }
    }
}