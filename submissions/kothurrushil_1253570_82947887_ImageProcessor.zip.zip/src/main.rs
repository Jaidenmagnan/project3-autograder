use std::fs::File;
use crate::processor::{get_header, get_pixels, test_equality, write_file, multiply, subtract, screen, overlay, part6, part7, part8_red, part8_blue, part8_green, part_9, part_10};

mod processor;
fn main() {

    //TEST 1
    let mut part1_file1 = File::open("input/layer1.tga").expect("error");
    let header1_part1 = get_header(&part1_file1);
    let mut pixels1_part1 = get_pixels(&part1_file1, &header1_part1);
    let mut part1_file2 = File::open("input/pattern1.tga").expect("error");
    let header2_part1 = get_header(&part1_file2);
    let pixels2_part2 = get_pixels(&part1_file2, &header2_part1);
    let pixel_output_part1 = multiply(&pixels1_part1, &pixels2_part2);
    let mut example1_file = File::open("examples/EXAMPLE_part1.tga").expect("error");
    let header_example1 = get_header(&example1_file);
    let pixels_example1 = get_pixels(&example1_file, &header_example1);
    if test_equality(&pixels_example1, &pixel_output_part1) {
        write_file("output/part1.tga", &header1_part1, &pixel_output_part1).expect("error");
        println!("TEST 1: PASSED");
    } else {
        println!("TEST 1: FAILED");
    }


    //TEST 2
    let mut part2_file1 = File::open("input/layer2.tga").expect("error");
    let header1_part2 = get_header(&part2_file1);
    let mut pixels1_part2 = get_pixels(&part2_file1, &header1_part2);
    let mut part2_file2 = File::open("input/car.tga").expect("error");
    let header2_part2 = get_header(&part2_file2);
    let pixels2_part2 = get_pixels(&part2_file2, &header2_part2);
    let pixel_output_part2 = subtract(&pixels1_part2, &pixels2_part2);
    let mut example2_file = File::open("examples/EXAMPLE_part2.tga").expect("error");
    let header_example2 = get_header(&example2_file);
    let pixels_example2 = get_pixels(&example2_file, &header_example2);
    if test_equality(&pixels_example2, &pixel_output_part2) {
        write_file("output/part2.tga", &header1_part2, &pixel_output_part2).expect("error");
        println!("TEST 2: PASSED");
    } else {
        println!("TEST 2: FAILED");
    }


    //TEST 3
    let mut part3_file1 = File::open("input/layer1.tga").expect("error");
    let header1_part3 = get_header(&part3_file1);
    let mut pixels1_part3 = get_pixels(&part3_file1, &header1_part3);
    let mut part3_file2 = File::open("input/pattern2.tga").expect("error");
    let header2_part3 = get_header(&part3_file2);
    let pixels2_part3 = get_pixels(&part3_file2, &header2_part3);
    let pixel_temp_output_part3 = multiply(&pixels1_part3, &pixels2_part3);
    let mut part3_file3 = File::open("input/text.tga").expect("error");
    let mut header3_part3 = get_header(&part3_file3);
    let mut pixels3_part3 = get_pixels(&part3_file3, &header3_part3);
    let pixel_output_part3 = screen(&pixels3_part3, &pixel_temp_output_part3);
    let mut example3_file = File::open("examples/EXAMPLE_part3.tga").expect("error");
    let header_example3 = get_header(&example3_file);
    let pixels_example3 = get_pixels(&example3_file, &header_example3);
    if test_equality(&pixels_example3, &pixel_output_part3) {
        write_file("output/part3.tga", &header1_part3, &pixel_output_part3).expect("error");
        println!("TEST 3: PASSED");
    } else {
        println!("TEST 3: FAILED");
    }


    //TEST 4
    let mut part4_file1 = File::open("input/layer2.tga").expect("error");
    let header1_part4 = get_header(&part4_file1);
    let mut pixels1_part4 = get_pixels(&part4_file1, &header1_part4);
    let mut part4_file2 = File::open("input/circles.tga").expect("error");
    let header2_part4 = get_header(&part4_file2);
    let pixels2_part4 = get_pixels(&part4_file2, &header2_part4);
    let pixel_temp_output_part4 = multiply(&pixels1_part4, &pixels2_part4);
    let mut part4_file3 = File::open("input/pattern2.tga").expect("error");
    let mut header3_part4 = get_header(&part4_file3);
    let mut pixels3_part4 = get_pixels(&part4_file3, &header3_part4);
    let pixel_output_part4 = subtract(&pixels3_part4, &pixel_temp_output_part4);
    let mut example4_file = File::open("examples/EXAMPLE_part4.tga").expect("error");
    let header_example4 = get_header(&example4_file);
    let pixels_example4 = get_pixels(&example4_file, &header_example4);
    if test_equality(&pixels_example4, &pixel_output_part4) {
        write_file("output/part4.tga", &header1_part4, &pixel_output_part4).expect("error");
        println!("TEST 4: PASSED");
    } else {
        println!("TEST 4: FAILED");
    }


    //TEST 5
    let mut part5_file1 = File::open("input/layer1.tga").expect("error");
    let header1_part5 = get_header(&part5_file1);
    let mut pixels1_part5 = get_pixels(&part5_file1, &header1_part5);
    let mut part5_file2 = File::open("input/pattern1.tga").expect("error");
    let header2_part5 = get_header(&part5_file2);
    let pixels2_part5 = get_pixels(&part5_file2, &header2_part5);
    let pixel_output_part5 = overlay(&pixels1_part5, &pixels2_part5);
    let mut example5_file = File::open("examples/EXAMPLE_part5.tga").expect("error");
    let header_example5 = get_header(&example5_file);
    let pixels_example5 = get_pixels(&example5_file, &header_example5);
    if test_equality(&pixels_example5, &pixel_output_part5) {
        write_file("output/part5.tga", &header1_part5, &pixel_output_part5).expect("error");
        println!("TEST 5: PASSED");
    } else {
        println!("TEST 5: FAILED");
    }


    //TEST 6
    let mut part6_file1 = File::open("input/car.tga").expect("error");
    let header1_part6 = get_header(&part6_file1);
    let mut pixels1_part6 = get_pixels(&part6_file1, &header1_part6);
    let pixel_output_part6 = part6(&pixels1_part6);
    let mut example6_file = File::open("examples/EXAMPLE_part6.tga").expect("error");
    let header_example6 = get_header(&example6_file);
    let pixels_example6 = get_pixels(&example6_file, &header_example6);
    if test_equality(&pixels_example6, &pixel_output_part6) {
        write_file("output/part6.tga", &header1_part6, &pixel_output_part6).expect("error");
        println!("TEST 6: PASSED");
    } else {
        println!("TEST 6: FAILED");
    }


    //TEST 7
    let mut part7_file1 = File::open("input/car.tga").expect("error");
    let header1_part7 = get_header(&part7_file1);
    let mut pixels1_part7 = get_pixels(&part7_file1, &header1_part7);
    let pixel_output_part7 = part7(&pixels1_part7);
    let mut example7_file = File::open("examples/EXAMPLE_part7.tga").expect("error");
    let header_example7 = get_header(&example7_file);
    let pixels_example7 = get_pixels(&example7_file, &header_example7);
    if test_equality(&pixels_example7, &pixel_output_part7) {
        write_file("output/part7.tga", &header1_part7, &pixel_output_part7).expect("error");
        println!("TEST 7: PASSED");
    } else {
        println!("TEST 7: FAILED");
    }


    //TEST 8
    let mut part8_file1 = File::open("input/car.tga").expect("error");
    let header1_part8 = get_header(&part8_file1);
    let mut pixels1_part8 = get_pixels(&part8_file1, &header1_part8);
    //red
    let pixel_output_part8_r = part8_red(&pixels1_part8);
    let mut example8_r_file = File::open("examples/EXAMPLE_part8_r.tga").expect("error");
    let header_example8_r = get_header(&example8_r_file);
    let pixels_example8_r = get_pixels(&example8_r_file, &header_example8_r);
    if test_equality(&pixels_example8_r, &pixel_output_part8_r) {
        write_file("output/part8_r.tga", &header1_part8, &pixel_output_part8_r).expect("error");
        println!("TEST 8_r: PASSED");
    } else {
        println!("TEST 8_r: FAILED");
    }
    //green
    let pixel_output_part8_g = part8_green(&pixels1_part8);
    let mut example8_g_file = File::open("examples/EXAMPLE_part8_g.tga").expect("error");
    let header_example8_g = get_header(&example8_g_file);
    let pixels_example8_g = get_pixels(&example8_g_file, &header_example8_g);
    if test_equality(&pixels_example8_g, &pixel_output_part8_g) {
        write_file("output/part8_g.tga", &header1_part8, &pixel_output_part8_g).expect("error");
        println!("TEST 8_g: PASSED");
    } else {
        println!("TEST 8_g: FAILED");
    }
    //blue
    let pixel_output_part8_b = part8_blue(&pixels1_part8);
    let mut example8_b_file = File::open("examples/EXAMPLE_part8_b.tga").expect("error");
    let header_example8_b = get_header(&example8_b_file);
    let pixels_example8_b = get_pixels(&example8_b_file, &header_example8_b);
    if test_equality(&pixels_example8_b, &pixel_output_part8_b) {
        write_file("output/part8_b.tga", &header1_part8, &pixel_output_part8_b).expect("error");
        println!("TEST 8_b: PASSED");
    } else {
        println!("TEST 8_b: FAILED");
    }


    //TEST 9
    let mut part9_file1 = File::open("input/layer_red.tga").expect("error");
    let header1_part9 = get_header(&part9_file1);
    let mut pixels1_part9 = get_pixels(&part9_file1, &header1_part9);
    let mut part9_file2 = File::open("input/layer_green.tga").expect("error");
    let header2_part9 = get_header(&part9_file2);
    let pixels2_part9 = get_pixels(&part9_file2, &header2_part9);
    let mut part9_file3 = File::open("input/layer_blue.tga").expect("error");
    let mut header3_part9 = get_header(&part9_file3);
    let mut pixels3_part9 = get_pixels(&part9_file3, &header3_part9);
    let pixel_output_part9 = part_9(&pixels1_part9, &pixels2_part9, &pixels3_part9);
    let mut example9_file = File::open("examples/EXAMPLE_part9.tga").expect("error");
    let header_example9 = get_header(&example9_file);
    let pixels_example9 = get_pixels(&example9_file, &header_example9);
    if test_equality(&pixels_example9, &pixel_output_part9) {
        write_file("output/part9.tga", &header1_part9, &pixel_output_part9).expect("error");
        println!("TEST 9: PASSED");
    } else {
        println!("TEST 9: FAILED");
    }


    //TEST 10
    let mut part10_file1 = File::open("input/text2.tga").expect("error");
    let header1_part10 = get_header(&part10_file1);
    let mut pixels1_part10 = get_pixels(&part10_file1, &header1_part10);
    let pixel_output_part10 = part_10(&pixels1_part10);
    let mut example10_file = File::open("examples/EXAMPLE_part10.tga").expect("error");
    let header_example10 = get_header(&example10_file);
    let pixels_example10 = get_pixels(&example10_file, &header_example10);
    if test_equality(&pixels_example10, &pixel_output_part10) {
        write_file("output/part10.tga", &header1_part10, &pixel_output_part10).expect("error");
        println!("TEST 10: PASSED");
    } else {
        println!("TEST 10: FAILED");
    }
}