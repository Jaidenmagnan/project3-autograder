use std::fs::File; //use statements
use std::io;
use std::io::Read;
use std::io::Write;


//Header struct to load in header data from files
#[derive(Debug)]
pub struct Header {
    pub id_length: u8,
    pub color_map_type: u8,
    pub data_type_code: u8,
    pub color_map_origin: u16,
    pub color_map_length: u16,
    pub color_map_depth: u8,
    pub x_origin: u16,
    pub y_origin: u16,
    pub width: u16,
    pub height: u16,
    pub bits_per_pixel: u8,
    pub image_descriptor: u8,
}


//Pixel struct to load in pixel data from files using Header struct
#[derive(Debug)]
pub struct Pixel {
    pub red_val: u8,
    pub green_val: u8,
    pub blue_val: u8
}

//function to get header given file variable
pub fn get_header(mut file: &File) -> Header {
    let mut header_data = [0; 18];

    //reads in file using read.exact() function and stores in header_data buffer
    file.read_exact(&mut header_data).expect("Error reading file for header data!");

    //returns full Header struct with each value placed correctly using indexing
    return Header{
        id_length: header_data[0],
        color_map_type: header_data[1],
        data_type_code: header_data[2],
        color_map_origin: u16::from_le_bytes([header_data[3], header_data[4]]),
        color_map_length: u16::from_le_bytes([header_data[5], header_data[6]]),
        color_map_depth: header_data[7],
        x_origin: u16::from_le_bytes([header_data[8], header_data[9]]),
        y_origin: u16::from_le_bytes([header_data[10], header_data[11]]),
        width: u16::from_le_bytes([header_data[12], header_data[13]]),
        height: u16::from_le_bytes([header_data[14], header_data[15]]),
        bits_per_pixel: header_data[16],
        image_descriptor: header_data[17]
    }
}


//function to get pixel data from file variable and header variable
pub fn get_pixels(mut file: &File, header: &Header) -> Vec<Pixel> {
    let num_pixels = (header.width as usize) * (header.height as usize);
    let mut pixel_data = Vec::with_capacity(num_pixels);
    for _i in 0..num_pixels {
        let mut pixel_bytes = [0; 3];

        //reads in file using read.exact() function and stores in pixel_bytes buffer
        file.read_exact(&mut pixel_bytes).expect("Error reading file for pixel data!");

        //initializes Pixel struct and fills with proper values from buffer
        let pixel = Pixel {
            blue_val: pixel_bytes[0],
            green_val: pixel_bytes[1],
            red_val: pixel_bytes[2]
        };

        //pushes Pixel struct into vector
        pixel_data.push(pixel);
    }
    return pixel_data;
}


//function to create file and store in location given name of file, header struct, and pixel struct
pub fn write_file(file_name: &str, header: &Header, pixels: &Vec<Pixel>) -> io::Result<()> {
    //creates file
    let mut file = File::create(file_name)?;

    let mut header_bytes = Vec::new();

    //pushes in each element of header into file first
    header_bytes.push(header.id_length);
    header_bytes.push(header.color_map_type);
    header_bytes.push(header.data_type_code);
    header_bytes.push(header.color_map_origin.to_le_bytes()[0]);
    header_bytes.push(header.color_map_origin.to_le_bytes()[1]);
    header_bytes.push(header.color_map_length.to_le_bytes()[0]);
    header_bytes.push(header.color_map_length.to_le_bytes()[1]);
    header_bytes.push(header.color_map_depth);
    header_bytes.push(header.x_origin.to_le_bytes()[0]);
    header_bytes.push(header.x_origin.to_le_bytes()[1]);
    header_bytes.push(header.y_origin.to_le_bytes()[0]);
    header_bytes.push(header.y_origin.to_le_bytes()[1]);
    header_bytes.push(header.width.to_le_bytes()[0]);
    header_bytes.push(header.width.to_le_bytes()[1]);
    header_bytes.push(header.height.to_le_bytes()[0]);
    header_bytes.push(header.height.to_le_bytes()[1]);
    header_bytes.push(header.bits_per_pixel);
    header_bytes.push(header.image_descriptor);

    //pushes in each pixel in blue, green, red order using a loop
    for pixel in pixels {
        header_bytes.push(pixel.blue_val);
        header_bytes.push(pixel.green_val);
        header_bytes.push(pixel.red_val);
    }

    //uses write_all() function to write in the vector into the file
    file.write_all(header_bytes.as_slice())?;
    Ok(())
}


//function to test example and output files given each file
pub fn test_equality(pixels1: &Vec<Pixel>, pixels2: &Vec<Pixel>) -> bool {
    for i in 0..pixels1.len() {

        //compares each pixel color from example file to output file, returns true if all are equal
        if !((pixels1[i].blue_val == pixels2[i].blue_val) & (pixels1[i].green_val == pixels2[i].green_val)
        & (pixels1[i].red_val == pixels2[i].red_val)) {
            return false
        }
    }
    return true
}


//function to multiply two files
pub fn multiply(pixels1: &Vec<Pixel>, pixels2: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    for i in 0..pixels1.len() {

        //sets new pixel color values to the files pixel values multiplied to each other
        let mut new_blue = (((pixels1[i].blue_val as f64)/255.0) * ((pixels2[i].blue_val as f64)/255.0) * 255.0).round() as u8;
        let mut new_green = (((pixels1[i].green_val as f64)/255.0) * ((pixels2[i].green_val as f64)/255.0) * 255.0).round() as u8;
        let mut new_red = (((pixels1[i].red_val as f64)/255.0) * ((pixels2[i].red_val as f64)/255.0) * 255.0).round() as u8;

        //pushes each pixel into new vector
        new_pixels.push(Pixel{red_val: new_red, green_val: new_green, blue_val: new_blue});
    }
    return new_pixels;
}


//function to subtract two files
pub fn subtract(top_layer: &Vec<Pixel>, bottom_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_blue = 0;
    let mut new_green = 0;
    let mut new_red = 0;
    for i in 0..top_layer.len() {

        //sets each new pixel color value to subtracted values, sets to 0 if it goes negative
        if (bottom_layer[i].blue_val as f64) - (top_layer[i].blue_val as f64) < 0.0 {
            new_blue = 0;
        } else {
            new_blue = bottom_layer[i].blue_val - top_layer[i].blue_val;
        }
        if (bottom_layer[i].green_val as f64) - (top_layer[i].green_val as f64) < 0.0 {
            new_green = 0;
        } else {
            new_green = bottom_layer[i].green_val - top_layer[i].green_val;
        }
        if (bottom_layer[i].red_val as f64) - (top_layer[i].red_val as f64) < 0.0 {
            new_red = 0;
        } else {
            new_red = bottom_layer[i].red_val - top_layer[i].red_val;
        }

        //pushes new pixels into new vector
        new_pixels.push(Pixel{red_val: new_red, green_val: new_green, blue_val: new_blue});

    }
    return new_pixels;
}


//function to screen two files
pub fn screen(pixels1: &Vec<Pixel>, pixels2: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    for i in 0..pixels1.len() {

        //same process as multiply
        let mut new_blue = ((1.0 - (1.0 - (pixels1[i].blue_val as f64)/255.0) * (1.0 - (pixels2[i].blue_val as f64)/255.0)) * 255.0).round() as u8;
        let mut new_green = ((1.0 - (1.0 - (pixels1[i].green_val as f64)/255.0) * (1.0 - (pixels2[i].green_val as f64)/255.0)) * 255.0).round() as u8;
        let mut new_red = ((1.0 - (1.0 - (pixels1[i].red_val as f64)/255.0) * (1.0 - (pixels2[i].red_val as f64)/255.0)) * 255.0).round() as u8;
        new_pixels.push(Pixel{red_val: new_red, green_val: new_green, blue_val: new_blue});
    }
    return new_pixels;
}


//function to overlay two files
pub fn overlay(top_layer: &Vec<Pixel>, bottom_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_blue = 0;
    let mut new_green = 0;
    let mut new_red = 0;
    for i in 0..top_layer.len() {

        //same process as subtract
        if bottom_layer[i].blue_val < 128 {
            new_blue = (2.0 * ((top_layer[i].blue_val as f64)/255.0) * ((bottom_layer[i].blue_val as f64)/255.0) * 255.0).round() as u8;
        } else {
            new_blue = ((1.0 - 2.0 * (1.0 - (top_layer[i].blue_val as f64)/255.0) * (1.0 - (bottom_layer[i].blue_val as f64)/255.0)) * 255.0).round() as u8;
        }
        if bottom_layer[i].green_val < 128 {
            new_green = (2.0 * ((top_layer[i].green_val as f64)/255.0) * ((bottom_layer[i].green_val as f64)/255.0) * 255.0).round() as u8;
        } else {
            new_green = ((1.0 - 2.0 * (1.0 - (top_layer[i].green_val as f64)/255.0) * (1.0 - (bottom_layer[i].green_val as f64)/255.0)) * 255.0).round() as u8;
        }
        if bottom_layer[i].red_val < 128 {
            new_red = (2.0 * ((top_layer[i].red_val as f64)/255.0) * ((bottom_layer[i].red_val as f64)/255.0) * 255.0).round() as u8;
        } else {
            new_red = ((1.0 - 2.0 * (1.0 - (top_layer[i].red_val as f64)/255.0) * (1.0 - (bottom_layer[i].red_val as f64)/255.0)) * 255.0).round() as u8;
        }
        new_pixels.push(Pixel{red_val: new_red, green_val: new_green, blue_val: new_blue});
    }
    return new_pixels;
}


//function specifically for part 6
pub fn part6(pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_green = 0;
    for i in 0..pixels.len() {
            if (pixels[i].green_val as u16) + 200 > 255 {
                new_green = 255;
            } else {
                new_green = pixels[i].green_val + 200
            }
        new_pixels.push(Pixel{red_val: pixels[i].red_val, green_val: new_green, blue_val: pixels[i].blue_val});
    }
    return new_pixels;
}


//function specifically for part 7
pub fn part7(pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_red = 0;
    let mut new_blue = 0;
    for i in 0..pixels.len() {
        if (pixels[i].red_val as u16) * 4 > 255 {
            new_red = 255;
        } else {
            new_red = pixels[i].red_val * 4;
        }
        new_pixels.push(Pixel{red_val: new_red, green_val: pixels[i].green_val, blue_val: new_blue});
    }
    return new_pixels;
}


//function specifically for part 8_red
pub fn part8_red(pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_red = 0;
    for i in 0..pixels.len() {
        new_red = pixels[i].red_val;
        new_pixels.push(Pixel{red_val: new_red, green_val: new_red, blue_val: new_red});
    }
    return new_pixels;
}


//function specifically for part 8_green
pub fn part8_green(pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_green = 0;
    for i in 0..pixels.len() {
        new_green = pixels[i].green_val;
        new_pixels.push(Pixel{red_val: new_green, green_val: new_green, blue_val: new_green});
    }
    return new_pixels;
}


//function specifically for part 8_blue
pub fn part8_blue(pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_blue = 0;
    for i in 0..pixels.len() {
        new_blue = pixels[i].blue_val;
        new_pixels.push(Pixel{red_val: new_blue, green_val: new_blue, blue_val: new_blue});
    }
    return new_pixels;
}


//function specifically for part 9
pub fn part_9(red_pixels: &Vec<Pixel>, green_pixels: &Vec<Pixel>, blue_pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let mut new_red = 0;
    let mut new_green = 0;
    let mut new_blue = 0;
    for i in 0..red_pixels.len() {
        new_red = red_pixels[i].red_val;
        new_green = green_pixels[i].green_val;
        new_blue = blue_pixels[i].blue_val;
        new_pixels.push(Pixel{red_val: new_red, green_val: new_green, blue_val: new_blue});
    }
    return new_pixels;
}


//function specifically for part 10
pub fn part_10(pixels: &Vec<Pixel>) -> Vec<Pixel> {
    let mut new_pixels = Vec::new();
    let length = pixels.len();
    for i in 0..length {
        new_pixels.push(Pixel{red_val: pixels[length - i - 1].red_val, green_val: pixels[length - i - 1].green_val, blue_val: pixels[length - i - 1].blue_val});
    }
    return new_pixels;
}