// Kai McFarlane

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "Image.h"


Image::Image(string file){
    loadImage(file);
}

// Changes img object data to a new file's data
void Image::loadImage(std::string fileName) {
    // Loads new file data
    ifstream file(fileName, ios::in | ios::binary);
    // Reads new img header data to current img header data
    file.read(&idLength, sizeof(char));
    file.read(&colorMapType, sizeof(char));
    file.read(&dataTypeCode, sizeof(char));
    file.read((char *)&colorMapOrigin, sizeof(colorMapOrigin));
    file.read((char *)&colorMapLength, sizeof(colorMapLength));
    file.read(&colorMapDepth, sizeof(char));
    file.read((char *)&xOrigin, sizeof(xOrigin));
    file.read((char *)&yOrigin, sizeof(yOrigin));
    file.read((char *)&width, sizeof(width));
    file.read((char *)&height, sizeof(height));
    file.read(&bitsPerPixel, sizeof(char));
    file.read(&imageDescriptor, sizeof(char));
    // Gets size of all color data
    colorPixelSize = width*height;
    colorByteSize = colorPixelSize*3;
    // Creates new arr for color data
    char* data = new char[colorByteSize];
    // Reads new file color data to new arr
    file.read(data,colorByteSize);
    // Sets old arr to new arr
    colorArray = data;
}

// Writes current img data to new file name and directory
void Image::writeImage(string fileName) {
    // Creates new output file
    ofstream outputFile(fileName, ios::out | ios::binary);
    // Writes current header data to new file
    outputFile.write(&idLength, sizeof(char));
    outputFile.write(&colorMapType, sizeof(char));
    outputFile.write(&dataTypeCode, sizeof(char));
    outputFile.write((char *)&colorMapOrigin, sizeof(colorMapOrigin));
    outputFile.write((char *)&colorMapLength, sizeof(colorMapLength));
    outputFile.write(&colorMapDepth, sizeof(char));
    outputFile.write((char *)&xOrigin, sizeof(xOrigin));
    outputFile.write((char *)&yOrigin, sizeof(yOrigin));
    outputFile.write((char *)&width, sizeof(width));
    outputFile.write((char *)&height, sizeof(height));
    outputFile.write(&bitsPerPixel, sizeof(char));
    outputFile.write(&imageDescriptor, sizeof(char));
    // Writes current image data to output file
    outputFile.write(colorArray,colorByteSize);
}

// Writes another img's data to new file name and directory
void Image::writeOtherImage(string fileName, char* colorData){
    // Creates new output file
    ofstream outputFile(fileName, ios::out | ios::binary);
    // Writes new header data to new file
    outputFile.write(&idLength, sizeof(char));
    outputFile.write(&colorMapType, sizeof(char));
    outputFile.write(&dataTypeCode, sizeof(char));
    outputFile.write((char *)&colorMapOrigin, sizeof(colorMapOrigin));
    outputFile.write((char *)&colorMapLength, sizeof(colorMapLength));
    outputFile.write(&colorMapDepth, sizeof(char));
    outputFile.write((char *)&xOrigin, sizeof(xOrigin));
    outputFile.write((char *)&yOrigin, sizeof(yOrigin));
    outputFile.write((char *)&width, sizeof(width));
    outputFile.write((char *)&height, sizeof(height));
    outputFile.write(&bitsPerPixel, sizeof(char));
    outputFile.write(&imageDescriptor, sizeof(char));
    // Writes new color data to output file
    outputFile.write(colorData,colorByteSize);
}

// Multiplies new img with original img
void Image::multiply(string otherFile, string newFile) {
    // Opens other img file
    ifstream file(otherFile, ios::in | ios::binary);
    // Goes to start of color data
    file.seekg(18);
    // Creates other arr
    char* otherData = new char[colorByteSize];
    // Sets other array to other img data
    file.read(otherData,colorByteSize);
    // Creates new empty arr for color data
    char* newData = new char[colorByteSize];
    // Sets new empty array to original color data multiplied with other color data
    for(int i=0;i<colorByteSize;i++){
        int otherDataInt = static_cast<int>(static_cast<unsigned char>(otherData[i]));
        int oldDataInt = static_cast<int>(static_cast<unsigned char>(colorArray[i]));
        float otherDataDec = (static_cast<float>(otherDataInt)/255.0);
        float oldDataDec = (static_cast<float>(oldDataInt)/255);
        newData[i] = static_cast<int>((otherDataDec * oldDataDec * 255) + 0.5);
    }
    // Takes new color data and saves it in a new file with a specified "newFile" name
    writeOtherImage(newFile,newData);
    // Deletes newData and otherData to prevent memory leaks
    delete[] newData;
    delete[] otherData;
}

// Subtracts other img from original img
void Image::subtract(std::string otherFile, std::string newFile) {
    // Opens other img file
    ifstream file(otherFile, ios::in | ios::binary);
    // Goes to start of other img data in file
    file.seekg(18);
    // Creates other array
    char* otherData = new char[colorByteSize];
    // Sets other array to other img data
    file.read(otherData,colorByteSize);
    // Creates another new array
    char* newData = new char[colorByteSize];
    // Sets values of new array to other color data minus original color data
    for(int i=0;i<colorByteSize;i++){
        if(static_cast<int>(static_cast<unsigned char>(colorArray[i])) > static_cast<int>(static_cast<unsigned char>(otherData[i]))){
            newData[i] = 0;
        }
        else{
            newData[i] = abs(static_cast<int>(static_cast<unsigned char>(colorArray[i])) - static_cast<int>(static_cast<unsigned char>(otherData[i])));
        }
    }
    // Takes new color data and saves it in a new file with a specified "newFile" name
    writeOtherImage(newFile,newData);
    // Deletes newData and otherData to prevent memory leaks
    delete[] newData;
    delete[] otherData;
}

//Screens original img with other img
void Image::screen(std::string otherFile, std::string newFile) {
    // Opens other img file
    ifstream file(otherFile, ios::in | ios::binary);
    // Goes to start of img data in other file
    file.seekg(18);
    // Creates other array
    char* otherData = new char[colorByteSize];
    // Sets other array to other img data
    file.read(otherData,colorByteSize);
    // Creates another new array
    char* newData = new char[colorByteSize];
    // Sets values of new array to other color data screened with original color data
    for(int i=0;i<colorByteSize;i++) {
        int otherDataInt = static_cast<int>(static_cast<unsigned char>(otherData[i]));
        int oldDataInt = static_cast<int>(static_cast<unsigned char>(colorArray[i]));
        float otherDataDec = (static_cast<float>(otherDataInt) / 255.0);
        float oldDataDec = (static_cast<float>(oldDataInt) / 255.0);
        newData[i] = static_cast<int>(((1-((1-otherDataDec) * (1-oldDataDec))) * 255) + 0.5);
        newData[i] = newData[i];
    }
    // Takes new color data and saves it in a new file with a specified "newFile" name
    writeOtherImage(newFile,newData);
    // Deletes newData and otherData to prevent memory leaks
    delete[] newData;
    delete[] otherData;
}

// Overlays original img with other img
void Image::overlay(std::string otherFile, std::string newFile) {
    // Opens other file data
    ifstream file(otherFile, ios::in | ios::binary);
    // Goes to start of img data in other file
    file.seekg(18);
    // Creates other array
    char* otherData = new char[colorByteSize];
    // Sets other array to other img data
    file.read(otherData,colorByteSize);
    // Creates another new array
    char* newData = new char[colorByteSize];
    // Sets values of new array to other color data overlayed with original color data
    for(int i=0;i<colorByteSize;i++) {
        int otherDataInt = static_cast<int>(static_cast<unsigned char>(otherData[i]));
        int oldDataInt = static_cast<int>(static_cast<unsigned char>(colorArray[i]));
        float otherDataDec = (static_cast<float>(otherDataInt) / 255.0);
        float oldDataDec = (static_cast<float>(oldDataInt) / 255.0);
        if(otherDataDec<=0.5){
            newData[i] = static_cast<int>(((oldDataDec * otherDataDec * 2) * 255) + 0.5);
        }
        else{
            newData[i] = static_cast<int>(((1-(2*((1-oldDataDec) * (1-otherDataDec)))) * 255) + 0.5);
        }
    }
    // Takes new color data and saves it in a new file specified "newFile" name
    writeOtherImage(newFile,newData);
    // Deletes newData and otherData to prevent memory leaks
    delete[] newData;
    delete[] otherData;
}

// Adds value to green channel of img
void Image::addGreenChannel(int value) {
    // Loops through color data of original data
    for(int i=1;i<colorByteSize;i+=3){
        // Changes green channel to 250 if after adding number value is greater than 250
        if(static_cast<int>(static_cast<unsigned char>(colorArray[i])) + 200 > 255){
            colorArray[i] = 255;
        }
        // Adds value to green channel
        else {
            colorArray[i] += value;
        }
    }
    // Takes new color data and saves it in a new file it a specified "newFile" name
    writeImage("./output/part6.tga");
}

// Scales red channel by 4 and blue channel by 0
void Image::changeRedBlue() {
    // Loops through original color data
    for(int i=2;i<colorByteSize;i+=3){
        // Makes red channel 255 if overflow
        if(static_cast<int>(static_cast<unsigned char>(colorArray[i]))*4 > 255){
            colorArray[i] = 255;
        }
        // Scales red channel by 4
        else{
            colorArray[i] *= 4;
        }
        // Scales blue channel by 0
        if(i != 0){
            colorArray[i-2] = 0;
        }
    }
    // Takes new color data and saves it in a new file it a specified "newFile" name
    writeImage("./output/part7.tga");
}

// Makes three new imgs from each channel of original img
void Image::makeThreeChannel() {
    // Creates new array for color data
    char* newData = new char[colorByteSize];
    // Loops through color data and sets original data to new array
    for(int i=0;i<colorByteSize;i++){
        newData[i] = colorArray[i];
    }
    // Loops through color data and makes all channels the red channel
    for(int i=2;i<colorByteSize;i+=3) {
        if(i!=0){
            newData[i-1] = colorArray[i];
            if(i != 1){
                newData[i-2] = colorArray[i];
            }
        }
    }
    // Takes new color data and saves it in a new file for red channel
    writeOtherImage("./output/part8_r.tga", newData);
    // Loops through color data and sets original data to new array
    for(int i=0;i<colorByteSize;i++){
        newData[i] = colorArray[i];
    }
    // Loops through color data and makes all channels the green channel
    for(int i=2;i<colorByteSize;i+=3){
        if(i!=0){
            newData[i] = colorArray[i-1];
            if(i != 1){
                newData[i-2] = colorArray[i-1];
            }
        }
    }
    // Takes new color data and saves it in a new file for green channel
    writeOtherImage("./output/part8_g.tga", newData);
    // Loops through color data and sets original data to new array
    for(int i=0;i<colorByteSize;i++){
        newData[i] = colorArray[i];
    }
    // Loops through color data and makes all channels the blue channel
    for(int i=2;i<colorByteSize;i+=3){
        if(i!=0){
            newData[i-1] = colorArray[i-2];
            if(i != 1){
                newData[i] = colorArray[i-2];
            }
        }
    }
    // Takes new color data and saves it in a new file for blue channel
    writeOtherImage("./output/part8_b.tga", newData);
    // Deletes newData to prevent memory leaks
    delete[] newData;
}

// Combines three images to create new img
void Image::combineThree(string file2, string file3) {
    // Opens second file
    ifstream file(file2, ios::in | ios::binary);
    // Goes to start of color data for second file
    file.seekg(18);
    // Creates new array for second file color data
    char* data2 = new char[colorByteSize];
    // Sets new array to second file color data
    file.read(data2,colorByteSize);
    // Opens third file
    ifstream newFile(file3, ios::in | ios::binary);
    // Goes to start of color data for third file
    newFile.seekg(18);
    // Creates new array for third file color data
    char* data3 = new char[colorByteSize];
    // Sets new array to third file color data
    newFile.read(data3,colorByteSize);
    // Sets green chanel of original img with that of second img
    for(int i=1;i<colorByteSize;i+=3){
        colorArray[i] = data2[i];
    }
    // Sets red channel of original img with that of third img
    for(int i=2;i<colorByteSize;i+=3){
        colorArray[i] = data3[i];
    }
    // Takes new color data and saves it in a new file
    writeImage("./output/part9.tga");
    // Deletes arrays for second and third img color data to prevent memory leaks
    delete[] data2;
    delete[] data3;
}

// Rotates img 180 degrees
void Image::rotate() {
    // Creates new array for color data
    char* newData = new char[colorByteSize];
    // Sets up variables at end and beginning of data
    int colorByteIndexSize = colorByteSize-1;
    int j=0;
    // Sets values of new array in reverse order to flip image
    for(int i=colorByteIndexSize;i>1;i-=3){
        // Sets end of new array as start of other array, adding value to index to preserve bgr format both ways
        newData[i] = colorArray[j+2];
        newData[i-1] = colorArray[j+1];
        newData[i-2] = colorArray[j];
        j+=3;
    }
    // Creates new file for new image data
    writeOtherImage("./output/part10.tga",newData);
    // Deletes newData array prevent memory leaks
    delete[] newData;
}

// Destructor
Image::~Image(){
    delete colorArray;
}