// Kai McFarlane

#pragma once
#include <string>
#include <vector>

using namespace std;

class Image {
public:
    // Constructor
    Image(string file);
    // Header Data
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
    // Amount of pixels in image
    int colorPixelSize;
    // Amount of all colors (all # of rgb values or # of pixels * 3)
    int colorByteSize;
    // Array of image's color data
    char* colorArray;
    // Methods
    void loadImage(string fileName);
    void writeImage(string fileName);
    void multiply(string otherFile, string newFile);
    void screen(string otherFile, string newFile);
    void writeOtherImage(string fileName, char* colorData);
    void subtract(string otherFile, string newFile);
    void overlay(string otherFile, string newFile);
    void addGreenChannel(int value);
    void changeRedBlue();
    void makeThreeChannel();
    void combineThree(string file2, string file3);
    void rotate();
    // Destructor
    ~Image();
};
