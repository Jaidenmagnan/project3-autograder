// Kai McFarlane

#include "Image.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    // Task 1
    // Creates img object with layer1.tga and mutiplies it with pattern1.tga to create part1.tga
    Image img1("./input/layer1.tga");
    img1.multiply("./input/pattern1.tga", "./output/part1.tga");

    // Task 2
    // Creates img object with layer2.tga and subtracts it from car.tga to create part2.tga
    Image img2("./input/layer2.tga");
    img2.subtract("./input/car.tga", "./output/part2.tga");

    // Task 3
    // Creates img object with layer1.tga and mutiplies it to pattern2.tga to create temp3.tga
    Image img3("./input/layer1.tga");
    img3.multiply("./input/pattern2.tga", "./output/temp3.tga");
    Image imgText("./input/text.tga");
    // Screens temp3.tga with text.tga to create part3.tga
    imgText.screen("./output/temp3.tga", "./output/part3.tga");
    // Deletes temporary file temp3.tga
    remove("./output/temp3.tga");

    // Task 4
    // Creates img object with layer2.tga and mutiplies it to circles.tga to create temp4.tga
    Image img4("./input/layer2.tga");
    img4.multiply("./input/circles.tga", "./output/temp4.tga");
    Image imgPattern("./input/pattern2.tga");
    // Subtracts pattern2.tga from temp4.tga to create part4.tga
    imgPattern.subtract("./output/temp4.tga", "./output/part4.tga");
    // Deletes temporary file temp4.tga
    remove("./output/temp4.tga");

    // Task 5
    // Creates img object with layer1.tga and overlays it with pattern1.tga to create part5.tga
    Image img5("./input/layer1.tga");
    img5.overlay("./input/pattern1.tga", "./output/part5.tga");

    // Task 6
    // Creates img object with car.tga and adds 200 to its green channel to create part6.tga
    Image img6("./input/car.tga");
    img6.addGreenChannel(200);

    // Task 7
    // Creates img object with car.tga and sclaes red channel by 4 and blue channel by 0 to create part7.tga
    Image img7("./input/car.tga");
    img7.changeRedBlue();

    // Task 8
    // Creates img object with car.tga and seperates its channels into three seperate files to create part8_b.tga, part8_g.tga, part8_r.tga
    Image img8("./input/car.tga");
    img8.makeThreeChannel();

    // Task 9
    // Creates img object with layer_blue.tga and combines it with layer_green.tga and layer_red.tga to create part9.tga
    Image img9("./input/layer_blue.tga");
    img9.combineThree("./input/layer_green.tga", "./input/layer_red.tga");

    // Task 10
    // Creates img object with text2.tga and rotates it 180 degrees to create part10.tga
    Image img10("./input/text2.tga");
    img10.rotate();
}

