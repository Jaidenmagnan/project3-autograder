//Nitish Goel
//COP 3504C Project 3
//Sources: Jaiden (TA), https://tgaviewer.com/download.aspx,
//Sources:http://www.simplefilter.de/en/basics/mixmods.html, https://cplusplus.com/reference/cstdio/remove/

#include <filesystem>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstdio> //for remove function used in Extra Credit

using namespace std;
//I took the one file approach due to personal preference
struct Header //Header that includes all the protypes of the variables and functions I use
{
    //Image characteristics
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;

    unsigned char rgb_value;
    vector<unsigned char> rgb_value_collection;

    //Functions
    void Read(const char* image);
    void Write(const char* image);
    void Multiply(Header image2, const char* outputImage);
    void Subtract(Header image2, const char* outputImage);
    void Screen(Header image2, const char* outputImage);
    void Overlay(Header image2, const char* outputImage);
    void add_to_green_channel(int val, const char* outputImage);
    void Scale(float factor, int index, const char* outputImage);
    void separate_color(int index, const char* outputImage);
    void combine(Header green, Header blue, const char* outputImage);
    void flip(const char* outputImage);
    void CombineHorizontally(const Header& image1, const Header& image2, const char* outputImage);
    void CombineVertically(const Header& image1, const Header& image2, const char* outputImage);
    bool isEqualTo(const Header& image); //My tester function


};

void Header::Read(const char* image) { //To essentially load the images and "read" them to be edited/written
    ifstream file(image, ios::in | ios::binary);
    file.read((char*)&this->idLength, sizeof(this->idLength));
    file.read((char*)&this->colorMapType, sizeof(this->colorMapType));
    file.read((char*)&this->dataTypeCode, sizeof(this->dataTypeCode));
    file.read((char*)&this->colorMapOrigin, sizeof(this->colorMapOrigin));
    file.read((char*)&this->colorMapLength, sizeof(this->colorMapLength));
    file.read((char*)&this->colorMapDepth, sizeof(this->colorMapDepth));
    file.read((char*)&this->xOrigin, sizeof(this->xOrigin));
    file.read((char*)&this->yOrigin, sizeof(this->yOrigin));
    file.read((char*)&this->width, sizeof(this->width));
    file.read((char*)&this->height, sizeof(this->height));
    file.read((char*)&this->bitsPerPixel, sizeof(this->bitsPerPixel));
    file.read((char*)&this->imageDescriptor, sizeof(this->imageDescriptor));

    vector<unsigned char>temp_vector;
    for (int i = 0; i < ((int) this->width) * ((int) this->height) * 3; i++) {
        file.read((char *) &this->rgb_value, sizeof(this->rgb_value));
        temp_vector.push_back((unsigned char) this->rgb_value);
    }
    file.close();
    rgb_value_collection = temp_vector;
}

void Header::Write(const char* image) { //used to write the files into output folder (ex: part1.tga)
    ofstream file(image, ios::binary);
    file.write((char*)&this->idLength, sizeof(this->idLength));
    file.write((char*)&this->colorMapType, sizeof(this->colorMapType));
    file.write((char*)&this->dataTypeCode, sizeof(this->dataTypeCode));
    file.write((char*)&this->colorMapOrigin, sizeof(this->colorMapOrigin));
    file.write((char*)&this->colorMapLength, sizeof(this->colorMapLength));
    file.write((char*)&this->colorMapDepth, sizeof(this->colorMapDepth));
    file.write((char*)&this->xOrigin, sizeof(this->xOrigin));
    file.write((char*)&this->yOrigin, sizeof(this->yOrigin));
    file.write((char*)&this->width, sizeof(this->width));
    file.write((char*)&this->height, sizeof(this->height));
    file.write((char*)&this->bitsPerPixel, sizeof(this->bitsPerPixel));
    file.write((char*)&this->imageDescriptor, sizeof(this->imageDescriptor));

    for (int i = 0; i < rgb_value_collection.size(); i++) {
        file.write((char*)&rgb_value_collection[i], sizeof(rgb_value_collection[i]));
    }
    file.close();
}

bool Header::isEqualTo(const Header& image) { //USED TO CHECK if 2 IMAGES ARE EQUIVALENT
    //returns true if every header property is equal.
    if (
            this->idLength == image.idLength &&
            this->colorMapType == image.colorMapType &&
            this->dataTypeCode == image.dataTypeCode &&
            this->colorMapOrigin == image.colorMapOrigin &&
            this->colorMapLength == image.colorMapLength &&
            this->colorMapDepth == image.colorMapDepth &&
            this->xOrigin == image.xOrigin &&
            this->yOrigin == image.yOrigin &&
            this->width == image.width &&
            this->height == image.height &&
            this->bitsPerPixel == image.bitsPerPixel &&
            this->imageDescriptor == image.imageDescriptor &&
            this->rgb_value_collection == image.rgb_value_collection
            ) {
        return true;
    }
    return false;
}

void Header::Multiply(Header image2, const char* outputImage) { //MULTIPLY FUNCTION CALCULATIONS for tasks 1, 3, 4
    vector<unsigned char> temp_data;
    for(int i = 0; i < rgb_value_collection.size(); i++) {
        int a = (int) (rgb_value_collection[i]);
        int b = (int) (image2.rgb_value_collection[i]);
        unsigned char c3 = (char)((a*b/255.0f) + (0.5f));
        temp_data.push_back(c3);
    }
    rgb_value_collection = temp_data;
    Write(outputImage); //This is how the new image is written into the output file, done inside every function
}

void Header::Subtract(Header image2, const char* outputImage) { //Subtract function for tasks 2,4
    vector<unsigned char> temp_data;
    for(int i = 0; i < rgb_value_collection.size(); i++) {
        int a = (int) (rgb_value_collection[i]);
        int b = (int) (image2.rgb_value_collection[i]);
        unsigned char val;
        if(b - a >= 0) {
            val = (char)(b - a);
        } else {
            val =  (char) 0;
        }
        temp_data.push_back(val);
    }
    rgb_value_collection = temp_data;
    Write(outputImage);
}

void Header::Screen(Header image2, const char* outputImage) { //Screen function for task 3
    vector<unsigned char> temp_data;

    for (int i = 0; i < rgb_value_collection.size(); i++) {
        int a = (int) (rgb_value_collection[i]);
        int b = (int) (image2.rgb_value_collection[i]);
        float val = (1.0f - float(a / 255.0f)) * (1.0f - float(b / 255.0f));
        float final_result = 255.0f * (1.0f - val) + 0.5f;
        unsigned char img_data = static_cast<unsigned char>(static_cast<int>(final_result));
        temp_data.push_back(img_data);
    }
    rgb_value_collection = temp_data;
    Write(outputImage);
}

void Header::Overlay(Header image2, const char* outputImage) { //Overlay function for task 5
    vector<unsigned char> temp_data;
    for(int i = 0; i < rgb_value_collection.size(); i++) {
        int x = (int) (rgb_value_collection[i]);
        int y = (int) (image2.rgb_value_collection[i]);

        float a = x / 255.0f; //to temporarily store calculations for ease
        float b = y / 255.0f;

        unsigned char val;
        if(a <= 0.5) {
            float temp_result = a * b;
            val = (unsigned char)(int)((255.0f * (2.0f * temp_result)) + (0.5f));
        } else {
            float temp_result2 = (1.0f - a) * (1.0f - b);
            val = (unsigned char)(int)((255.0f * (1.0f - (2.0f * temp_result2))) + 0.5f);
        }

        temp_data.push_back(val);
    }
    rgb_value_collection = temp_data;
    Write(outputImage);
}

void Header::add_to_green_channel(int value, const char* outputImage) { //Adds green to image, for task 6

    for(int i = 1; i < rgb_value_collection.size(); i += 3) {
        if(((int)(rgb_value_collection[i] + value) > 255)) {
            rgb_value_collection[i] = (unsigned char)(255);
        } else if (((int)(rgb_value_collection[i] + value) < 0)) {
            rgb_value_collection[i] = (unsigned char)(0);
        } else {
            rgb_value_collection[i] = (unsigned char)((int)(rgb_value_collection[i] + value));
        }
    }

    Write(outputImage);
}

void Header::Scale(float factor, int index, const char* outputImage) { //Scales an image, for task 7
    for(int i = index; i < rgb_value_collection.size(); i += 3) {
        if (((int)rgb_value_collection[i] * factor) > 255){
            rgb_value_collection[i] = (unsigned char)255;
        } else {
            rgb_value_collection[i] = (unsigned char)((int)rgb_value_collection[i] * factor);
        }
    }
    Write(outputImage);
}

void Header::separate_color(int index, const char* outputImage) { //Essentially filters by red, green, blue for task 8
    vector<unsigned char> temp = rgb_value_collection;

    for(int i = 0; i < rgb_value_collection.size(); i++) {
        if(i % 3  == index) {
            if(index == 0) {
                rgb_value_collection[i + 1] = rgb_value_collection[i];
                rgb_value_collection[i + 2] = rgb_value_collection[i];
            } else if(index == 1) {
                rgb_value_collection[i - 1] = rgb_value_collection[i];
                rgb_value_collection[i + 1] = rgb_value_collection[i];
            } else if(index == 2) {
                rgb_value_collection[i - 1] = rgb_value_collection[i];
                rgb_value_collection[i - 2] = rgb_value_collection[i];
            }
        }
    }
    Write(outputImage);
    rgb_value_collection = temp;
}

void Header::combine(Header green, Header blue, const char* outputImage){ //combines 3 files into 1 file for task 9
    for (int i = 0; i < rgb_value_collection.size(); ++i){
        if (i % 3 == 0){
            rgb_value_collection[i] = blue.rgb_value_collection[i];
        } else if (i % 3 == 1) {
            rgb_value_collection[i] = green.rgb_value_collection[i];
        }
    }
    Write(outputImage);
}

void Header::flip(const char* outputImage) { //Rotates image 180 degrees for task 10
    vector<vector<unsigned char> > value;
    for (int i = 0; i < rgb_value_collection.size(); i = i + 3){
        vector<unsigned char> temp_data;
        temp_data.push_back(rgb_value_collection[i]);
        temp_data.push_back(rgb_value_collection[i+1]);
        temp_data.push_back(rgb_value_collection[i+2]);
        value.push_back(temp_data);
    }
    reverse(value.begin(), value.end());
    vector<unsigned char> temp_data;
    for (int i = 0; i < value.size(); ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            temp_data.push_back(value[i][j]);
        }
    }
    rgb_value_collection = temp_data;
    Write(outputImage);
}

//Combines 2 images side by side (horizontally)
void Header::CombineHorizontally(const Header& image1, const Header& image2, const char* outputImage) { //FOR EXTRA CREDIT
    // Calculate the new width for the combined image
    int newWidth = image1.width + image2.width;

    //create new vector to store combined RGB values
    vector<unsigned char> temp_data;

    // Combine rgb values horizontally
    for (int y = 0; y < image1.height; ++y) {
        //first img
        temp_data.insert(temp_data.end(), image1.rgb_value_collection.begin() + y * image1.width * 3,
                           image1.rgb_value_collection.begin() + (y + 1) * image1.width * 3);

        //second img
        temp_data.insert(temp_data.end(), image2.rgb_value_collection.begin() + y * image2.width * 3,
                           image2.rgb_value_collection.begin() + (y + 1) * image2.width * 3);
    }

    // Create a new Header object for the combined image
    Header combinedImage;

    //set parameters for the combined image
    combinedImage.idLength = image1.idLength;
    combinedImage.colorMapType = image1.colorMapType;
    combinedImage.dataTypeCode = image1.dataTypeCode;
    combinedImage.colorMapOrigin = image1.colorMapOrigin;
    combinedImage.colorMapLength = image1.colorMapLength;
    combinedImage.colorMapDepth = image1.colorMapDepth;
    combinedImage.xOrigin = image1.xOrigin;
    combinedImage.yOrigin = image1.yOrigin;
    combinedImage.width = newWidth;  // Updated width
    combinedImage.height = image1.height; // Height remains the same
    combinedImage.bitsPerPixel = image1.bitsPerPixel;
    combinedImage.imageDescriptor = image1.imageDescriptor;

    combinedImage.rgb_value_collection = temp_data;
    combinedImage.Write(outputImage);
}

//Combines images vertically
void Header::CombineVertically(const Header& image1, const Header& image2, const char* outputImage) { //FOR EXTRA CREDIT
    int newHeight = image1.height + image2.height;

    vector<unsigned char> combinedRGB;

    combinedRGB.insert(combinedRGB.end(), image1.rgb_value_collection.begin(), image1.rgb_value_collection.end());
    combinedRGB.insert(combinedRGB.end(), image2.rgb_value_collection.begin(), image2.rgb_value_collection.end());

    Header combinedImage;

    combinedImage.idLength = image1.idLength;
    combinedImage.colorMapType = image1.colorMapType;
    combinedImage.dataTypeCode = image1.dataTypeCode;
    combinedImage.colorMapOrigin = image1.colorMapOrigin;
    combinedImage.colorMapLength = image1.colorMapLength;
    combinedImage.colorMapDepth = image1.colorMapDepth;
    combinedImage.xOrigin = image1.xOrigin;
    combinedImage.yOrigin = image1.yOrigin;
    combinedImage.width = image1.width;
    combinedImage.height = newHeight;  //updated height
    combinedImage.bitsPerPixel = image1.bitsPerPixel;
    combinedImage.imageDescriptor = image1.imageDescriptor;

    combinedImage.rgb_value_collection = combinedRGB;
    combinedImage.Write(outputImage);
}

int main() {
    //TASK 1:
    Header task1_image1;
    task1_image1.Read("input/layer1.tga"); //Load the first image
    Header task1_image2;
    task1_image2.Read("input/pattern1.tga"); //Load the 2nd image

    //Perform the "function", in this case it is the Multiply function
    task1_image1.Multiply(task1_image2, "output/part1.tga"); //Write the resulting image (part1.tga) to output folder

    //To test if the output image and the example image match
    Header task1_test;
    task1_test.Read("examples/EXAMPLE_part1.tga");
    Header task1_output;
    task1_output.Read("output/part1.tga");

    if (task1_output.isEqualTo(task1_test)) {
        cout << "TASK #1 PASSED!" << endl;
    }
    else {
        cout << "TASK #1 FAILED" << endl;
    }

    /* Essentially, these steps are repeated for tasks 2-10 with a few changes as needed, but the idea is the same*/

    //TASK 2
    Header task2_image1;
    task2_image1.Read("input/layer2.tga");
    Header task2_image2;
    task2_image2.Read("input/car.tga");

    task2_image1.Subtract(task2_image2, "output/part2.tga");

    Header task2_test;
    task2_test.Read("examples/EXAMPLE_part2.tga");
    Header task2_output;
    task2_output.Read("output/part2.tga");

    if (task2_output.isEqualTo(task2_test)) {
        cout << "TASK #2 PASSED!" << endl;
    }
    else {
        cout << "TASK #2 FAILED" << endl;
    }

    //TASK 3
    Header task3_image1;
    task3_image1.Read("input/pattern2.tga");
    Header task3_image2;
    task3_image2.Read("input/layer1.tga");

    task3_image1.Multiply(task3_image2, "output/part3.tga");
    Header temp_result_task3;
    temp_result_task3.Read("output/part3.tga");

    Header top_layer_task3;
    top_layer_task3.Read("input/text.tga");
    top_layer_task3.Screen(temp_result_task3, "output/part3.tga");

    Header task3_test;
    task3_test.Read("examples/EXAMPLE_part3.tga");
    Header task3_output;
    task3_output.Read("output/part3.tga");

    if (task3_output.isEqualTo(task3_test)) {
        cout << "TASK #3 PASSED!" << endl;
    }
    else {
        cout << "TASK #3 FAILED" << endl;
    }

    //TASK 4
    Header task4_image1;
    task4_image1.Read("input/layer2.tga");
    Header task4_image2;
    task4_image2.Read("input/circles.tga");

    task4_image1.Multiply(task4_image2, "output/part4.tga");
    Header temp_result_task4;
    temp_result_task4.Read("output/part4.tga");

    Header top_layer_task4;
    top_layer_task4.Read("input/pattern2.tga");
    top_layer_task4.Subtract(temp_result_task4, "output/part4.tga");

    Header task4_test;
    task4_test.Read("examples/EXAMPLE_part4.tga");
    Header task4_output;
    task4_output.Read("output/part4.tga");

    if (task4_output.isEqualTo(task4_test)) {
        cout << "TASK #4 PASSED!" << endl;
    }
    else {
        cout << "TASK #4 FAILED" << endl;
    }

    //TASK 5
    Header task5_image1;
    task5_image1.Read("input/layer1.tga");
    Header task5_image2;
    task5_image2.Read("input/pattern1.tga");

    task5_image2.Overlay(task5_image1, "output/part5.tga");

    Header task5_test;
    task5_test.Read("examples/EXAMPLE_part5.tga");
    Header task5_output;
    task5_output.Read("output/part5.tga");

    if (task5_output.isEqualTo(task5_test)) {
        cout << "TASK #5 PASSED!" << endl;
    }
    else {
        cout << "TASK #5 FAILED" << endl;
    }

    //TASK 6
    Header task6_image1;
    task6_image1.Read("input/car.tga");
    task6_image1.add_to_green_channel(200, "output/part6.tga");
    Header task6_test;
    task6_test.Read("examples/EXAMPLE_part6.tga");
    Header task6_output;
    task6_output.Read("output/part6.tga");

    if (task6_output.isEqualTo(task6_test)) {
        cout << "TASK #6 PASSED!" << endl;
    }
    else {
        cout << "TASK #6 FAILED" << endl;
    }

    //TASK 7
    Header task7_image1;
    task7_image1.Read("input/car.tga");
    task7_image1.Scale(4.0f, 2, "output/part7.tga");

    Header task7_image2;
    task7_image2.Read("output/part7.tga");
    task7_image2.Scale(0.0f, 0, "output/part7.tga");

    Header task7_test;
    task7_test.Read("examples/EXAMPLE_part7.tga");
    Header task7_output;
    task7_output.Read("output/part7.tga");

    if (task7_output.isEqualTo(task7_test)) {
        cout << "TASK #7 PASSED!" << endl;
    }
    else {
        cout << "TASK #7 FAILED" << endl;
    }

    //TASK 8
    Header task8_image1;
    task8_image1.Read("input/car.tga");

    task8_image1.separate_color(0, "output/part8_b.tga");
    task8_image1.separate_color(1, "output/part8_g.tga");
    task8_image1.separate_color(2, "output/part8_r.tga");

    Header task8_test_red;
    Header task8_test_green;
    Header task8_test_blue;
    task8_test_red.Read("examples/EXAMPLE_part8_r.tga");
    task8_test_green.Read("examples/EXAMPLE_part8_g.tga");
    task8_test_blue.Read("examples/EXAMPLE_part8_b.tga");

    Header task8_output_red;
    Header task8_output_green;
    Header task8_output_blue;
    task8_output_red.Read("output/part8_r.tga");
    task8_output_green.Read("output/part8_g.tga");
    task8_output_blue.Read("output/part8_b.tga");

    if (task8_output_red.isEqualTo(task8_test_red) && task8_output_green.isEqualTo(task8_test_green) && task8_output_blue.isEqualTo(task8_test_blue)) {
        cout << "TASK #8 PASSED!" << endl;
    }
    else {
        cout << "TASK #8 FAILED" << endl;
    }

    //TASK 9
    Header task9_red_image;
    task9_red_image.Read("input/layer_red.tga");
    task9_red_image.rgb_value_collection.size();

    Header task9_green_image;
    Header task9_blue_image;
    task9_green_image.Read("input/layer_green.tga");
    task9_blue_image.Read("input/layer_blue.tga");

    task9_red_image.combine(task9_green_image, task9_blue_image, "output/part9.tga");

    Header task9_test;
    task9_test.Read("examples/EXAMPLE_part9.tga");
    Header task9_output;
    task9_output.Read("output/part9.tga");

    if (task9_output.isEqualTo(task9_test)) {
        cout << "TASK #9 PASSED!" << endl;
    }
    else {
        cout << "TASK #9 FAILED" << endl;
    }

    //TASK 10
    Header task10_image1;
    task10_image1.Read("input/text2.tga");

    task10_image1.flip("output/part10.tga");

    Header task10_test;
    task10_test.Read("examples/EXAMPLE_part10.tga");
    Header task10_output;
    task10_output.Read("output/part10.tga");

    if (task10_output.isEqualTo(task10_test)) {
        cout << "TASK #10 PASSED!" << endl;
    }
    else {
        cout << "TASK #10 FAILED" << endl;
    }

    //EXTRA CREDIT

    Header header;
    Header car, circles, text, pattern1;
    car.Read("./input/car.tga");
    circles.Read("./input/circles.tga");
    text.Read("./input/text.tga");
    pattern1.Read("./input/pattern1.tga");


    header.CombineHorizontally(car, circles, "output/placeholder1.tga"); //placeholder file
    header.CombineHorizontally(text, pattern1, "output/placeholder2.tga"); //2nd placeholder file

    //store the 2 horizontal pictures
    Header placeholder1, placeholder2;
    placeholder1.Read("output/placeholder1.tga");
    placeholder2.Read("output/placeholder2.tga");
    //combine the 2 pairs of photos vertically to form a quadrant
    header.CombineVertically(placeholder2, placeholder1, "output/extracredit.tga");

    //clean the placeholder files up
    remove("output/placeholder1.tga");
    remove("output/placeholder2.tga");

    Header EC_test;
    EC_test.Read("examples/EXAMPLE_extracredit.tga");
    Header EC_output;
    EC_output.Read("output/extracredit.tga");

    if (EC_output.isEqualTo(EC_test)) {
        cout << "EXTRA CREDIT PASSED!" << endl;
    }
    else {
        cout << "EXTRA CREDIT FAILED" << endl;
    }
    return 0;
}

