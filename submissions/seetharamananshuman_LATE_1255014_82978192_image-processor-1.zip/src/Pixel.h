#ifndef PROJECT3IMAGES_PIXEL_H
#define PROJECT3IMAGES_PIXEL_H

struct Pixel {
    //holds the data for each RGB component of the pixels
    unsigned char red;
    unsigned char green;
    unsigned char blue;

    //Default constructor
    Pixel();
    //In reverse order (BGR) because TGA is weird
    Pixel(unsigned char b, unsigned char g, unsigned char r);

    unsigned char getB() const;
    unsigned char getG() const;
    unsigned char getR() const;

};

#endif //PROJECT3IMAGES_PIXEL_H
