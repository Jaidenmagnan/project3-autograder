#include "Pixel.h"

Pixel::Pixel(unsigned char b, unsigned char g, unsigned char r) : blue(b), green(g), red(r) {}
Pixel::Pixel() : blue(0), green(0), red(0) {}

unsigned char Pixel::getB() const{
    return blue;
}
unsigned char Pixel::getG() const{
    return green;
}
unsigned char Pixel::getR() const{
    return red;
}