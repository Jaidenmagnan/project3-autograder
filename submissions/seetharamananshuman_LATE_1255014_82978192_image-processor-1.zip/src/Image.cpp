#include "Image.h"
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


//Given a TGA file, reads in the header data in the given format
int Image::getWidth() {
    return width;
}
int Image::getHeight(){
    return height;
}

void Image::readHeader(std::ifstream &file)
{
    //Used to check for errors
    if (!file.is_open())
    {
        std::cerr << "DID NOT OPEN" << std::endl;
        return;
    }

    //Using the variables defined in the .h file
    //Read in the header values using file stream
    //The only ones we care about are width and height
    file.read(&idLength, sizeof(idLength));
    file.read(&colorMapType, sizeof(colorMapType));
    file.read(&dataTypeCode, sizeof(dataTypeCode));
    file.read(reinterpret_cast<char*>(&colorMapOrigin), sizeof(colorMapOrigin));
    file.read(reinterpret_cast<char*>(&colorMapLength), sizeof(colorMapLength));
    file.read(&colorMapDepth, sizeof(colorMapDepth));
    file.read(reinterpret_cast<char*>(&xOrigin), sizeof(xOrigin));
    file.read(reinterpret_cast<char*>(&yOrigin), sizeof(yOrigin));
    file.read(reinterpret_cast<char*>(&width), sizeof(width));
    file.read(reinterpret_cast<char*>(&height), sizeof(height));
    file.read(&bitsPerPixel, sizeof(bitsPerPixel));
    file.read(&imageDescriptor, sizeof(imageDescriptor));

}

//This does the opposite of the readHeader method.
//Allows a new file to have a header so that we can put it in proper TGA format
void Image::writeHeader(ofstream &file)
{
    file.write(&idLength, sizeof(idLength));
    file.write(&colorMapType, sizeof(colorMapType));
    file.write(&dataTypeCode, sizeof(dataTypeCode));
    file.write(reinterpret_cast<char*>(&colorMapOrigin), sizeof(colorMapOrigin));
    file.write(reinterpret_cast<char*>(&colorMapLength), sizeof(colorMapLength));
    file.write(&colorMapDepth, sizeof(colorMapDepth));
    file.write(reinterpret_cast<char*>(&xOrigin), sizeof(xOrigin));
    file.write(reinterpret_cast<char*>(&yOrigin), sizeof(yOrigin));
    file.write(reinterpret_cast<char*>(&width), sizeof(width));
    file.write(reinterpret_cast<char*>(&height), sizeof(height));
    file.write(&bitsPerPixel, sizeof(bitsPerPixel));
    file.write(&imageDescriptor, sizeof(imageDescriptor));
}

//Once we have read the header, we can read the image (given the size, or number of pixels)
void Image::readImage(std::ifstream &file, int imageSize)
{
    //traverse through the bytes in the file
    for(unsigned int i = 0; i < imageSize; i++)
    {
        char B, G, R;

        //Read in the data for the current pixel
        file.read(&B, sizeof(B));
        file.read(&G, sizeof(G));
        file.read(&R, sizeof(R));

        //Add the pixel to this vector of pixels
        //move onto the next pixel in the loop
        image.push_back(Pixel(B,G,R));
    }
}

//The opposite of the above method - writes image data to a new file
//Takes in a vector of pixels as our current data
//We can perform the various maniuplations for this assignment for the different tasks directly
//on vectors, and then input them into this method to write the changes to our desired output files
void Image::writeImage(std::vector<Pixel> &data, std::ofstream &file, int imageSize){

    for (int i=0; i<imageSize; i++){
        //traverse the given vector of pixels, and get the data from each pixel in BGR format
        unsigned char B = data[i].getB();
        unsigned char G = data[i].getG();
        unsigned char R = data[i].getR();

        //write the values to our specified file
        file.write(reinterpret_cast<const char*>(&B), sizeof(B));
        file.write(reinterpret_cast<const char*>(&G), sizeof(G));
        file.write(reinterpret_cast<const char*>(&R), sizeof(R));

    }
}

Pixel Image::Multiply(const Pixel& fg, const Pixel& bg) {
    // using the multiplication algorithm found on http://www.simplefilter.de/en/basics/mixmods.html
    //Divide by 255.0f to normalize the value
    int B = (int)(((float)(fg.getB()) * bg.getB()) / 255.0f + 0.5f);
    if(B > 255) B = 255;
    else if(B < 0) B = 0;

    //repeat for green
    int G = (int)(((float)(fg.getG()) * bg.getG()) / 255.0f + 0.5f);
    if(G > 255) G = 255;
    else if(G < 0) G = 0;

    //repeat for red
    int R = (int)(((float)(fg.getR()) * bg.getR()) / 255.0f + 0.5f);
    if(R > 255) R = 255;
    else if(R < 0) R = 0;

    //return a pixel with the multiplied values
    return Pixel(B,G,R);
}

Pixel Image::Subtract(const Pixel& fg, const Pixel& bg)
{
    int B, G, R;

    //Simply subtract the values and check to make sure they are not out of bounds
    //if they are, then correct this by changing the value to 0 or 255 (whichever is closer)
    B = fg.getB()- bg.getB();
    if(B > 255) B = 255;
    else if(B < 0) B = 0;

    //repeat for green
    G = fg.getG()- bg.getG();
    if(G > 255) G = 255;
    else if(G < 0) G = 0;

    //repeat for red
    R = fg.getR()- bg.getR();
    if(R > 255) R = 255;
    else if(R < 0) R = 0;

    //return a pixel with the subtracted values
    return Pixel(B, G, R);
}

Pixel Image::Add(const Pixel& fg, const Pixel& bg)
{
    int B, G, R;

    //Simply add the values and check to make sure they are not out of bounds
    //if they are, then correct this by changing the value to 0 or 255 (whichever is closer)
    B = fg.getB() + bg.getB();
    if (B > 255) B = 255;
    else if (B < 0) B = 0;

    //repeat for green
    G = (fg.getG()) + (bg.getG());
    if (G > 255) G = 255;
    else if (G < 0) G = 0;

    //repeat for red
    R = (fg.getR()) + (bg.getR());
    if (R > 255) R = 255;
    else if (R < 0) R = 0;

    //return a pixel with the summed values
    return Pixel(B, G, R);
}

Pixel Image::Screen(const Pixel& fg, const Pixel& bg)
{
    int B, G, R;

    //Using the screen formula from http://www.simplefilter.de/en/basics/mixmods.html
    //C = 1 - (1-A)*(!-B)
    //Normalize the values (divide by 255, and thdn multiply the whole thing by 255 at the end_
    //Add 0.5f for rounding

    //First, do it on red
    R = (int)((1.0f - (1.0f - fg.getR() / 255.0f) * (1.0f - bg.getR() / 255.0f)) * 255.0f + 0.5f);
    if (R > 255) R = 255;
    else if (R < 0) R = 0;

    //Repeat for green
    G = (int)((1.0f - (1.0f - fg.getG() / 255.0f) * (1.0f - bg.getG() / 255.0f)) * 255.0f + 0.5f);
    if (G > 255) G = 255;
    else if (G < 0) G = 0;

    //repeat for blue
    B = (int)((1.0f - (1.0f - fg.getB() / 255.0f) * (1.0f - bg.getB() / 255.0f)) * 255.0f + 0.5f);
    if (B > 255) B = 255;
    else if (B < 0) B = 0;

    return Pixel(B, G, R);
}

Pixel Image::Overlay(const Pixel& fg, const Pixel& bg)
{
    int B, G, R;

    //Formula for overlay using a foreground image and a background image
    //From http://www.simplefilter.de/en/basics/mixmods.html

    if ((float)(bg.getB()) <= 0.5f*255.0f)
        B = (int)((2 * (float)(fg.getB()) * bg.getB()) / 255.0f + 0.5f);
    else
        B = (int)((1.0f - 2 * (1.0f - (float)(fg.getB()) / 255.0f) * (1.0f - (float)(bg.getB()) / 255.0f)) * 255.0f + 0.5f);

    if ((float)(bg.getG()) <= 0.5f*255.0f)
        G = (int)((2 * (float)(fg.getG()) * bg.getG()) / 255.0f + 0.5f);
    else
        G = (int)((1.0f - 2 * (1.0f - (float)(fg.getG()) / 255.0f) * (1.0f - (float)(bg.getG()) / 255.0f)) * 255.0f + 0.5f);

    if ((float)(bg.getR()) <= 0.5f*255.0f)
        R = (int)((2 * (float)(fg.getR()) * bg.getR()) / 255.0f + 0.5f);
    else
        R = (int)((1.0f - 2 * (1.0f - (float)(fg.getR()) / 255.0f) * (1.0f - (float)(bg.getR()) / 255.0f)) * 255.0f + 0.5f);

    return Pixel(B, G, R);
}
