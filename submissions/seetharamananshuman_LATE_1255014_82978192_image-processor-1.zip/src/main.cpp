#include <iostream>
#include <vector>
#include "Image.h"
#include "Pixel.h"
#include <fstream>
using namespace std;

int main(){

    //Part 1: Load the file “layer1.tga” and “pattern1.tga” (both from the input folder)
    //and blend them together using the Multiply algorithm (“layer1” would be considered the top layer).
    // Save the results as “part1.tga” (in the output folder)
    // and your file should match EXAMPLE_part1.tga (from the examples folder)

    //Create an image object to be manipulated. This will be repeated throughout the whole program
    Image layer1;
    //Create a file stream to read in the data to be stored in layer1
    std::ifstream layer1f("input/layer1.tga", std::ios::binary);
    //read in the header data and store it in layer1
    layer1.readHeader(layer1f);
    //find the image dimensions using the header data so that we can then read in the image
    int layer1Size = layer1.getWidth() * layer1.getHeight();
    //read in the image once we know our dimensions
    layer1.readImage(layer1f, layer1Size);

    // Repeat the process for pattern1
    Image pattern1;
    std::ifstream pattern1File("input/pattern1.tga", std::ios::binary);
    pattern1.readHeader(pattern1File);
    int pattern1Size = pattern1.getWidth() * pattern1.getHeight();
    pattern1.readImage(pattern1File, pattern1Size);
    pattern1File.close();

    //Use the multiplication method defined in Image.cpp to combined the two images
    std::vector<Pixel> part1Pixels;
    for (int i = 0; i < layer1Size; ++i) {
        Pixel part1Pixel = Image::Multiply(layer1.image[i], pattern1.image[i]);
        part1Pixels.push_back(part1Pixel);
    }
    //Write the resulting file to part1Result by opening an ofstream
    std::ofstream outputFile("output/part1.tga", std::ios::binary);
    //Write the header first using the static method writeHeader
    layer1.writeHeader(outputFile);
    //Write the imamge using the static method writeImage and the vector part1Pixels
    layer1.writeImage(part1Pixels, outputFile, layer1Size);
    //Close file stream
    outputFile.close();

    //Part 2Use the Subtract blending mode to combine “layer2.tga” (top layer) with “car.tga” (bottom layer).
   //This mode subtracts the top layer from the bottom layer.

   //Read in our data, Same process as part 1.
    Image layer2;
    std::ifstream layer2f("input/layer2.tga", std::ios::binary);
    layer2.readHeader(layer2f);
    int layer2Size = layer2.getWidth() * layer2.getHeight(); //the size of the image is the following product
    layer2.readImage(layer2f, layer2Size);
    layer2f.close();

    Image car;
    std::ifstream carf("input/car.tga", std::ios::binary);
    car.readHeader(carf);
    int carSize = car.getWidth() * car.getHeight();
    car.readImage(carf, carSize);
    layer1f.close();

    //Subtract layer 2 from car using our written function
    std::vector<Pixel> part2Pixels;
    for (int i = 0; i < layer2Size; ++i) {
        Pixel part2Pixel = Image::Subtract(car.image[i],layer2.image[i]);
        part2Pixels.push_back(part2Pixel);
    }

    //output the data to the file
    std::ofstream outputFile2("output/part2.tga", std::ios::binary);
    layer2.writeHeader(outputFile2);
    layer2.writeImage(part2Pixels, outputFile2, layer2Size);
    outputFile2.close();

    //Part 3Use the Multiply blending mode to combine “layer1.tga” with “pattern2.tga”, and store the
    //results temporarily. Load the image “text.tga” and, using that as the top layer, combine it with
    //the previous results of layer1/pattern2 using the Screen blending mode

    //Read in our data
    Image pattern2;
    std::ifstream pattern2f("input/pattern2.tga", std::ios::binary);
    pattern2.readHeader(pattern2f);
    int pattern2Size = pattern2.getWidth() * pattern2.getHeight(); //the size of the image is the following product
    pattern2.readImage(pattern2f, layer2Size);
    pattern2f.close();

    Image nlayer1;
    std::ifstream nlayer1f("input/layer1.tga", std::ios::binary);
    nlayer1.readHeader(nlayer1f);
    int nlayer1size = nlayer1.getWidth() * nlayer1.getHeight();
    nlayer1.readImage(nlayer1f, nlayer1size);
    nlayer1f.close();

    //create an intermediate vector temp3 to store our vector after the multiplication operation has been performed
    vector<Pixel> temp3;
    for(int i=0; i<layer1Size; ++i){
        Pixel part3Pixel = Image::Multiply(nlayer1.image[i], pattern2.image[i]);
        temp3.push_back(part3Pixel);
    }

    //Now, we want to add text to this image
    //Open the text file
    Image text;
    std::ifstream textf("input/text.tga", std::ios::binary);
    text.readHeader(textf);
    text.readImage(textf, layer1Size);
    textf.close();

    //Use the screen function written in Image.cpp to create a new vector part3Pixels
    //This will hold the image data to be submitted for part 3
    vector<Pixel> part3Pixels;
    for(int i=0; i<layer1Size; ++i){
        Pixel newPart3Pixel = Image::Screen(temp3[i], text.image[i]);
        part3Pixels.push_back(newPart3Pixel);
    }

    //Write the data to part3Result
    std::ofstream outputFile3("output/part3.tga", std::ios::binary);
    pattern2.writeHeader(outputFile3);
    pattern2.writeImage(part3Pixels, outputFile3, pattern2Size);
    outputFile3.close();


    //Part 4. Multiply “layer2.tga” with “circles.tga”, and store it. Load “pattern2.tga” and, using that as the
    //top layer, combine it with the previous result using the Subtract blending mode.

    //Read in data
    Image nlayer2;
    std::ifstream nlayer2f("input/layer2.tga", std::ios::binary);
    nlayer2.readHeader(nlayer2f);
    int nlayer2Size = nlayer2.getWidth() * nlayer2.getHeight(); //the size of the image is the following product
    nlayer2.readImage(nlayer2f, nlayer2Size);
    nlayer2f.close();

    Image circle;
    std::ifstream circlef("input/circles.tga", std::ios::binary);
    circle.readHeader(circlef);
    int circlesize = circle.getWidth() * circle.getHeight(); //the size of the image is the following product
    circle.readImage(circlef, circlesize);
    circlef.close();

    //create a vector circle2 to store the image data after the multiplication has been formed
    vector<Pixel> circle2;
    for(int i=0; i<circlesize; ++i){
        circle2.push_back(Image::Multiply(nlayer2.image[i], circle.image[i]));
    }

    //create a new vector sub to store the image data after the subtraction has been performed
    vector<Pixel> sub;
    for(int i=0; i<circlesize; ++i){
        sub.push_back(Image::Subtract(circle2[i], pattern2.image[i]));
    }

    //Write to the output file
    std::ofstream outputFile4("output/part4.tga", std::ios::binary);
    circle.writeHeader(outputFile4);
    circle.writeImage(sub, outputFile4, circlesize);
    outputFile4.close();


    //Part 5 Combine “layer1.tga” (as the top layer) with “pattern1.tga” using the Overlay blending mode.

    //read in data
    Image newlayer1;
    std::ifstream newlayer1f("input/layer1.tga", std::ios::binary);
    newlayer1.readHeader(newlayer1f);
    int newlayer1size = newlayer1.getWidth() * newlayer1.getHeight();
    newlayer1.readImage(newlayer1f, newlayer1size);
    newlayer1f.close();

    Image newpattern1;
    std::ifstream newpattern1f("input/pattern1.tga", std::ios::binary);
    newpattern1.readHeader(newpattern1f);
    int newpattern1size = newpattern1.getWidth() * newpattern1.getHeight();
    newpattern1.readImage(newpattern1f, newpattern1size);
    newpattern1f.close();

    //Create a vector to contain our data after we peform the overlay method, written in Image.cpp
    vector<Pixel> part5pixels;
    for(int i=0; i<newlayer1size; ++i) {
        part5pixels.push_back(Image::Overlay(newlayer1.image[i],newpattern1.image[i]));
    }

    //output the result of the overlay to the output file
    std::ofstream outputFile5("output/part5.tga", std::ios::binary);
    newlayer1.writeHeader(outputFile5);
    newlayer1.writeImage(part5pixels, outputFile5, newlayer1size);
    outputFile5.close();


  //PART 6  Load “car.tga” and add 200 to the green channel.

  //load in image data
    Image newCar;
    std::ifstream newcarf("input/car.tga", std::ios::binary);
    newCar.readHeader(newcarf);
    int newcarSize = newCar.getWidth() * newCar.getHeight();
    newCar.readImage(newcarf, newcarSize);
    newcarf.close();

    //create a new vector to store the pixel data for the updated image
    //simply traverse through all the current pixels, adding 200 to the green column
    // R and B stay constant
    //our method already handles if the current value +200 is greater than 255 so we don't have to worry about this
    vector<Pixel> part6pixels;
    for(int i=0; i<newcarSize; ++i){
        part6pixels.push_back(Image::Add(newCar.image[i], Pixel(0,200,0)));
    }

    //write to the desired file
    std::ofstream outputFile6("output/part6.tga", std::ios::binary);
    newCar.writeHeader(outputFile6);
    newCar.writeImage(part6pixels, outputFile6, newcarSize);
    outputFile6.close();



    //Part 7 Load “car.tga” and scale (multiply) the red channel by 4, and the blue channel by 0. This will
    //increase the intensity of any red in the image, while negating any blue it may have.

    Image part7car;
    std::ifstream part7carf("input/car.tga", std::ios::binary);
    part7car.readHeader(part7carf);
    int part7carsize = part7car.getWidth() * part7car.getHeight();
    part7car.readImage(part7carf, part7carsize);
    part7carf.close();



    //traverse thorugh the car elements and update their pixels, adding them to the part7pixels vector
    vector<Pixel> part7pixels;
    for (int i = 0; i < part7carsize; ++i) {
        //Scale the red column, leaving the green and blue columns the same
        int R = (int)(((float)(part7car.image[i].getR()) * 4.0f) + 0.5f);
        if (R > 255) R = 255;
        else if (R < 0) R = 0;

        part7pixels.push_back(Pixel(0, part7car.image[i].getG(), R));
    }

    //write to file to output
    std::ofstream outputFile7("output/part7.tga", std::ios::binary);
    part7car.writeHeader(outputFile7);
    part7car.writeImage(part7pixels, outputFile7, part7carsize);
    outputFile7.close();



    //Part 8. Load “car.tga” and write each channel to a separate file: the red channel should be “part8_r.tga”,
   // the green channel should be “part8_g.tga”, and the blue channel should be “part8_b.tga”

   //Load in data
    Image part8car;
    std::ifstream part8carf("input/car.tga", std::ios::binary);
    part8car.readHeader(part8carf);
    int part8carsize = part8car.getWidth() * part8car.getHeight();
    part8car.readImage(part8carf, part8carsize);
    part8carf.close();

    //Create three vectors to hold individual R, G, and B data
    std::vector<Pixel> red;
    std::vector<Pixel> green;
    std::vector<Pixel> blue;

    //traverse through the current image data
    //take the respective B, G, and R values and add them to their respective vectors of Pixels
    for (int i = 0; i < part8carsize; ++i) {
        red.push_back(Pixel(part8car.image[i].getR(), part8car.image[i].getR(), part8car.image[i].getR()));
        green.push_back(Pixel(part8car.image[i].getG(), part8car.image[i].getG(), part8car.image[i].getG()));
        blue.push_back(Pixel(part8car.image[i].getB(), part8car.image[i].getB(), part8car.image[i].getB()));
    }

    //Output the red channel vector alone to its own file
    std::ofstream redf("output/part8_r.tga", std::ios::binary);
    part8car.writeHeader(redf);
    part8car.writeImage(red, redf, part8carsize);
    redf.close();

    //Do the same for the green vector
    std::ofstream greenf("output/part8_g.tga", std::ios::binary);
    part8car.writeHeader(greenf);
    part8car.writeImage(green, greenf, part8carsize);
    greenf.close();

    //Do the same for the blue vector
    std::ofstream bluef("output/part8_b.tga", std::ios::binary);
    part8car.writeHeader(bluef);
    part8car.writeImage(blue, bluef, part8carsize);
    bluef.close();

    //Part 9 9. Load “layer_red.tga”, “layer_green.tga” and “layer_blue.tga”, and combine the three files into
    //one file. The data from “layer_red.tga” is the red channel of the new image, layer_green is
    //green, and layer_blue is blue.

    //Create a red layer by using the given data from layer_red.tga
    //Read in the data for it
    Image redlayer;
    std::ifstream redlayerf("input/layer_red.tga", std::ios::binary);
    redlayer.readHeader(redlayerf);
    int redlayersize = redlayer.getWidth() * redlayer.getHeight();
    redlayer.readImage(redlayerf, redlayersize);
    redlayerf.close();

    //Repeat for the blue layer
    Image bluelayer;
    std::ifstream bluelayerf("input/layer_blue.tga", std::ios::binary);
    bluelayer.readHeader(bluelayerf);
    bluelayer.readImage(bluelayerf, redlayersize);
    bluelayerf.close();

    //Repeat for the green layer
    Image greenlayer;
    std::ifstream greenlayerf("input/layer_green.tga", std::ios::binary);
    greenlayer.readHeader(greenlayerf);
    greenlayer.readImage(greenlayerf, redlayersize);
    greenlayerf.close();

    //Create a combined vector storing the image data from all three layers, R G and B combined
    vector<Pixel> combined;
    for (int i = 0; i < redlayersize; ++i) {
        combined.push_back( Pixel(bluelayer.image[i].getB(),
                                  greenlayer.image[i].getG(),
                                  redlayer.image[i].getR()));
    }

    //Write this combined image data to the output file
    std::ofstream outputFile9("output/part9.tga", std::ios::binary);
    redlayer.writeHeader(outputFile9);
    redlayer.writeImage(combined, outputFile9, redlayersize);
    outputFile9.close();


//Part 10 Load “text2.tga”, and rotate it 180 degrees, flipping it upside down. This is easier than you think!
//Try diagramming the data of an image (such as earlier in this document). What would the data
//look like if you flipped it? Now, how to write some code to accomplish that...?

    Image text2;
    std::ifstream text2f("input/text2.tga", std::ios::binary);
    text2.readHeader(text2f);
    int text2size = text2.getWidth()*text2.getHeight();
    text2.readImage(text2f, text2size);
    text2f.close();

    //First, define a vector t1 containing the pixels in their normal order
    //Traverse through the image data array to populate it
    //count represents the current index we are at
    //incriment this by one each time
    int count=0;
    vector<vector<Pixel>> t1(text2.getHeight(), vector<Pixel>(text2.getWidth()));// Populate t1
    for (int i = 0; i < text2.getHeight(); ++i) {
        for (int j = 0; j < text2.getWidth(); ++j) {
            t1[i][j] = text2.image[count];
            count++;
        }
    }

    //now, reverse the order we are traversing in to flip the image 180 degrees
    //start at the first row, but in the last column
    //add all our values to a new vector, part10pixels
    vector<Pixel> part10pixels;
    for (int i = text2.getHeight() - 1; i >= 0; --i) {
        for (int j = text2.getWidth() - 1; j >= 0; --j) {
            part10pixels.push_back(t1[i][j]);
        }
    }

    //write the data from part10pixels vector to outputFile10
    std::ofstream outputFile10("output/part10.tga", std::ios::binary);
    text2.writeHeader(outputFile10);
    text2.writeImage(part10pixels, outputFile10, text2size);
    outputFile10.close();

    return 0;
};