
using namespace std;

#ifndef PROJECT3IMAGES_IMAGE_H
#define PROJECT3IMAGES_IMAGE_H

#include <vector>
#include <iostream>
#include "Pixel.h"

class Image{

public:
    //Vector to represent the image data, made of pixels (each pixel holds 3 integers)
    std::vector<Pixel> image;

    //Variables for the header with the correct types
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;

    Image() {}
    int getWidth();
    int getHeight();

    //Methods to read image data, takes in references
    void readHeader(std::ifstream &file);
    void readImage(std::ifstream &file, int imageSize);

    //Methods to write image data to files, again, takes in refereneces
    void writeHeader(std::ofstream &file);
    void writeImage(std::vector<Pixel> &data, std::ofstream &file, int imageSize);

    //Static methods to perform different operations
    //Since they are static, i performed them on arbitrary Image obejcts when I was writing to files in the main code
    static Pixel Subtract(const Pixel& fg, const Pixel& bg);
    static Pixel Multiply(const Pixel& fg, const Pixel& bg);
    static Pixel Screen(const Pixel& fg, const Pixel& bg);
    static Pixel Overlay(const Pixel& fg, const Pixel& bg);
    static Pixel Add(const Pixel& fg, const Pixel& bg);

};


#endif //PROJECT3IMAGES_IMAGE_H