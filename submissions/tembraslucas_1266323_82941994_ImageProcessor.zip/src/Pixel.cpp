#include "Pixel.h"

Pixel::Pixel(const unsigned char &blue, const unsigned char &green, const unsigned char &red){ //Pixel constructor definition
    this->blue = blue;
    this->green = green;
    this->red = red;
};