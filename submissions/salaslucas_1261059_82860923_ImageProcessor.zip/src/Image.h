#pragma once
#include "Pixel.h"
#include "vector"
#include "Channel.h"
#include "string"

using namespace std;

class Image {
public:
    Image(unsigned short , unsigned short);
    Image(string);
    Image(unsigned char*, int);
    vector<Pixel*> pixels;
    unsigned short width;
    unsigned short height;

    static Image* multiply(Image* A, Image* B);
    static Image* subtract(Image* A, Image* B);
    static Image* screen(Image* A, Image* B);
    static Image* overlay(Image* A, Image* B);
    static Image* add(Image* A, Image* B);
    void channelMultiply(Channel channel, float multiplier);
    void channelAdd(Channel channel, int add);
    vector<unsigned char>* outputTgaData();
    bool writeTGAile(string path);

private:
    bool areSameSize(Image A, Image B);
    void loadTGAData(unsigned char*, int);
    unsigned char* shortToChars(unsigned short &s);
    static unsigned char channelOverlay(Channel channel, Pixel* A, Pixel* B);
    static unsigned char channelOverlay(unsigned char& A, unsigned char& B);

};