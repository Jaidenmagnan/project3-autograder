//
// Created by acrud on 10/31/2023.
//

#include <fstream>
#include <algorithm>
#include "Image.h"
#include "iostream"

Image* Image::multiply(Image* A, Image* B) {
    Image* result = new Image(A->width, A->height);

    for (int i = 0; i < A->pixels.size(); ++i) {
        result->pixels.push_back(new Pixel(*(A->pixels[i]) * *(B->pixels[i])));
    }

    return result;
}

// Handles overlay for each channel
unsigned char Image::channelOverlay(Channel channel, Pixel *A, Pixel *B) {
    switch (channel) {
        case Red:
            return channelOverlay(A->R, B->R);
        case Green:
            return channelOverlay(A->G, B->G);
        case Blue:
            return channelOverlay(A->B, B->B);
    }
}

// Does overlay for single channel
unsigned char Image::channelOverlay(unsigned char& A, unsigned char& B){
    float result = 0;
    float nA = A/255.0f;
    float nB = B/255.0f;
    
    if(nB <= 0.5) result = 255 * nA * nB * 2;
    else result = 255.0f * (1 - 2*(1 - nA)*(1 - nB));

    return (unsigned char)(result +.5f);
}

// Doe overlay for all channels
Image *Image::overlay(Image *A, Image *B) {
    Image* result = new Image(A->width, A->height);

    for (int i = 0; i < A->pixels.size(); ++i) {
        auto pR = new Pixel(0,0,0);

        pR->R = Image::channelOverlay(Red, A->pixels[i], B->pixels[i]);
        pR->G = Image::channelOverlay(Green, A->pixels[i], B->pixels[i]);
        pR->B = Image::channelOverlay(Blue, A->pixels[i], B->pixels[i]);

        result->pixels.push_back(pR);
    }

    return result;
}

Image *Image::screen(Image *A, Image *B) {
    Image* result = new Image(A->width, A->height);

    for (int i = 0; i < A->pixels.size(); ++i) {
        result->pixels.push_back(Pixel::screen(A->pixels[i], B->pixels[i]));
    }

    return result;
}

Image* Image::subtract(Image* A, Image* B) {
    Image* result = new Image(A->width, A->height);

    for (int i = 0; i < A->pixels.size(); ++i) {
        result->pixels.push_back(new Pixel(*(A->pixels[i]) - *(B->pixels[i])));
    }

    return result;
}


Image *Image::add(Image *A, Image *B) {
    Image* result = new Image(A->width, A->height);

    for (int i = 0; i < A->pixels.size(); ++i) {
        result->pixels.push_back(new Pixel(*(A->pixels[i]) + *(B->pixels[i])));
    }

    return result;
}

// Loads TGA data into the image
void Image::loadTGAData(unsigned char *tgaData, int data_size) {
    // Grab height and width
    width = ((tgaData[13] << 8) | tgaData[12]);
    height = ((tgaData[15] << 8) | tgaData[14]);

    // Add all pixels (starting w/ 19th byte)
    for (int i = 18; i < data_size; i+=3) {
        Pixel* p = new Pixel(tgaData[i + 2], tgaData[i + 1], tgaData[i]);

        pixels.push_back(p);
    }
}

Image::Image(unsigned short _width, unsigned short _height) : pixels(){
    width = _width;
    height = _height;
}
Image::Image(unsigned char *tgaData, int data_size) : width(0), height(0), pixels(){
    loadTGAData(tgaData, data_size);
}
Image::Image(string _filePath) : width(0), height(0), pixels() {
    ifstream fileStream(_filePath, ios::binary);

    if(fileStream.is_open()){
        // Get size of file for buffer
        fileStream.seekg(0, ios::end);
        int size = fileStream.tellg();
        fileStream.seekg(0, ios::beg);

        // Create buffer and read
        auto readData = new unsigned char[size];
        fileStream.read((char*) readData, size);

        // Load data to Image
        loadTGAData(readData, size);

        fileStream.close();
        delete[] readData;
    }
    else{
        cerr << "Error opening the file at: " << _filePath;
    }
}

// Converts shorts to two chars for binary storage
unsigned char *Image::shortToChars(unsigned short &s) {
    unsigned char high = (s >> 8) & 0xFF;
    unsigned char low = s & 0xFF;

    return new unsigned char[] {high, low};
}

vector<unsigned char>* Image::outputTgaData() {
    auto output = new vector<unsigned char>(18, 0);

    // store Image Type
    output->at(2) = 2;

    // Store pixel depth
    output->at(16) = 24;

    // store width
    unsigned char* widthChars = shortToChars(width);
    output->at(13) = widthChars[0];
    output->at(12) = widthChars[1];

    // store height
    unsigned char* heightChars = shortToChars(height);
    output->at(15) = heightChars[0];
    output->at(14) = heightChars[1];

    // store all pixels
    for (int i = 0; i < pixels.size(); ++i) {
        output->push_back(pixels[i]->B);
        output->push_back(pixels[i]->G);
        output->push_back(pixels[i]->R);
    }

    return output;
}

// Exports a TGA file from an image object
bool Image::writeTGAile(string path) {
    auto outputData = outputTgaData();
    ofstream fileWrite(path, ios::binary);
    if(fileWrite){
        fileWrite.write((char*)outputData->data(), outputData->size());
        return true;
    }

    return false;
}

// Adds to an entire channel
void Image::channelAdd(Channel channel, int add) {
    for (auto p : pixels) {
        switch (channel) {
            case Red:
                p->R = clamp(((int)p->R) + add, 0, 255);
                break;
            case Green:
                p->G = clamp(((int)p->G) + add, 0, 255);
                break;
            case Blue:
                p->B = clamp(((int)p->B) + add, 0, 255);
                break;
        }
    }
}

// Multiplies an entire channel
void Image::channelMultiply(Channel channel, float multiplier) {
    for (auto p : pixels) {
        switch (channel) {
            case Red:
                p->R = clamp((int)(((int)p->R) * multiplier), 0, 255);
                break;
            case Green:
                p->G = clamp((int)(((int)p->G) * multiplier), 0, 255);
                break;
            case Blue:
                p->B = clamp((int)(((int)p->B) * multiplier), 0, 255);
                break;
        }
    }
}

