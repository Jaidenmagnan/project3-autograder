#include "Pixel.h"
#include "algorithm"

Pixel::Pixel() : Pixel(0,0,0) {}

Pixel::Pixel(int r, int g, int b) {
    R = clamp(r, 0, 255);
    G = clamp(g, 0, 255);
    B = clamp(b, 0, 255);
}

Pixel::Pixel(const Pixel &otherObject) {
    R = otherObject.R;
    G = otherObject.G;
    B = otherObject.B;
}

Pixel* Pixel::screen(Pixel *A, Pixel *B) {
    return new Pixel(screenValue(A->R, B->R), screenValue(A->G, B->G), screenValue(A->B, B->B));
}

int Pixel::screenValue(unsigned char& A, unsigned char& B) {
    float result = 0;
    float nA = A/255.0f;
    float nB = B/255.0f;

    result = 255.0f * (1 - (1 - nA)*(1 - nB));

    return (unsigned char)(result +.5f);
}