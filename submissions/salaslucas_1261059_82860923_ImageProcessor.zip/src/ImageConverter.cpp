#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include "Image.h"
#include <vector>
#include <algorithm>

using namespace std;

// Tests files against pixel data
bool testOutputWithInput(string _exampleFilePath, unsigned char* _outputData, int _outputDataSize){
    ifstream fileStream(_exampleFilePath, ios::binary);

    bool doDebug = false;
    bool isSame = true;

    if(fileStream.is_open()){
        // Get size of file for buffer
        fileStream.seekg(0, ios::end);
        int size = fileStream.tellg();
        fileStream.seekg(0, ios::beg);

        // Create buffer and read
        unsigned char* readData = new unsigned char[size];
        fileStream.read((char*) readData, size);

        // Test if the same
        for (int i = 0; i < _outputDataSize; ++i) {
            if(_outputData[i] != readData[i]){
                if(doDebug){
                    cout << "\nFound mismatch at i = " << i << " where "
                         << "\n\texample[i]: " << to_string((int)readData[i])
                         << "\n\toutput[i]: " << to_string((int)_outputData[i]);
                }

                isSame = false;
            }
        }

        fileStream.close();
        delete[] readData;
    }
    else{
        cerr << "Error opening the file at: " << _exampleFilePath;
        isSame = false;
    }

    return isSame;
}

// Tests files against files
bool testOutputWithInput(string _exampleFilePath, string _outputtedFilePath){
    ifstream outputtedFileStream(_outputtedFilePath, ios::binary);
    if(outputtedFileStream.is_open() && outputtedFileStream.is_open()){
        // Get size of file for buffer
        outputtedFileStream.seekg(0, ios::end);
        int outputtedSize = outputtedFileStream.tellg();
        outputtedFileStream.seekg(0, ios::beg);

        // Create buffer and read
        auto outputReadData = new unsigned char[outputtedSize];
        outputtedFileStream.read((char*) outputReadData, outputtedSize);

        return testOutputWithInput(_exampleFilePath, outputReadData, outputtedSize);
    }
    else{
        cerr << "Error opening the file at: " << _exampleFilePath;
    }

    return false;
}

bool task1(){
    Image layer1("input/layer1.tga");
    Image pattern1("input/pattern1.tga");

    Image* result = Image::multiply(&layer1, &pattern1);
    result->writeTGAile("output/part1.tga");

    return testOutputWithInput("examples/EXAMPLE_part1.tga", "output/part1.tga");
}
bool task2(){
    Image car("input/car.tga");
    Image layer2("input/layer2.tga");

    Image* result = Image::subtract(&car, &layer2);
    result->writeTGAile("output/part2.tga");

    return testOutputWithInput("examples/EXAMPLE_part2.tga", "output/part2.tga");
}
bool task3(){
    Image layer1("input/layer1.tga");
    Image pattern2("input/pattern2.tga");

    Image* multResult = Image::multiply(&layer1, &pattern2);

    Image text("input/text.tga");
    Image* screenResult = Image::screen(multResult,&text);
    screenResult->writeTGAile("output/part3.tga");

    return testOutputWithInput("examples/EXAMPLE_part3.tga", "output/part3.tga");
}
bool task4(){
    Image layer2("input/layer2.tga");
    Image circles("input/circles.tga");

    Image* multResult = Image::multiply(&layer2, &circles);

    Image pattern2("input/pattern2.tga");
    Image* result = Image::subtract(multResult, &pattern2);
    result->writeTGAile("output/part4.tga");

    return testOutputWithInput("examples/EXAMPLE_part4.tga", "output/part4.tga");
}
bool task5(){
    Image layer1("input/layer1.tga");
    Image pattern1("input/pattern1.tga");

    Image* result = Image::overlay(&layer1, &pattern1);

    result->writeTGAile("output/part5.tga");

    return testOutputWithInput("examples/EXAMPLE_part5.tga", "output/part5.tga");
}
bool task6(){
    Image car("input/car.tga");

    car.channelAdd(Green, 200);

    car.writeTGAile("output/part6.tga");

    return testOutputWithInput("examples/EXAMPLE_part6.tga", "output/part6.tga");
}
bool task7(){
    Image car("input/car.tga");

    car.channelMultiply(Red, 4);
    car.channelMultiply(Blue, 0);

    car.writeTGAile("output/part7.tga");

    return testOutputWithInput("examples/EXAMPLE_part7.tga", "output/part7.tga");
}
bool task8(){
    Image car("input/car.tga");

    Image carR(car.width, car.height);
    Image carG(car.width, car.height);
    Image carB(car.width, car.height);

    for (int i = 0; i < car.pixels.size(); ++i) {
        carR.pixels.push_back(new Pixel(car.pixels[i]->R, car.pixels[i]->R, car.pixels[i]->R));
        carG.pixels.push_back(new Pixel(car.pixels[i]->G, car.pixels[i]->G, car.pixels[i]->G));
        carB.pixels.push_back(new Pixel(car.pixels[i]->B, car.pixels[i]->B, car.pixels[i]->B));
    }

    carR.writeTGAile("output/part8_r.tga");
    carG.writeTGAile("output/part8_g.tga");
    carB.writeTGAile("output/part8_b.tga");

    bool r_pass = testOutputWithInput("examples/EXAMPLE_part8_r.tga", "output/part8_r.tga");
    bool g_pass = testOutputWithInput("examples/EXAMPLE_part8_g.tga", "output/part8_g.tga");
    bool b_pass = testOutputWithInput("examples/EXAMPLE_part8_b.tga", "output/part8_b.tga");

    return r_pass && g_pass && b_pass;
}
bool task9(){
    Image layer_red("input/layer_red.tga");
    Image layer_blue("input/layer_blue.tga");
    Image layer_green("input/layer_green.tga");

    Image result(layer_red.width, layer_red.height);

    for (int i = 0; i < layer_red.pixels.size(); ++i) {
        result.pixels.push_back(new Pixel(layer_red.pixels[i]->R,layer_green.pixels[i]->G,layer_blue.pixels[i]->B));
    }

    result.writeTGAile("output/part9.tga");

    return testOutputWithInput("examples/EXAMPLE_part9.tga", "output/part9.tga");
}
bool task10(){
    Image text2("input/text2.tga");

    reverse(text2.pixels.begin(), text2.pixels.end());

    text2.writeTGAile("output/part10.tga");

    return testOutputWithInput("examples/EXAMPLE_part10.tga", "output/part10.tga");

}
bool task11(){
    Image car("input/car.tga");
    Image circles("input/circles.tga");
    Image pattern1("input/pattern1.tga");
    Image text("input/text.tga");

    Image result(1024,1024);

    // first two
    for (int r = 0; r < 512; ++r) {
        for (int c = 0; c < 512; ++c) {
            result.pixels.push_back(text.pixels[r*512 + c]);
        }
        for (int c = 0; c < 512; ++c) {
            result.pixels.push_back(pattern1.pixels[r*512 + c]);
        }
    }

    // second two
    for (int r = 0; r < 512; ++r) {
        for (int c = 0; c < 512; ++c) {
            result.pixels.push_back(car.pixels[r*512 + c]);
        }
        for (int c = 0; c < 512; ++c) {
            result.pixels.push_back(circles.pixels[r*512 + c]);
        }

    }

    result.writeTGAile("output/extracredit.tga");
    return testOutputWithInput("examples/EXAMPLE_extracredit.tga", "output/extracredit.tga");

}

int main() {
    cout << "\nTask 1.... " << (task1() ? "Pass" : "Fail");
    cout << "\nTask 2.... " << (task2() ? "Pass" : "Fail");
    cout << "\nTask 3.... " << (task3() ? "Pass" : "Fail");
    cout << "\nTask 4.... " << (task4() ? "Pass" : "Fail");
    cout << "\nTask 5.... " << (task5() ? "Pass" : "Fail");
    cout << "\nTask 6.... " << (task6() ? "Pass" : "Fail");
    cout << "\nTask 7.... " << (task7() ? "Pass" : "Fail");
    cout << "\nTask 8.... " << (task8() ? "Pass" : "Fail");
    cout << "\nTask 9.... " << (task9() ? "Pass" : "Fail");
    cout << "\nTask 10... " << (task10() ? "Pass" : "Fail");
    cout << "\nTask EC... " << (task11() ? "Pass" : "Fail");
    return 0;
}
