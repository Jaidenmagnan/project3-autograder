enum Channel {
    Red,
    Green,
    Blue
};
