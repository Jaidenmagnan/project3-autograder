#pragma once
#include <cstdint>
#include <cmath>

using namespace std;

class Pixel {
public:
    Pixel();
    Pixel(int, int, int);
    Pixel(const Pixel &otherObject);
    unsigned char B;
    unsigned char G;
    unsigned char R;

    inline Pixel operator*(const Pixel& rhs) const {
        return Pixel(R/255.0 * rhs.R/255.0 * 255 + .5f, G/255.0 * rhs.G/255.0 * 255 + .5f, B/255.0 * rhs.B/255.0 * 255 + .5f);

    }
    inline Pixel operator+(const Pixel& rhs) const {
        return Pixel(R + (int)rhs.R, G + (int)rhs.G, B + (int)rhs.B);
    }
    inline Pixel operator-(const Pixel& rhs) const {
        return Pixel(R - (int)rhs.R, G - (int)rhs.G, B - (int)rhs.B);
    }
    static Pixel* screen(Pixel* A, Pixel* B);
    static int screenValue(unsigned char&, unsigned char&);
};