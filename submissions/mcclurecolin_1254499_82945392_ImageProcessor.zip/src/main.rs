// An image processing application that outputs images based on specific instructions denoted by parts
// Name: Colin McClure

use crate::files::write_file_using_data;
use crate::images::{BlendingMode, RGBChannel, RGBChannelModification, RGBModificationAction, TGAImage};

mod files;
mod images;

// The entrypoint: the main function will delegate all parts to helper functions
// These helper functions utilize other functions from the images and files modules to:
// - load images
// - modify images
// - write images
// This trend is followed through uniformly for all methods in the main module.
// Refer to the modules for more detailed documentation
fn main() {
    do_part_one().expect("part one failed");
    do_part_two().expect("part two failed");
    do_part_three().expect("part three failed");
    do_part_four().expect("part four failed");
    do_part_five().expect("part five failed");
    do_part_six().expect("part six failed");
    do_part_seven().expect("part seven failed");
    do_part_eight();
    do_part_nine().expect("part nine failed");
    do_part_ten().expect("part ten failed");
}

fn do_part_one() -> std::io::Result<()> {
    // import the two files
    let layer = files::load_file_by_name("input/layer1.tga").expect("part one: could not get layer image");
    let pattern = files::load_file_by_name("input/pattern1.tga").expect("part one: could not get pattern image");
    let blended_image = images::blend_using_mode(&layer, &pattern, BlendingMode::Multiply);
    write_file_using_data("output/part1.tga", &blended_image)
}

fn do_part_two() -> std::io::Result<()>  {
    let layer = files::load_file_by_name("input/layer2.tga").expect("part two: could not get layer image");
    let car = files::load_file_by_name("input/car.tga").expect("part two: could not get car image");
    let blended_image = images::blend_using_mode(&layer, &car, BlendingMode::Subtract);
    write_file_using_data("output/part2.tga", &blended_image)
}

fn do_part_three() -> std::io::Result<()> {
    let layer = files::load_file_by_name("input/layer1.tga").expect("part three: could not get layer image");
    let circles = files::load_file_by_name("input/pattern2.tga").expect("part three: could not get circles image");
    let multiply_blended_image = images::blend_using_mode(&layer, &circles, BlendingMode::Multiply);
    let text = files::load_file_by_name("input/text.tga").expect("part three: could not get text image");
    let screen_blended_image = images::blend_using_mode(&multiply_blended_image, &text, BlendingMode::Screen);
    write_file_using_data("output/part3.tga", &screen_blended_image)
}

fn do_part_four() -> std::io::Result<()> {
    let layer = files::load_file_by_name("input/layer2.tga").expect("part four: could not get layer image");
    let circles = files::load_file_by_name("input/circles.tga").expect("part four: could not get circles image");
    let multiply_blended_image = images::blend_using_mode(&layer, &circles, BlendingMode::Multiply);
    let pattern = files::load_file_by_name("input/pattern2.tga").expect("part four: could not get pattern image");
    let blended_image = images::blend_using_mode(&pattern, &multiply_blended_image, BlendingMode::Subtract);
    write_file_using_data("output/part4.tga", &blended_image)
}

fn do_part_five() -> std::io::Result<()> {
    let layer = files::load_file_by_name("input/layer1.tga").expect("part five: could not get layer image");
    let pattern = files::load_file_by_name("input/pattern1.tga").expect("part five: could not get pattern image");
    let blended_image = images::blend_using_mode(&layer, &pattern, BlendingMode::Overlay);
    write_file_using_data("output/part5.tga", &blended_image)
}

fn do_part_six() -> std::io::Result<()> {
    let car = files::load_file_by_name("input/car.tga").expect("part six: could not get car image");
    let new_car = images::modify_image_by_specification(&car, &vec![
        RGBChannelModification {
            channel: RGBChannel::Green,
            action: RGBModificationAction::Add,
            value: 200,
        }
    ]);
    write_file_using_data("output/part6.tga", &new_car)
}

fn do_part_seven() -> std::io::Result<()> {
    let car = files::load_file_by_name("input/car.tga").expect("part seven: could not get car image");
    let new_car = images::modify_image_by_specification(&car, &vec![
        RGBChannelModification {
            channel: RGBChannel::Red,
            action: RGBModificationAction::Multiply,
            value: 4
        },
        RGBChannelModification {
            channel: RGBChannel::Blue,
            action: RGBModificationAction::Multiply,
            value: 0
        }
    ]);
    write_file_using_data("output/part7.tga", &new_car)
}

fn do_part_eight() {
    let car = files::load_file_by_name("input/car.tga").expect("part eight: could not get car image");
    let r_car = images::image_by_single_channel(&car, RGBChannel::Red);
    write_file_using_data("output/part8_r.tga", &r_car).expect("part eight: failed to write R channel");
    let g_car = images::image_by_single_channel(&car, RGBChannel::Green);
    write_file_using_data("output/part8_g.tga", &g_car).expect("part eight: failed to write G channel");
    let b_car = images::image_by_single_channel(&car, RGBChannel::Blue);
    write_file_using_data("output/part8_b.tga", &b_car).expect("part eight: failed to write B channel");
}

fn do_part_nine() -> std::io::Result<()> {
    let layer_red = files::load_file_by_name("input/layer_red.tga").expect("part nine: could not get layer_red image");
    let layer_green = files::load_file_by_name("input/layer_green.tga").expect("part nine: could not get layer_green image");
    let layer_blue = files::load_file_by_name("input/layer_blue.tga").expect("part nine: could not get layer_blue image");
    let combined_image = TGAImage {
        header: layer_red.header,
        data: images::construct_pixel_array_from_channels(layer_red.data.len(), &layer_red.data, &layer_green.data, &layer_blue.data),
    };
    write_file_using_data("output/part9.tga", &combined_image)
}

fn do_part_ten() -> std::io::Result<()> {
    let text = files::load_file_by_name("input/text2.tga").expect("part ten: could not get text image");
    let rotated_text = images::rotate_image_by_180_degrees(&text);
    write_file_using_data("output/part10.tga", &rotated_text)
}
