// The images module is what handles image modification and produces new images

// The TGA image in its full glory
pub struct TGAImage {
    pub(crate) header: TGAImageHeader,
    pub(crate) data: Vec<[u8; 3]>,
}

// The header of the TGA image
#[derive(Clone, Copy)]
pub struct TGAImageHeader {
    pub(crate) id_length: u8,
    pub(crate) color_map_type: u8,
    pub(crate) data_type_code: u8,
    pub(crate) color_map_origin: i16,
    pub(crate) color_map_length: i16,
    pub(crate) color_map_depth: u8,
    pub(crate) x_origin: i16,
    pub(crate) y_origin: i16,
    pub(crate) width: i16,
    pub(crate) height: i16,
    pub(crate) bits_per_pixel: u8,
    pub(crate) image_descriptor: u8,
}

// The specific type of blending mode
#[derive(Clone, Copy)]
pub enum BlendingMode {
    Multiply,
    Subtract,
    Screen,
    Overlay,
}

// The specific RGB channel to target in certain scenarios (such as when writing a single channel to a file)
#[derive(Clone, Copy)]
pub enum RGBChannel {
    Red = 0,
    Green = 1,
    Blue = 2,
}

// The type of modification to do on a single file (such as add or multiply)
pub enum RGBModificationAction {
    Add,
    Multiply
}

// The information for a modification to do on a single file, containing a channel type, a modification type, and a value acting as a "magnitude"
pub struct RGBChannelModification {
    pub(crate) channel: RGBChannel,
    pub(crate) action: RGBModificationAction,
    pub(crate) value: i32
}

// Produces a TGA image with using a single RGB channel as the channel for R, G, and B
pub fn image_by_single_channel(image: &TGAImage, channel: RGBChannel) -> TGAImage {
    let mut new_pixels: Vec<[u8; 3]> = Vec::new();
    for pixel in &image.data {
        new_pixels.push([pixel[channel as usize]; 3]);
    }
    TGAImage {
        header: image.header,
        data: new_pixels,
    }
}

// Rotates the image by 180 degrees
pub fn rotate_image_by_180_degrees(image: &TGAImage) -> TGAImage {
    let mut new_pixels: Vec<[u8; 3]> = Vec::new();
    for value in image.data.iter().rev() {
        new_pixels.push(*value);
    }
    TGAImage {
        header: image.header,
        data: new_pixels,
    }
}

// Takes individual r, g, and b channels and makes a pixel array out of them
pub fn construct_pixel_array_from_channels(size: usize, r_channel: &Vec<[u8; 3]>, g_channel: &Vec<[u8; 3]>, b_channel: &Vec<[u8; 3]>) -> Vec<[u8; 3]> {
    let mut new_pixels: Vec<[u8; 3]> = Vec::new();
    for i in 0..size {
        let new_pixel: [u8; 3] = [r_channel[i][0], g_channel[i][1], b_channel[i][2]];
        new_pixels.push(new_pixel);
    }
    new_pixels
}

// Modifies an image using an array of RGBChannelModifications and produces a new image out of it
pub fn modify_image_by_specification(image: &TGAImage, specifications: &Vec<RGBChannelModification>) -> TGAImage {
    let mut new_pixels: Vec<[u8; 3]> = Vec::new();
    for pixel in &image.data {
        let mut new_pixel = pixel.clone();
        for specification in specifications {
            let channel = pixel[specification.channel as usize];
            match specification.action {
                RGBModificationAction::Add => {
                    new_pixel[specification.channel as usize] = (channel as i32 + specification.value).clamp(0, 255) as u8;
                }
                RGBModificationAction::Multiply => {
                    new_pixel[specification.channel as usize] = (channel as i32 * specification.value).clamp(0, 255) as u8;
                }
            }
        }
        new_pixels.push(new_pixel);
    }
    TGAImage {
        header: image.header,
        data: new_pixels,
    }
}

// Produces a new image with blending algorithms, as calculated in the calculate_pixel_using_mode method
pub fn blend_using_mode(image_a: &TGAImage, image_b: &TGAImage, mode: BlendingMode) -> TGAImage {
    let mut pixels: Vec<[u8; 3]> = Vec::new();
    for i in 0..image_a.data.len() {
        pixels.push(calculate_pixel_using_mode(&image_a.data[i], &image_b.data[i], mode))
    }
    TGAImage {
        header: image_a.header,
        data: pixels,
    }
}

// Gets a normalized pixel stored in f32 if needed for a multiplication
fn get_normalized_pixel(pixel: &[u8; 3]) -> [f32; 3] {
    [
        pixel[0] as f32 / 255.0,
        pixel[1] as f32 / 255.0,
        pixel[2] as f32 / 255.0,
    ]
}

// Calculates an individual pixel using a specific blending mode
// Formula are as presented here: http://www.simplefilter.de/en/basics/mixmods.html
fn calculate_pixel_using_mode(pixel_a: &[u8; 3], pixel_b: &[u8; 3], mode: BlendingMode) -> [u8; 3] {
    let mut pixel = [0, 0, 0];
    match mode {
        BlendingMode::Multiply => {
            let normalized_pixel_a = get_normalized_pixel(pixel_a);
            let normalized_pixel_b = get_normalized_pixel(pixel_b);
            for i in 0..3 {
                pixel[i] = ((normalized_pixel_a[i] * normalized_pixel_b[i]) * 255.0 + 0.5) as u8;
            }
        }
        BlendingMode::Subtract => {
            for i in 0..3 {
                pixel[i] = (pixel_b[i] as i16 - pixel_a[i] as i16).clamp(0, 255) as u8;
            }
        }
        BlendingMode::Screen => {
            let normalized_pixel_a = get_normalized_pixel(pixel_a);
            let normalized_pixel_b = get_normalized_pixel(pixel_b);
            for i in 0..3 {
                pixel[i] = ((1.0 - (1.0 - normalized_pixel_a[i]) * (1.0 - normalized_pixel_b[i])) * 255.0 + 0.5) as u8;
            }
        }
        BlendingMode::Overlay => {
            let normalized_pixel_a = get_normalized_pixel(pixel_a);
            let normalized_pixel_b = get_normalized_pixel(pixel_b);
            for i in 0..3 {
                if normalized_pixel_b[i] <= 0.5 {
                    pixel[i] = ((2.0 * normalized_pixel_a[i] * normalized_pixel_b[i]) * 255.0 + 0.5) as u8;
                } else {
                    pixel[i] = ((1.0 - (2.0 * (1.0 - normalized_pixel_a[i]) * (1.0 - normalized_pixel_b[i]))) * 255.0 + 0.5) as u8;
                }
            }
        }
    }
    pixel
}