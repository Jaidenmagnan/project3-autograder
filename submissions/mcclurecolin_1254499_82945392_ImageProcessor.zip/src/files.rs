// The files module takes file inputs and converts them into images as well as outputs TGAImages to files

use std::fs::File;
use std::io::{BufReader, Read, Write};
use crate::images::{TGAImage, TGAImageHeader};

// Loads a file by the given name, or the specified path
pub fn load_file_by_name(path: &str) -> Result<TGAImage, std::io::Error> {
    // get the file and initialize the buffer
    let file = File::open(path)?;
    let mut reader = BufReader::new(file);

    // read the contents
    let mut contents = Vec::new();
    reader.read_to_end(&mut contents)?;

    Ok(get_image_from_bytes(&contents))
}

// Writes a file to a specified path using a reference to a TGAImage
pub fn write_file_using_data(path: &str, image: &TGAImage) -> std::io::Result<()> {
    let mut file = File::create(path)?;
    file.write_all(&*image_data_to_bytes(image))
}

// A helper function to convert a byte array to a TGAImage
fn get_image_from_bytes(bytes: &[u8]) -> TGAImage {
    // read the header (we expect 18 bytes to be read from the header)
    // of course, for any fields that are expected to occupy 2 bytes, we assume little endian (which is reasonable per the comment on the method header)
    let width = little_endian(&bytes[12..14]);
    let height = little_endian(&bytes[14..16]);
    TGAImage {
        header: TGAImageHeader {
            id_length: bytes[0],
            color_map_type: bytes[1],
            data_type_code: bytes[2],
            color_map_origin: little_endian(&bytes[3..5]),
            color_map_length: little_endian(&bytes[5..7]),
            color_map_depth: bytes[7],
            x_origin: little_endian(&bytes[8..10]),
            y_origin: little_endian(&bytes[10..12]),
            width,
            height,
            bits_per_pixel: bytes[16],
            image_descriptor: bytes[17],
        },
        data: read_pixels_from_bytes(&bytes[18..bytes.len()]),
    }
}

// A helper function to create a vector of pairs for pixels
fn read_pixels_from_bytes(bytes: &[u8]) -> Vec<[u8; 3]> {
    let mut pixels: Vec<[u8; 3]> = Vec::new();
    for chunk in bytes.chunks(3) {
        pixels.push([chunk[2], chunk[1], chunk[0]]);
    }
    pixels
}

// Takes a TGAImage and converts it back to a byte array
fn image_data_to_bytes(image: &TGAImage) -> Vec<u8> {
    let mut bytes: Vec<u8> = Vec::new();
    // write the header back to bytes
    bytes.push(image.header.id_length);
    bytes.push(image.header.color_map_type);
    bytes.push(image.header.data_type_code);
    let inverted_color_map_origin = invert_little_endian(image.header.color_map_origin);
    bytes.push(inverted_color_map_origin.0);
    bytes.push(inverted_color_map_origin.1);
    let inverted_color_map_length = invert_little_endian(image.header.color_map_length);
    bytes.push(inverted_color_map_length.0);
    bytes.push(inverted_color_map_length.1);
    bytes.push(image.header.color_map_depth);
    let inverted_x_origin = invert_little_endian(image.header.x_origin);
    bytes.push(inverted_x_origin.0);
    bytes.push(inverted_x_origin.1);
    let inverted_y_origin = invert_little_endian(image.header.y_origin);
    bytes.push(inverted_y_origin.0);
    bytes.push(inverted_y_origin.1);
    let inverted_width = invert_little_endian(image.header.width);
    bytes.push(inverted_width.0);
    bytes.push(inverted_width.1);
    let inverted_height = invert_little_endian(image.header.height);
    bytes.push(inverted_height.0);
    bytes.push(inverted_height.1);
    bytes.push(image.header.bits_per_pixel);
    bytes.push(image.header.image_descriptor);
    for pixel in &image.data {
        bytes.push(pixel[2]);
        bytes.push(pixel[1]);
        bytes.push(pixel[0]);
    }
    bytes
}

// Invert the byte order that was previously done to get correct values (we're back to using little endian)
fn invert_little_endian(input: i16) -> (u8, u8) {
    ((input & 0xFF) as u8, ((input >> 8) as u8))
}

// Takes a byte and transforms it into 2 bytes, assuming little endian
// This is a pretty educated assumption considering how bits tend to be stored in each .TGA file (ex: 00 02 corresponds to 02 00 or 512 for height)
fn little_endian(bytes: &[u8]) -> i16 {
    ((bytes[1] as i16) << 8) | bytes[0] as i16
}
