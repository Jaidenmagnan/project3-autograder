// Name: Jackie Wang
// UFID: 69416910
#include <iostream>
#include <fstream>
#include "image.h"
using namespace std;


int main() {
    //Load all input images data
    image text1 = image();
    text1.getImageData("input/text.tga");
    image text2 = image();
    text2.getImageData("input/text2.tga");
    image pattern1 = image();
    pattern1.getImageData("input/pattern1.tga");
    image pattern2 = image();
    pattern2.getImageData("input/pattern2.tga");
    image layer1 = image();
    layer1.getImageData("input/layer1.tga");
    image layer2 = image();
    layer2.getImageData("input/layer2.tga");
    image circles = image();
    circles.getImageData("input/circles.tga");
    image car = image();
    car.getImageData("input/car.tga");
    image layerRed = image();
    layerRed.getImageData("input/layer_red.tga");
    image layerGreen = image();
    layerGreen.getImageData("input/layer_green.tga");
    image layerBlue = image();
    layerBlue.getImageData("input/layer_blue.tga");

    //Create a new image of multiplying layer 1 and pattern 1
    image task1 = image();
    task1 = task1.multiply(layer1, pattern1);
    task1.writeImageData("output/part1.tga");

    //Create a new image of subtracting layer2 and car
    image task2 = image();
    task2 = task2.subtract(layer2, car);
    task2.writeImageData("output/part2.tga");

    //Create a new image by multiplying layer1 and pattern 2 and screening it with text1
    image task3Front = image();
    task3Front = task3Front.multiply(layer1,pattern2);
    image task3 = image();
    task3 = task3.screen(task3Front, text1);
    task3.writeImageData("output/part3.tga");

    //Create a new image by multiplying layer2 and circles and subtracting that with pattern2
    image task4Back = image();
    task4Back = task4Back.multiply(layer2,circles);
    image task4 = image();
    task4 = task4.subtract(pattern2, task4Back);
    task4.writeImageData("output/part4.tga");

    //Create a new image by overlaying layer1 and pattern1
    image task5 = image();
    task5 = task5.overlay(layer1, pattern1);
    task5.writeImageData("output/part5.tga");
    image task6 = image();

    //Create a new image by adding 200 to the green channel of car
    task6 = task6.addGreen(car);
    task6.writeImageData("output/part6.tga");

    //Create a new image by multiplying the red channel by 4 and the blue by 0 to car
    image task7 = image();
    task7 = task7.increaseRed(car);
    task7.writeImageData("output/part7.tga");

    //Create 3 new images by separating the red, green, and blue channels from car
    image task8Red = image();
    task8Red = task8Red.getColorLayer(car, "red");
    task8Red.writeImageData("output/part8_r.tga");
    image task8Green = image();
    task8Green = task8Green.getColorLayer(car, "green");
    task8Green.writeImageData("output/part8_g.tga");
    image task8Blue= image();
    task8Blue = task8Blue.getColorLayer(car, "blue");
    task8Blue.writeImageData("output/part8_b.tga");

    //Create a new image by combining 3 images
    image task9 = image();
    task9 = task9.mergeThree(layerBlue, layerGreen, layerRed);
    task9.writeImageData("output/part9.tga");

    //Create a new image by reversing text2
    image task10 = image();
    task10 = task10.reverse(text2);
    task10.writeImageData("output/part10.tga");

    //Create a new image displaying text1, pattern1, car, and circles next to each other
    image extraCredit = image();
    extraCredit = extraCredit.combineFour(text1, pattern1, car, circles);
    extraCredit.writeImageData("output/extracredit.tga");

    // Load all of the example images
    image exampleOne = image();
    exampleOne.getImageData("examples/EXAMPLE_part1.tga");
    image exampleTwo = image();
    exampleTwo.getImageData("examples/EXAMPLE_part2.tga");
    image exampleThree = image();
    exampleThree.getImageData("examples/EXAMPLE_part3.tga");
    image exampleFour = image();
    exampleFour.getImageData("examples/EXAMPLE_part4.tga");
    image exampleFive = image();
    exampleFive.getImageData("examples/EXAMPLE_part5.tga");
    image exampleSix = image();
    exampleSix.getImageData("examples/EXAMPLE_part6.tga");
    image exampleSeven = image();
    exampleSeven.getImageData("examples/EXAMPLE_part7.tga");
    image exampleEightBlue = image();
    exampleEightBlue.getImageData("examples/EXAMPLE_part8_b.tga");
    image exampleEightGreen = image();
    exampleEightGreen.getImageData("examples/EXAMPLE_part8_g.tga");
    image exampleEightRed = image();
    exampleEightRed.getImageData("examples/EXAMPLE_part8_r.tga");
    image exampleNine = image();
    exampleNine.getImageData("examples/EXAMPLE_part9.tga");
    image exampleTen = image();
    exampleTen.getImageData("examples/EXAMPLE_part10.tga");
    image ecExample = image();
    ecExample.getImageData("examples/EXAMPLE_extracredit.tga");

    // Check if the new images created are equal to their example counterparts
    if(task1.isMatching(exampleOne)){
        cout << "Test #1...... Passed!" << endl;
    }
    else{
        cout << "Test #1...... Failed!" << endl;
    }
    if(task2.isMatching(exampleTwo)){
        cout << "Test #2...... Passed!" << endl;
    }
    else{
        cout << "Test #2...... Failed!" << endl;
    }
    if(task3.isMatching(exampleThree)){
        cout << "Test #3...... Passed!" << endl;
    }
    else{
        cout << "Test #3...... Failed!" << endl;
    }
    if(task4.isMatching(exampleFour)){
        cout << "Test #4...... Passed!" << endl;
    }
    else{
        cout << "Test #4...... Failed!" << endl;
    }
    if(task5.isMatching(exampleFive)){
        cout << "Test #5...... Passed!" << endl;
    }
    else{
        cout << "Test #5...... Failed!" << endl;
    }
    if(task6.isMatching(exampleSix)){
        cout << "Test #6...... Passed!" << endl;
    }
    else{
        cout << "Test #6...... Failed!" << endl;
    }
    if(task7.isMatching(exampleSeven)){
        cout << "Test #7...... Passed!" << endl;
    }
    else{
        cout << "Test #7...... Failed!" << endl;
    }
    if(task8Blue.isMatching(exampleEightBlue)){
        cout << "Test #8 Blue...... Passed!" << endl;
    }
    else{
        cout << "Test #8 Blue...... Failed!" << endl;
    }
    if(task8Green.isMatching(exampleEightGreen)){
        cout << "Test #8 Green...... Passed!" << endl;
    }
    else{
        cout << "Test #8 Green...... Failed!" << endl;
    }
    if(task8Red.isMatching(exampleEightRed)){
        cout << "Test #8 Red...... Passed!" << endl;
    }
    else{
        cout << "Test #8 Red...... Failed!" << endl;
    }
    if(task9.isMatching(exampleNine)){
        cout << "Test #9...... Passed!" << endl;
    }
    else{
        cout << "Test #9...... Failed!" << endl;
    }
    if(task10.isMatching(exampleTen)){
        cout << "Test #10...... Passed!" << endl;
    }
    else{
        cout << "Test #10...... Failed!" << endl;
    }

    if(extraCredit.isMatching(ecExample)){
        cout << "Test Extra Credit...... Passed!" << endl;
    }
    else{
        cout << "Test Extra Credit...... Failed!" << endl;
    }
    return 0;
}
