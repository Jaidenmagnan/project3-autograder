// Name: Jackie Wang
// UFID: 69416910
#include "image.h"
#include <fstream>
#include <iostream>
#include <vector>

// Constructor to assign red, green, and blue to 0
colorData::colorData(){
    this->blue = 0;
    this->green = 0;
    this->red = 0;
}

// Function that gets the header and pixel data of the inputted file
void image::getImageData(string fileName) {
    ifstream imageFile(fileName, ios::binary);
    imageFile.read(&this->idLength, 1);
    imageFile.read(&this->colorMapType, 1);
    imageFile.read(&this->dataTypeCode, 1);
    imageFile.read((char *)&this->colorMapOrigin, 2);
    imageFile.read((char *)&this->colorMapLength, 2);
    imageFile.read(&this->colorMapDepth, 1);
    imageFile.read((char *)&this->xOrigin, 2);
    imageFile.read((char *)&this->yOrigin, 2);
    imageFile.read((char *)&this->width, 2);
    imageFile.read((char *)&this->height, 2);
    imageFile.read(&this->bitsPerPixel, 1);
    imageFile.read(&this->imageDescriptor, 1);
    Pixels = new vector<colorData>(width * height);
    //Reads all the pixels in one go
    imageFile.read((char *) Pixels->data(),Pixels->size()*3);

}

// Function that wrties the header and pixel data to the inputted file
void image::writeImageData(string fileName) {
    ofstream imageFile(fileName, ios::binary);
    imageFile.write(&this->idLength, sizeof(this->idLength));
    imageFile.write(&this->colorMapType, sizeof(this->colorMapType));
    imageFile.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
    imageFile.write((char *)&this->colorMapOrigin, sizeof(this->colorMapOrigin));
    imageFile.write((char *)&this->colorMapLength, sizeof(this->colorMapLength));
    imageFile.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
    imageFile.write((char *)&this->xOrigin, sizeof(this->xOrigin));
    imageFile.write((char *)&this->yOrigin, sizeof(this->yOrigin));
    imageFile.write((char *)&this->width, sizeof(this->width));
    imageFile.write((char *)&this->height, sizeof(this->height));
    imageFile.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
    imageFile.write(&this->imageDescriptor, sizeof(this->imageDescriptor));
    int numPixels = this->width*this->height;
    // For loop to write each pixel
    for(int i = 0; i  < numPixels; i++){

        imageFile << ((*Pixels)[i].blue);
        imageFile << ((*Pixels)[i].green);
        imageFile << ((*Pixels)[i].red);
}
}

// Function that multiplies every color value of 2 inputted images while making sure the values are between 0-255
image image::multiply(image frontLayer, image backLayer){
    image resultImage = frontLayer;
    resultImage.Pixels = new vector<colorData>(frontLayer.height * frontLayer.width);
    for(int i = 0; i < (frontLayer.width * frontLayer.height); i++){
    int newBlue = ((int)(*frontLayer.Pixels)[i].blue/255.0f * (int)(*backLayer.Pixels)[i].blue/255.0f
                                  * 255.0f + 0.5f);
    if(newBlue > 255){
        (*resultImage.Pixels)[i].blue = 255;
    }
    else if(newBlue < 0){
        (*resultImage.Pixels)[i].blue = 0;
    }
    else{
        (*resultImage.Pixels)[i].blue = (unsigned char)((*frontLayer.Pixels)[i].blue/255.0f * (*backLayer.Pixels)[i].blue/255.0f
                                                        * 255.0f + 0.5f);
    }
    int newGreen = ((int)(*frontLayer.Pixels)[i].green/255.0f * (int)(*backLayer.Pixels)[i].green/255.0f
                    * 255.0f + 0.5f);
    if(newGreen > 255){
        (*resultImage.Pixels)[i].green = 255;
    }
    else if (newGreen < 0){
        (*resultImage.Pixels)[i].green = 0;
    }
    else{
        (*resultImage.Pixels)[i].green = (unsigned char)((*frontLayer.Pixels)[i].green/255.0f * (*backLayer.Pixels)[i].green/255.0f
                                                         * 255.0f + 0.5f);
    }
    int newRed = ((int)(*frontLayer.Pixels)[i].red/255.0f * (int)(*backLayer.Pixels)[i].red/255.0f
                  * 255.0f + 0.5f);
        if(newRed > 255){
            (*resultImage.Pixels)[i].red = 255;
        }
        else if (newRed < 0){
            (*resultImage.Pixels)[i].red = 0;
        }
        else{
            (*resultImage.Pixels)[i].red = (unsigned char)((*frontLayer.Pixels)[i].red/255.0f * (*backLayer.Pixels)[i].red/255.0f
                                                             * 255.0f + 0.5f);
        }
    }
    return resultImage;
}

// Function that subtracts every color value of 2 inputted images while making sure the values are between 0-255
image image::subtract(image frontLayer, image backLayer){
    image resultImage = frontLayer;
    resultImage.Pixels = new vector<colorData>(frontLayer.height * frontLayer.width);
    for(int i = 0; i < (frontLayer.width * frontLayer.height); i++){
        int newBlue = (int)(*backLayer.Pixels)[i].blue - (int)(*frontLayer.Pixels)[i].blue;
        if(newBlue > 255){
            (*resultImage.Pixels)[i].blue = 255;
        }
        else if(newBlue < 0){
            (*resultImage.Pixels)[i].blue = 0;
        }
        else{
            (*resultImage.Pixels)[i].blue = (unsigned char)newBlue;
        }
        int newGreen = (int)(*backLayer.Pixels)[i].green - (int)(*frontLayer.Pixels)[i].green;
        if(newGreen > 255) {
            (*resultImage.Pixels)[i].green = 255;
        }
        else if(newGreen < 0){
            (*resultImage.Pixels)[i].green = 0;
        }
        else{
            (*resultImage.Pixels)[i].green = (unsigned char)newGreen;
        }
        int newRed = (int)(*backLayer.Pixels)[i].red - (int)(*frontLayer.Pixels)[i].red;
        if(newRed > 255) {
            (*resultImage.Pixels)[i].red = 255;
        }
        else if(newRed < 0){
            (*resultImage.Pixels)[i].red = 0;
        }
        else{
            (*resultImage.Pixels)[i].red = (unsigned char)newRed;
        }
    }
    return resultImage;
}

// Function that screens every color value of 2 inputted images while making sure the values are between 0-255
image image::screen(image frontLayer, image backLayer){
    image resultImage = frontLayer;
    for(int i = 0; i < (frontLayer.width * frontLayer.height); i++){
        int newBlue =  ((1 - ((1 - (int)(*frontLayer.Pixels)[i].blue/255.0f) *
                                                                             (1 - (int)(*backLayer.Pixels)[i].blue/255.0f))) * 255.0f + 0.5f);
        if(newBlue > 255){
            (*resultImage.Pixels)[i].blue = 255;
        }
        else if(newBlue < 0){
            (*resultImage.Pixels)[i].blue = 0;
        }
        else{
            (*resultImage.Pixels)[i].blue = (unsigned char)newBlue;
        }
        int newGreen =  ((1 - ((1 - (int)(*frontLayer.Pixels)[i].green/255.0f) *
                              (1 - (int)(*backLayer.Pixels)[i].green/255.0f))) * 255.0f + 0.5f);
        if(newGreen > 255){
            (*resultImage.Pixels)[i].green = 255;
        }
        else if(newBlue < 0){
            (*resultImage.Pixels)[i].green = 0;
        }
        else{
            (*resultImage.Pixels)[i].green = (unsigned char)newGreen;
        }
        int newRed =  ((1 - ((1 - (int)(*frontLayer.Pixels)[i].red/255.0f) *
                              (1 - (int)(*backLayer.Pixels)[i].red/255.0f))) * 255.0f + 0.5f);
        if(newRed > 255){
            (*resultImage.Pixels)[i].red = 255;
        }
        else if(newRed < 0){
            (*resultImage.Pixels)[i].red = 0;
        }
        else{
            (*resultImage.Pixels)[i].red = (unsigned char)newRed;
        }
    }
    return resultImage;
}

// Function that overlays the color value of 2 inputted images
image image::overlay(image frontLayer, image backLayer){
    image resultImage = frontLayer;
    for(int i = 0; i < (frontLayer.width * frontLayer.height); i++){
        if((*backLayer.Pixels)[i].blue/255.0f > 0.5f){
            (*resultImage.Pixels)[i].blue = (unsigned char)((1 - 2 * (1 - (*frontLayer.Pixels)[i].blue/255.0f) *
                    (1 - (*backLayer.Pixels)[i].blue/255.0f)) * 255.0f + 0.5f);
        }
        else{
            (*resultImage.Pixels)[i].blue = (unsigned char)(2 * 255.0f * (*frontLayer.Pixels)[i].blue/255.0f *
                    (*backLayer.Pixels)[i].blue/255.0f + 0.5f);
        }
        if((*backLayer.Pixels)[i].green/255.0f > 0.5f){
            (*resultImage.Pixels)[i].green = (unsigned char)((1 - 2 * (1 - (*frontLayer.Pixels)[i].green/255.0f) *
                                                (1 - (*backLayer.Pixels)[i].green/255.0f)) * 255.0f + 0.5f);
        }
        else{
            (*resultImage.Pixels)[i].green = (unsigned char)(2 * 255.0f * (*frontLayer.Pixels)[i].green/255.0f *
                                            (*backLayer.Pixels)[i].green/255.0f + 0.5f);
        }
        if((*backLayer.Pixels)[i].red/255.0f > 0.5f){
            (*resultImage.Pixels)[i].red = (unsigned char)((1 - 2 * (1 - (*frontLayer.Pixels)[i].red/255.0f) *
                                                (1 - (*backLayer.Pixels)[i].red/255.0f)) * 255.0f + 0.5f);
        }
        else{
            (*resultImage.Pixels)[i].red = (unsigned char)(2 * 255.0f * (*frontLayer.Pixels)[i].red/255.0f *
                                            (*backLayer.Pixels)[i].red/255.0f + 0.5f);
        }
    }
    return resultImage;
}

//Function that adds 200 to green value of every pixel in the inputted image
image image::addGreen(image firstImage){
    image resultImage = firstImage;
    resultImage.Pixels = new vector<colorData>(firstImage.height * firstImage.width);
    for(int i = 0; i < (firstImage.width * firstImage.height); i++){
        (*resultImage.Pixels)[i].blue = (*firstImage.Pixels)[i].blue;
        int newGreen = int((*firstImage.Pixels)[i].green) + 200;
        if(newGreen > 255){
            (*resultImage.Pixels)[i].green = 255;
        }
        else if(newGreen < 0){
            (*resultImage.Pixels)[i].green = 0;
        }
        else{
            (*resultImage.Pixels)[i].green = (unsigned char)newGreen;
        }
        (*resultImage.Pixels)[i].red = (*firstImage.Pixels)[i].red;
    }

    return resultImage;
}
// Function multiplies 4 to the red value of every pixel in the inputted image and 0 to the blue value while keeping values between 0-255
image image::increaseRed(image firstImage){
    image resultImage = firstImage;
    resultImage.Pixels = new vector<colorData>(firstImage.height * firstImage.width);
    for(int i = 0; i < (firstImage.width * firstImage.height); i++){
        (*resultImage.Pixels)[i].blue = (*firstImage.Pixels)[i].blue * 0;
        (*resultImage.Pixels)[i].green = (*firstImage.Pixels)[i].green;
        int newRed = (int)(*firstImage.Pixels)[i].red * 4;
        if(newRed > 255){
            (*resultImage.Pixels)[i].red = 255;
        }
        else if(newRed < 0){
            (*resultImage.Pixels)[i].red = 0;
        }
        else{
            (*resultImage.Pixels)[i].red = (unsigned char)newRed;
        }
    }
    return resultImage;
}
// Function to get the color layer of an inputted image
image image::getColorLayer(image firstImage, std::string color) {
    image resultImage = firstImage;
    resultImage.Pixels = new vector<colorData>(firstImage.height * firstImage.width);
    if(color == "red"){
        for(int i = 0; i < (firstImage.width * firstImage.height); i++){
            (*resultImage.Pixels)[i].blue = (*firstImage.Pixels)[i].red;
            (*resultImage.Pixels)[i].green = (*firstImage.Pixels)[i].red;
            (*resultImage.Pixels)[i].red = (*firstImage.Pixels)[i].red;
            }
        }
    else if(color == "green"){
        for(int i = 0; i < (firstImage.width * firstImage.height); i++){
            (*resultImage.Pixels)[i].blue = (*firstImage.Pixels)[i].green;
            (*resultImage.Pixels)[i].green = (*firstImage.Pixels)[i].green;
            (*resultImage.Pixels)[i].red = (*firstImage.Pixels)[i].green;
        }
    }
    else {
        for(int i = 0; i < (firstImage.width * firstImage.height); i++){
            (*resultImage.Pixels)[i].blue = (*firstImage.Pixels)[i].blue;
            (*resultImage.Pixels)[i].green = (*firstImage.Pixels)[i].blue;
            (*resultImage.Pixels)[i].red = (*firstImage.Pixels)[i].blue;
        }
    }
    return resultImage;
}

// Function to merge 3 images and their color values into one image
image image::mergeThree(image blueLayer, image greenLayer, image redLayer) {
    image resultImage = blueLayer;
    resultImage.Pixels = new vector<colorData>(blueLayer.height * blueLayer.width);
    for (int i = 0; i < (blueLayer.height * blueLayer.width); i++) {
        (*resultImage.Pixels)[i].blue = (*blueLayer.Pixels)[i].blue;
        (*resultImage.Pixels)[i].green = (*greenLayer.Pixels)[i].green;
        (*resultImage.Pixels)[i].red = (*redLayer.Pixels)[i].red;
    }
    return resultImage;
}

// Function that reverses the inputted image
image image::reverse(image firstImage) {
    image resultImage = firstImage;
    resultImage.Pixels = new vector<colorData>(firstImage.height * firstImage.width);
    int reverseIterator = firstImage.height * firstImage.width - 1;
    for(int i = 0; i < (firstImage.width * firstImage.height); i++){
        (*resultImage.Pixels)[i].blue = (*firstImage.Pixels)[reverseIterator].blue;
        (*resultImage.Pixels)[i].green = (*firstImage.Pixels)[reverseIterator].green;
        (*resultImage.Pixels)[i].red = (*firstImage.Pixels)[reverseIterator].red;
        reverseIterator--;
    }
    return resultImage;
}
// Function that produces an image that showcases 4 images each in a corner
image image::combineFour(image one, image two, image three, image four) {
    image resultImage = one;
    resultImage.width = one.width * 2;
    resultImage.height = one.height * 2;
    resultImage.Pixels = new vector<colorData>(one.height * one.width * 4);
    int resultIterator = 0;
    int oneIterator = 0;
    int twoIterator = 0;
    for(int i = 0; i < one.height; i++){
        for(int j = 0; j < one.width; j++){
            (*resultImage.Pixels)[resultIterator].blue = (*one.Pixels)[oneIterator].blue;
            (*resultImage.Pixels)[resultIterator].green = (*one.Pixels)[oneIterator].green;
            (*resultImage.Pixels)[resultIterator].red = (*one.Pixels)[oneIterator].red;
            resultIterator++;
            oneIterator++;
        };
        for(int k = 0; k < two.width; k++){
            (*resultImage.Pixels)[resultIterator].blue = (*two.Pixels)[twoIterator].blue;
            (*resultImage.Pixels)[resultIterator].green = (*two.Pixels)[twoIterator].green;
            (*resultImage.Pixels)[resultIterator].red = (*two.Pixels)[twoIterator].red;
            resultIterator++;
            twoIterator++;
        }
    }
    int thirdIterator = 0;
    int fourIterator = 0;
    for(int i = one.height; i < one.height * 2; i++){
        for(int j = 0; j < one.width; j++){
            (*resultImage.Pixels)[resultIterator].blue = (*three.Pixels)[thirdIterator].blue;
            (*resultImage.Pixels)[resultIterator].green = (*three.Pixels)[thirdIterator].green;
            (*resultImage.Pixels)[resultIterator].red = (*three.Pixels)[thirdIterator].red;
            resultIterator++;
            thirdIterator++;
        };
        for(int k = 0; k < two.width; k++){
            (*resultImage.Pixels)[resultIterator].blue = (*four.Pixels)[fourIterator].blue;
            (*resultImage.Pixels)[resultIterator].green = (*four.Pixels)[fourIterator].green;
            (*resultImage.Pixels)[resultIterator].red = (*four.Pixels)[fourIterator].red;
            resultIterator++;
            fourIterator++;
        }
    }
    return resultImage;
}

// Function to check if two images are matching
bool image::isMatching(image example){
    if(this->idLength != example.idLength){
        return false;
    }
    else if(this->colorMapType != example.colorMapType){
        return false;
    }
    else if(this->dataTypeCode != example.dataTypeCode){
        return false;
    }
    else if(this->colorMapOrigin != example.colorMapOrigin){
        return false;
    }
    else if(this->colorMapLength != example.colorMapLength){
        return false;
    }
    else if(this->colorMapDepth != example.colorMapDepth){
        return false;
    }
    else if(this->xOrigin != example.xOrigin){
        return false;
    }
    else if(this->yOrigin != example.yOrigin){
        return false;
    }
    else if(this->width != example.width){
        return false;
    }
    else if(this->height != example.height){
        return false;
    }
    else if(this->bitsPerPixel != example.bitsPerPixel){
        return false;
    }
    else if(this->imageDescriptor != example.imageDescriptor){
        return false;
    }
    else{
        for(int i = 0; i < this->height * this->width; i++){
            if((*this->Pixels)[i].blue != (*example.Pixels)[i].blue){
                return false;
            }
            else if((*this->Pixels)[i].green != (*example.Pixels)[i].green){
                return false;
            }
            else if((*this->Pixels)[i].red != (*example.Pixels)[i].red){
                return false;
            }
        }
        return true;
    }
}
