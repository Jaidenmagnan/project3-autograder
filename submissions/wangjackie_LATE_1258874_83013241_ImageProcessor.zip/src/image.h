// Name: Jackie Wang
// UFID: 69416910

#ifndef IMAGEPROCESSING_IMAGE_H
#define IMAGEPROCESSING_IMAGE_H
// Include libraries
#include <fstream>
#include <vector>
using namespace std;

// Declare a colorData struct to have the attributes red, green, and blue for pixels
struct colorData{
    unsigned char blue;
    unsigned char green;
    unsigned char red;
// Declare default constructor
public:
    colorData();
};
// Declare an image struct
struct image
{
    // Declare header attributes
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
    // Declare the pixel data vector attribute
    vector<colorData> *Pixels;
    // Declare function prototypes
    void getImageData(string fileName);
    void writeImageData(string fileName);
    image multiply(image frontLayer, image backLayer);
    image subtract(image frontLayer, image backLayer);
    image screen(image firstImage, image secondImage);
    image overlay(image firstImage, image secondImage);
    image addGreen(image firstImage);
    image increaseRed(image firstImage);
    image getColorLayer(image firstImage, string color);
    image mergeThree(image blueLayer, image greenLayer, image redLayer);
    image reverse(image firstImage);
    bool isMatching(image example);
    image combineFour(image one, image two, image three, image four);
};

#endif //IMAGEPROCESSING_IMAGE_H
