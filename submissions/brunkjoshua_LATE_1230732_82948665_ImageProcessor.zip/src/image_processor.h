//
// Created by Joshua Brunk on 11/7/23.
//

#ifndef P3_SKELETON_IMAGE_PROCESSOR_H
#define P3_SKELETON_IMAGE_PROCESSOR_H
#include <string>
#include <vector>
#include "Pixel.h"
using std::vector;
using std::string;

struct Header
{


    Header();
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
    string filename;

    vector <char> image;
    vector<Pixel>* pixeled_image;
    vector<Pixel>* reversed_image;
    vector<vector<Pixel>*>* pixelfiedRows;


    vector<vector<Pixel>*>* pixelfy_rows();
    vector<Pixel>*pixelfy();
    Header* multiply(Header& multiplier);
    Header* subtract(Header& subtracter);
    Header* screen(Header& screener);
    Header* overlay(Header &overlay);


    void color_split();
    void combine(Header& green, Header& blue);
    Header(string _filename);
    Header(vector<Pixel>*);


    void read_image();

    void write_image(string filename);
    void write_image_vector(string filename, vector<char>* image);
    void write_reverse_image(string filename);
    void write_pixel_image(string filename);
    void write_pixel_image(string filename,Header* head);
    void write_pixel_image(string filename, const vector<Pixel>& pixels);
    void write_rowified_image(string filename);

    void set_color(int red,int green, int blue);
    void add_color(int red,int green, int blue);
    void scale_color(int red,int green, int blue);


    void reverse();
    bool checkVector(const Header& Vec2);
    bool check_pixel_Vector(const Header& header2);
    void set_all_color(char num,const string& operation);
    Header(const Header& other);


};

//ifstream ios read

//everything fits then do size of

#endif //P3_SKELETON_IMAGE_PROCESSOR_H
