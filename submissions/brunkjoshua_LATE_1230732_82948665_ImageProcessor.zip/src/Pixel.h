//
// Created by Joshua Brunk on 11/9/23.
//

#ifndef P3_SKELETON_PIXEL_H
#define P3_SKELETON_PIXEL_H
#include <string>
#include <vector>

using std::vector;
using std::string;

struct Pixel {
    unsigned char red;
    unsigned char green;
    unsigned char blue;

    Pixel(unsigned char _red, unsigned char _green, unsigned char _blue);

};


#endif //P3_SKELETON_PIXEL_H
