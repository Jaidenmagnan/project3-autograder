//
// Created by Joshua Brunk on 11/7/23.
//Citationnnnns:https://www.geeksforgeeks.org/stdistream_iterator-stdostream_iterator-c-stl/
//https://www.tutorialspoint.com/cplusplus/cpp_files_streams.htm
//https://www.geeksforgeeks.org/vector-in-cpp-stl/

//Me debugging memory leaks be like: https://www.youtube.com/watch?v=fVfv_lK7vBM
#include "image_processor.h"
#include "image_processor.h"
#include <string>
#include <fstream>
#include <iostream>
#include <filesystem>


//For extracredit, split into vectors of 512 pixels or howeverbig. Final image will be 512+512 * 512+512.
// Thenbottom left image of 512 (first vector of that list of vectors for that image) then next image first vector.
//Do this until you have bottom 2 images then do this for top two as well.

using std::string;
using std::string;
using std::cout;
using std::endl;
using std::cerr;
using std::ifstream;
//Test cases
bool areFilesEqual(const std::string& file1, const std::string& file2) {

    string fullPath1 = std::filesystem::current_path().string() + "/" + file1;
    string fullPath2 = std::filesystem::current_path().string() + "/" + file2;
   // cout<<fullPath1<<endl;
    //cout<<fullPath2<<endl;
    std::ifstream ifs1(file1, std::ios::binary | std::ios::ate);
    std::ifstream ifs2(file2, std::ios::binary | std::ios::ate);

    if (!ifs1.is_open() || !ifs2.is_open()) {
        std::cerr << "Error opening files." << std::endl;
        return false;
    }

    if (ifs1.tellg() != ifs2.tellg()) {
        // Files are of different sizes, so they can't be equal
        return false;
    }

    // Move file pointers to the beginning
    ifs1.seekg(0, std::ios::beg);
    ifs2.seekg(0, std::ios::beg);

    // Compare the contents of the files
    if (std::equal(std::istreambuf_iterator<char>(ifs1.rdbuf()),
                   std::istreambuf_iterator<char>(),
                   std::istreambuf_iterator<char>(ifs2.rdbuf()))) {
        return true; // Files are equal
    }

    return false; // Files are not equal
}

//Test cases are commented because they would all fail in the zip because no examples file
int main(){
    //Parts 1
    Header layer1("input/layer1.tga");
    Header pattern1("input/pattern1.tga");
    Header part1 = (*layer1.multiply(pattern1));
    part1.write_pixel_image("output/part1.tga");


//Test 1
    //cout<<areFilesEqual("./output/part1.tga","../examples/EXAMPLE_part1.tga")<<" Test1"<<endl;

    //Part 2
    Header car("./input/car.tga");
    Header layer2("./input/layer2.tga");
    Header part2 = (*(car.subtract(layer2)));
    part2.write_pixel_image("./output/part2.tga");


    //Test 2
    //cout<<areFilesEqual("./output/part2.tga","../examples/EXAMPLE_part2.tga")<<" Test2"<<endl;


   //Number3!!!
   //Header layer1("/input/layer1.tga");
    Header pattern2("./input/pattern2.tga");
    Header text("./input/text.tga");
    Header finalScreen = (*layer1.multiply(pattern2));
    Header part3 = (*text.screen(finalScreen));
    part3.write_pixel_image("./output/part3.tga");

    //Test 3
    //cout<<areFilesEqual("./output/part3.tga","../examples/EXAMPLE_part3.tga")<<" Test3"<<endl;

    //Header layer2("layer2.tga");
    Header circles("./input/circles.tga");
    Header combo = (*layer2.multiply(circles));
    //Header pattern2("pattern2.tga");
    Header part4 = (*combo.subtract(pattern2));
    part4.write_pixel_image("./output/part4.tga");

    //Test 4
    //cout<<areFilesEqual("./output/part4.tga","../examples/EXAMPLE_part4.tga")<<" Test4"<<endl;

//Part 5 works
//Header layer1("layer1.tga");
//Header pattern1("pattern1.tga");
    Header layerOverlayPattern = (*layer1.overlay(pattern1));
    layerOverlayPattern.write_pixel_image("./output/part5.tga");
    //Test 5
    //cout<<areFilesEqual("./output/part5.tga","../examples/EXAMPLE_part5.tga")<<" Test5"<<endl;


// Part 6 Works!
    //Header car("car.tga"); this mes
    car.add_color(0,200,0);
    car.write_pixel_image("./output/part6.tga");
    //Test 6
    //cout<<areFilesEqual("./output/part6.tga","../examples/EXAMPLE_part6.tga")<<" Test6"<<endl;


// Part 7
    Header car2("./input/car.tga");
    car2.scale_color(4,1,0);
    car2.write_pixel_image("./output/part7.tga");

    //Test 7
    //cout<<areFilesEqual("./output/part7.tga","../examples/EXAMPLE_part7.tga")<<" Test7"<<endl;


//Case8 works!!

    Header car3("./input/car.tga");
    cout<<"loaded"<<endl;
    car3.color_split();

    //Test 8
    //cout<<areFilesEqual("./output/part8r.tga","../examples/EXAMPLE_part8_r.tga")<<" Test8 red"<<endl;
    //cout<<areFilesEqual("./output/part8g.tga","../examples/EXAMPLE_part8_g.tga")<<" Test8 green"<<endl;
    //cout<<areFilesEqual("./output/part8b.tga","../examples/EXAMPLE_part8_b.tga")<<" Test8 blue"<<endl;


//Case 9 Works!
    Header layer_red("./input/layer_red.tga");
    Header layer_green("./input/layer_green.tga");
    Header layer_blue("./input/layer_blue.tga");
    layer_red.combine(layer_green,layer_blue);
    layer_red.write_pixel_image("./output/part9.tga");

    //Test 9
    //cout<<areFilesEqual("./output/part9.tga","../examples/EXAMPLE_part9.tga")<<" Test9"<<endl;


    //Part 10
    Header text2("./input/text2.tga");
    text2.reverse();
    text2.write_reverse_image("./output/part10.tga");

    //Test
    //10
    //cout<<areFilesEqual("./output/part10.tga","../examples/EXAMPLE_part10.tga")<<" Test10"<<endl;

    return 0;
}





//--Extra Code--

//cout<<areFilesEqual("multiplied2.tga","tester.tga")<<"equal?";
//car.change_color(255,"set","r");
//cout<<car.check_pixel_Vector(car2);

//Header car2("test.tga");
//car2.read_image();
//cout<<car.checkVector(car2)<<endl;
//cout<<"hello"<<endl;
//vector<Pixel>* test = car.pixelfy();
//cout<<"pixelled"<<endl;
//car.write_pixel_image("test.tga");
//std::cout << areFilesEqual("car.tga", "test.tga");


//car.change_color(85,"set",1);
//car.write_image("final2.tga");
/*
for(char byte: car.image){
    cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(byte));
    cout<<endl;
}
 */

/*
    int line = 0;
    for(int i=0; i<100;i++){
        cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*final.pixeled_image)[i].blue))<<" ";
        cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*final.pixeled_image)[i].green))<<" ";
        cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*final.pixeled_image)[i].red))<<" ";
        line += 1;
        if(line>=32){
            line = 0;
            cout<<endl;
        }
    }
*/