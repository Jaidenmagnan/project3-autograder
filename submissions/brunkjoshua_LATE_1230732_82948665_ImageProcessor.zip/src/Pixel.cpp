//
// Created by Joshua Brunk on 11/9/23.
//

#include "Pixel.h"

Pixel::Pixel(unsigned char _red, unsigned char _green, unsigned char _blue) {
    this->red = _red;

    this->green = _green;

    this->blue = _blue;
}
/*
void Pixel::setColor(unsihed char color_channel,char value) {


}*/