//
// Created by Joshua Brunk on 11/7/23.
//Citationnnnns:https://www.geeksforgeeks.org/stdistream_iterator-stdostream_iterator-c-stl/
//
//Me debugging memory leaks be like: https://www.youtube.com/watch?v=fVfv_lK7vBM

#include "image_processor.h"
#include <string>
#include <fstream>
#include <iostream>

#include <vector>
using std::vector;
using std::string;
using std::string;
using std::cout;
using std::endl;
using std::cerr;
//Base Constructor doesn't do much lol
Header::Header(){
    //Vectors auto allocate
}
//Constructor with a string
Header::Header(string _filename){
    //Don't need relative
    //std::filesystem::path relativePath = _filename;
    //std::filesystem::path currentPath = std::filesystem::current_path();
    //std::filesystem::path absolutePath = currentPath / relativePath;
    //cout<<currentPath<<" current"<<endl;
    this->filename = _filename;
    this->read_image();
    this->pixelfy();
}

//Used to test pixel vectors i dont think i actually use it
Header::Header(vector<Pixel>* vectorino){
    this->pixeled_image = vectorino;
}

//Reads image stores in file using filename string and instream
void Header::read_image() {
    //string fullPath = std::filesystem::current_path().string() + "/" + this->filename;
    //cout<<fullPath<<endl;
    //cout<<filename<<endl;
    std::ifstream inStream(filename,std::ios::binary);

    if(inStream){
        inStream.read(&this->idLength, sizeof(this->idLength));
        inStream.read(&this->colorMapType, sizeof(this->colorMapType));
        inStream.read(&this->dataTypeCode, sizeof(this->dataTypeCode));
        inStream.read(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        inStream.read(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        inStream.read(&this->colorMapDepth, sizeof(this->colorMapDepth));
        inStream.read(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        inStream.read(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        inStream.read(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        inStream.read(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        inStream.read(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        inStream.read(&this->imageDescriptor, sizeof(this->imageDescriptor));

        //Iterator gang
        vector <char> imageFile((std::istreambuf_iterator<char>(inStream)),
                                (std::istreambuf_iterator<char>())
        );

        //Change this possibly for memory? I feel like I have bigger leaks than the titanic.
        //But they're hiding somewhere

        this->image = imageFile;
        inStream.close();
        //cout<<this->idLength<<"\n"<<this->colorMapType<<"\n"<<this->dataTypeCode<<"\n"<<this->colorMapOrigin<<"\n"<<this->colorMapLength;

    }

    else{
        //just incase of error!
        cerr<<"Error in File read"<<"\n";
        cerr<<filename<<endl;
    }


}
//Takes that image and turns it into a group of pixels
vector<Pixel>* Header::pixelfy(){

    vector<Pixel>* imagePixel = new vector<Pixel>();
    //This doesn't leak right? hahahahhahahhhahhahahha
    //https://www.youtube.com/watch?v=9YqlJ4s7M4s
    for (int i = 0; i < this->image.size(); i += 3){
        Pixel pixel(this->image[i + 2], this->image[i + 1], this->image[i]);
        imagePixel->push_back(pixel);
    }
    this->pixeled_image = imagePixel;
    return imagePixel;

}

//Multiples the current/this header with the multiplier header and returns
Header* Header::multiply(Header& multiplier){
    Header* multipliedHeader = new Header();
    multipliedHeader->idLength = this->idLength;
    multipliedHeader->colorMapType = this->colorMapType;
    multipliedHeader->dataTypeCode = this->dataTypeCode;
    multipliedHeader->colorMapOrigin = this->colorMapOrigin;
    multipliedHeader->xOrigin = this->xOrigin;
    multipliedHeader->yOrigin = this->yOrigin;
    multipliedHeader->width = this->width;
    multipliedHeader->height = this->height;
    multipliedHeader->bitsPerPixel = this->bitsPerPixel;
    multipliedHeader->imageDescriptor = this->imageDescriptor;
    //memory leaks?? It's joever isn't it (ㅠ﹏ㅠ)(ㅠ﹏ㅠ)(ㅠ﹏ㅠ)
    //https://www.youtube.com/watch?v=Zwx24H8mlCs&pp=ygUUaXQncyBqb2V2ZXIgaXNuJ3QgaXQ%3D
    vector<Pixel>* multipliedImage = new vector<Pixel>();
    if(this->pixeled_image->size() != multiplier.pixeled_image->size()){
        cout<<"something is happening here and what it is ain't exactly clear. *music plays*"<<endl;
    }

    for (int i = 0; i < pixeled_image->size(); i += 1){

        float normalizedRed1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].red)))/255;
        float normalizedGreen1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].green)))/255;
        float normalizedBlue1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].blue)))/255;
        float normalizedRed2 = (static_cast<float>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].red)))/255;
        float normalizedGreen2 = (static_cast<float>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].green)))/255;
        float normalizedBlue2 = (static_cast<float>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue)))/255;

        float red =(normalizedRed1*normalizedRed2*255)+0.5;
        float green = (normalizedGreen1*normalizedGreen2*255)+0.5;
        float blue = (normalizedBlue1*normalizedBlue2*255)+0.5;

        if(blue>255){
            blue = 255;
        }
        if(red>255){
            red = 255;
        }
        if(green>255){
            green = 255;
        }

        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue))<<" ";
        //cout<<normalizedBlue1<<endl;
        //cout<<normalizedBlue2<<endl;
        Pixel pixel(static_cast<unsigned char>(red),static_cast<unsigned char>(green),static_cast<unsigned char>(blue));
        multipliedImage->push_back(pixel);

    }
    multipliedHeader->pixeled_image = multipliedImage;

    return multipliedHeader;
}
//Does the a subtract on the two headers
Header* Header::subtract(Header &subtracter) {
    Header* subtractHeader = new Header();
    subtractHeader->idLength = this->idLength;
    subtractHeader->colorMapType = this->colorMapType;
    subtractHeader->dataTypeCode = this->dataTypeCode;
    subtractHeader->colorMapOrigin = this->colorMapOrigin;
    subtractHeader->xOrigin = this->xOrigin;
    subtractHeader->yOrigin = this->yOrigin;
    subtractHeader->width = this->width;
    subtractHeader->height = this->height;
    subtractHeader->bitsPerPixel = this->bitsPerPixel;
    subtractHeader->imageDescriptor = this->imageDescriptor;
    //memory leaks?? what even is the purpose of life
    //https://www.youtube.com/watch?v=y0bvko7IQmg
    vector<Pixel>* subtractedImage = new vector<Pixel>();
    if(this->pixeled_image->size() != subtracter.pixeled_image->size()){
        cout<<"something is happening here and what it is ain't exactly clear. *music plays*"<<endl;
    }

    for (int i = 0; i < pixeled_image->size(); i += 1){

        float ogRed1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].red)));
        float ogGreen1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].green)));
        float ogBlue1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].blue)));
        float newRed2 = (static_cast<float>(static_cast<unsigned char>((*subtracter.pixeled_image)[i].red)));
        float newGreen2 = (static_cast<float>(static_cast<unsigned char>((*subtracter.pixeled_image)[i].green)));
        float newBlue2 = (static_cast<float>(static_cast<unsigned char>((*subtracter.pixeled_image)[i].blue)));

        float red = ogRed1-newRed2;
        float green = ogGreen1-newGreen2;
        float blue = ogBlue1-newBlue2;

        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue))<<" ";
        //cout<<normalizedBlue1<<endl;
        //cout<<normalizedBlue2<<endl;
        Pixel pixel(static_cast<unsigned char>(red),static_cast<unsigned char>(green),static_cast<unsigned char>(blue));
        subtractedImage->push_back(pixel);

    }
    subtractHeader->pixeled_image = subtractedImage;
    return subtractHeader;
}

//Does the screen algo on the two headers
Header* Header::screen(Header &screener) {
    Header* screenHeader = new Header();
    screenHeader->idLength = this->idLength;
    screenHeader->colorMapType = this->colorMapType;
    screenHeader->dataTypeCode = this->dataTypeCode;
    screenHeader->colorMapOrigin = this->colorMapOrigin;
    screenHeader->xOrigin = this->xOrigin;
    screenHeader->yOrigin = this->yOrigin;
    screenHeader->width = this->width;
    screenHeader->height = this->height;
    screenHeader->bitsPerPixel = this->bitsPerPixel;
    screenHeader->imageDescriptor = this->imageDescriptor;
    //memory leaks?? Why must I suffer
    //https://www.youtube.com/watch?v=xADSDapqn9o i forgor
    vector<Pixel>* screenedImage = new vector<Pixel>();
    if(this->pixeled_image->size() != screener.pixeled_image->size()){
        //https://www.youtube.com/watch?v=80_39eAx3z8
        cout<<"something is happening here and what it is ain't exactly clear. *music plays*"<<endl;
    }

    for (int i = 0; i < pixeled_image->size(); i += 1){

        float ogRed1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].red)))/255;
        float ogGreen1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].green)))/255;
        float ogBlue1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].blue)))/255;
        float newRed2 = (static_cast<float>(static_cast<unsigned char>((*screener.pixeled_image)[i].red)))/255;
        float newGreen2 = (static_cast<float>(static_cast<unsigned char>((*screener.pixeled_image)[i].green)))/255;
        float newBlue2 = (static_cast<float>(static_cast<unsigned char>((*screener.pixeled_image)[i].blue)))/255;

        float red = ((1-(1-ogRed1)*(1-newRed2))*255)+0.5;
        float green = ((1-(1-ogGreen1)*(1-newGreen2))*255)+0.5;
        float blue = ((1-(1-ogBlue1)*(1-newBlue2))*255)+0.5;

        if(blue>255){
            blue = 255;
        }
        if(red>255){
            red = 255;
        }
        if(green>255){
            green = 255;
        }

        //cout<<ogRed1<<"\n"<<newRed2<<"\n";
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue))<<" ";
        //cout<<normalizedBlue1<<endl;
        //cout<<normalizedBlue2<<endl;
        Pixel pixel(static_cast<unsigned char>(red),static_cast<unsigned char>(green),static_cast<unsigned char>(blue));
        screenedImage->push_back(pixel);

    }
    screenHeader->pixeled_image = screenedImage;
    return screenHeader;
}
//Overlays one header on the other
Header* Header::overlay(Header &overlay) {
    Header* overlayHeader = new Header();
    overlayHeader->idLength = this->idLength;
    overlayHeader->colorMapType = this->colorMapType;
    overlayHeader->dataTypeCode = this->dataTypeCode;
    overlayHeader->colorMapOrigin = this->colorMapOrigin;
    overlayHeader->xOrigin = this->xOrigin;
    overlayHeader->yOrigin = this->yOrigin;
    overlayHeader->width = this->width;
    overlayHeader->height = this->height;
    overlayHeader->bitsPerPixel = this->bitsPerPixel;
    overlayHeader->imageDescriptor = this->imageDescriptor;
    //memory leaks?? Pain and suffering
    //https://www.youtube.com/watch?v=2Vcy8huku_Q  me after all my memory leaks and I get fired
    vector<Pixel>* overlayedImage = new vector<Pixel>();
    if(this->pixeled_image->size() != overlay.pixeled_image->size()){
        cout<<"something is happening here and what it is ain't exactly clear. *music plays*"<<endl;
    }

    for (int i = 0; i < pixeled_image->size(); i += 1){

        float ogRed1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].red)))/255;
        float ogGreen1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].green)))/255;
        float ogBlue1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].blue)))/255;
        float newRed2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].red)))/255;
        float newGreen2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].green)))/255;
        float newBlue2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].blue)))/255;

        float red;
        float green;
        float blue;

        if(newRed2<0.5){
            red = ((2*ogRed1*newRed2)*255)+0.5;
        }
        else{
            red = ((1-2*(1-ogRed1)*(1-newRed2))*255)+0.5;
        }

        if(newGreen2<0.5){
            green = ((2*ogGreen1*newGreen2)*255)+0.5;
        }
        else{
            green = ((1-2*(1-ogGreen1)*(1-newGreen2))*255)+0.5;
        }

        if(newBlue2<0.5){
            blue = ((2*ogBlue1*newBlue2)*255)+0.5;
        }
        else{
            blue = ((1-2*(1-ogBlue1)*(1-newBlue2))*255)+0.5;
        }

        if(blue>255){
            blue = 255;
        }
        if(red>255){
            red = 255;
        }
        if(green>255){
            green = 255;
        }

        //cout<<ogRed1<<"\n"<<newRed2<<"\n";
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue))<<" ";
        //cout<<normalizedBlue1<<endl;
        //cout<<normalizedBlue2<<endl;
        Pixel pixel(static_cast<unsigned char>(red),static_cast<unsigned char>(green),static_cast<unsigned char>(blue));
        overlayedImage->push_back(pixel);

    }
    overlayHeader->pixeled_image = overlayedImage;
    return overlayHeader;
}

/*Header* Header::flipX() {
    Header* overlayHeader = new Header();
    overlayHeader->idLength = this->idLength;
    overlayHeader->colorMapType = this->colorMapType;
    overlayHeader->dataTypeCode = this->dataTypeCode;
    overlayHeader->colorMapOrigin = this->colorMapOrigin;
    overlayHeader->xOrigin = this->xOrigin;
    overlayHeader->yOrigin = this->yOrigin;
    overlayHeader->width = this->width;
    overlayHeader->height = this->height;
    overlayHeader->bitsPerPixel = this->bitsPerPixel;
    overlayHeader->imageDescriptor = this->imageDescriptor;
    //memory leaks?? Pain and suffering
    vector<Pixel>* overlayedImage = new vector<Pixel>();
    if(this->pixeled_image->size() != overlay.pixeled_image->size()){
        cout<<"something is happening here and what it is ain't exactly clear. *music plays*"<<endl;
    }

    for (int i = 0; i < pixeled_image->size(); i += 1){

        float ogRed1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].red)))/255;
        float ogGreen1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].green)))/255;
        float ogBlue1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].blue)))/255;
        float newRed2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].red)))/255;
        float newGreen2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].green)))/255;
        float newBlue2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].blue)))/255;

        float red;
        float green;
        float blue;

        if(newRed2<0.5){
            red = (2*ogRed1*newRed2)*255;
        }
        else{
            red = (1-2*(1-ogRed1)*(1-newRed2))*255;
        }

        if(newGreen2<0.5){
            green = (2*ogGreen1*newGreen2)*255;
        }
        else{
            green = (1-2*(1-ogGreen1)*(1-newGreen2))*255;
        }

        if(newBlue2<0.5){
            blue = (2*ogBlue1*newBlue2)*255;
        }
        else{
            blue = (1-2*(1-ogBlue1)*(1-newBlue2))*255;
        }
        cout<<ogRed1<<"\n"<<newRed2<<"\n";
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue))<<" ";
        //cout<<normalizedBlue1<<endl;
        //cout<<normalizedBlue2<<endl;
        Pixel pixel(static_cast<unsigned char>(red),static_cast<unsigned char>(green),static_cast<unsigned char>(blue));
        overlayedImage->push_back(pixel);

    }
    overlayHeader->pixeled_image = overlayedImage;
    return overlayHeader;
}

Header* Header::flipY() {
    Header* overlayHeader = new Header();
    overlayHeader->idLength = this->idLength;
    overlayHeader->colorMapType = this->colorMapType;
    overlayHeader->dataTypeCode = this->dataTypeCode;
    overlayHeader->colorMapOrigin = this->colorMapOrigin;
    overlayHeader->xOrigin = this->xOrigin;
    overlayHeader->yOrigin = this->yOrigin;
    overlayHeader->width = this->width;
    overlayHeader->height = this->height;
    overlayHeader->bitsPerPixel = this->bitsPerPixel;
    overlayHeader->imageDescriptor = this->imageDescriptor;
    //memory leaks?? Pain and suffering
    vector<Pixel>* overlayedImage = new vector<Pixel>();
    if(this->pixeled_image->size() != overlay.pixeled_image->size()){
        cout<<"something is happening here and what it is ain't exactly clear. *music plays*"<<endl;
    }

    for (int i = 0; i < pixeled_image->size(); i += 1){

        float ogRed1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].red)))/255;
        float ogGreen1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].green)))/255;
        float ogBlue1 = (static_cast<float>(static_cast<unsigned char>((*this->pixeled_image)[i].blue)))/255;
        float newRed2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].red)))/255;
        float newGreen2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].green)))/255;
        float newBlue2 = (static_cast<float>(static_cast<unsigned char>((*overlay.pixeled_image)[i].blue)))/255;

        float red;
        float green;
        float blue;

        if(newRed2<0.5){
            red = (2*ogRed1*newRed2)*255;
        }
        else{
            red = (1-2*(1-ogRed1)*(1-newRed2))*255;
        }

        if(newGreen2<0.5){
            green = (2*ogGreen1*newGreen2)*255;
        }
        else{
            green = (1-2*(1-ogGreen1)*(1-newGreen2))*255;
        }

        if(newBlue2<0.5){
            blue = (2*ogBlue1*newBlue2)*255;
        }
        else{
            blue = (1-2*(1-ogBlue1)*(1-newBlue2))*255;
        }
        cout<<ogRed1<<"\n"<<newRed2<<"\n";
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>((*multiplier.pixeled_image)[i].blue))<<" ";
        //cout<<normalizedBlue1<<endl;
        //cout<<normalizedBlue2<<endl;
        Pixel pixel(static_cast<unsigned char>(red),static_cast<unsigned char>(green),static_cast<unsigned char>(blue));
        overlayedImage->push_back(pixel);

    }
    overlayHeader->pixeled_image = overlayedImage;
    return overlayHeader;
}
*/
//Writes out an vector of chars (I don't use. Only for testing)
void Header::write_image(string filename){

    std::ofstream outStream(filename,std::ios::binary);

    if(outStream){
        outStream.write(&this->idLength, sizeof(this->idLength));
        outStream.write(&this->colorMapType, sizeof(this->colorMapType));
        outStream.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
        outStream.write(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        outStream.write(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        outStream.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
        outStream.write(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        outStream.write(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        outStream.write(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        outStream.write(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        outStream.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        outStream.write(&this->imageDescriptor, sizeof(this->imageDescriptor));
        outStream.write(this->image.data(),this->image.size());
        outStream.close();
    }
    else{
        cerr<<"whoospie"<<endl;
    }
}
/*
void Header::write_image_vector(string filename, vector<char>* image_up){
    std::ofstream outStream(filename,std::ios::binary);

    if(outStream){
        outStream.write(&this->idLength, sizeof(this->idLength));
        outStream.write(&this->colorMapType, sizeof(this->colorMapType));
        outStream.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
        outStream.write(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        outStream.write(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        outStream.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
        outStream.write(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        outStream.write(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        outStream.write(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        outStream.write(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        outStream.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        outStream.write(&this->imageDescriptor, sizeof(this->imageDescriptor));
        outStream.write(image_up->data(),image_up->size());
        outStream.close();
    }
    else{
        cerr<<"whoospie"<<endl;
    }
}
*/
//Writes out an image from the vector of pixel classes uses this->pixelled image
void Header::write_pixel_image(string filename){
    std::ofstream outStream(filename,std::ios::binary);
    if(outStream){
        outStream.write(&this->idLength, sizeof(this->idLength));
        outStream.write(&this->colorMapType, sizeof(this->colorMapType));
        outStream.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
        outStream.write(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        outStream.write(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        outStream.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
        outStream.write(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        outStream.write(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        outStream.write(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        outStream.write(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        outStream.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        outStream.write(&this->imageDescriptor, sizeof(this->imageDescriptor));
        for(int i = 0; i < this->pixeled_image->size(); i++) {
            outStream << (*this->pixeled_image)[i].blue;
            outStream << (*this->pixeled_image)[i].green;
            outStream << (*this->pixeled_image)[i].red;

        }
        outStream.close();
    }

    else{
        cerr<<"whoospie"<<endl;
    }
}
//Writes out the pixel array/vector that you give it
void Header::write_pixel_image(string filename, const vector<Pixel>& pixels) {
    std::ofstream outStream(filename,std::ios::binary);
    if(outStream){
        outStream.write(&this->idLength, sizeof(this->idLength));
        outStream.write(&this->colorMapType, sizeof(this->colorMapType));
        outStream.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
        outStream.write(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        outStream.write(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        outStream.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
        outStream.write(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        outStream.write(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        outStream.write(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        outStream.write(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        outStream.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        outStream.write(&this->imageDescriptor, sizeof(this->imageDescriptor));
        for(int i = 0; i < pixels.size(); i++) {
            outStream << pixels[i].blue;
            outStream << pixels[i].green;
            outStream << pixels[i].red;
        }
        outStream.close();
    }
}
/*
 *  * something is extremely wrong
void Header::write_rowified_image(string filename){
    std::ofstream outStream(filename,std::ios::binary);
    if(outStream){
        outStream.write(&this->idLength, sizeof(this->idLength));
        outStream.write(&this->colorMapType, sizeof(this->colorMapType));
        outStream.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
        outStream.write(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        outStream.write(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        outStream.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
        outStream.write(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        outStream.write(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        outStream.write(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        outStream.write(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        outStream.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        outStream.write(&this->imageDescriptor, sizeof(this->imageDescriptor));

        vector<Pixel> imageSetter;

        for(int i = 0; i < this->pixelfiedRows->size(); i++) {
            for (int z = 0; z < this->pixelfiedRows[i].size(); z++){
                imageSetter->push_back((*this->pixelfiedRows)[i][z]);
            }
        }
        }
        outStream.close();
}
*/
//Reverses the image by reading the vector of pixels backward
void Header::write_reverse_image(string filename){
    std::ofstream outStream(filename,std::ios::binary);
    if(outStream){
        outStream.write(&this->idLength, sizeof(this->idLength));
        outStream.write(&this->colorMapType, sizeof(this->colorMapType));
        outStream.write(&this->dataTypeCode, sizeof(this->dataTypeCode));
        outStream.write(reinterpret_cast<char*>(&this->colorMapOrigin), sizeof(this->colorMapOrigin));
        outStream.write(reinterpret_cast<char*>(&this->colorMapLength), sizeof(this->colorMapLength));
        outStream.write(&this->colorMapDepth, sizeof(this->colorMapDepth));
        outStream.write(reinterpret_cast<char*>(&this->xOrigin), sizeof(this->xOrigin));
        outStream.write(reinterpret_cast<char*>(&this->yOrigin), sizeof(this->yOrigin));
        outStream.write(reinterpret_cast<char*>(&this->width), sizeof(this->width));
        outStream.write(reinterpret_cast<char*>(&this->height), sizeof(this->height));
        outStream.write(&this->bitsPerPixel, sizeof(this->bitsPerPixel));
        outStream.write(&this->imageDescriptor, sizeof(this->imageDescriptor));


        for(int i = 0; i < this->reversed_image->size(); i++) {
            outStream << (*this->reversed_image)[i].blue;
            outStream << (*this->reversed_image)[i].green;
            outStream << (*this->reversed_image)[i].red;

        }

        outStream.close();
    }

    else{
        cerr<<"whoospie"<<endl;
    }
}
//Sets the color of all pixels of that color to the ints
void Header::set_color(int red,int green, int blue) {
    for(Pixel& pixel: *this->pixeled_image){
            //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.red))<<endl;
            if(red>=0){
                pixel.red = red;
            }
            if(green>=0){
                pixel.green = green;
            }

            if(blue>=0){
                pixel.blue = blue;
            }

    }
}
//adds a number to all pixels of that color
void Header::add_color(int red,int green, int blue) {
    for(Pixel& pixel: *this->pixeled_image){
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.blue))<<endl;
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.red))<<endl;

        if(red>0) {
            //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
            float finalRed = static_cast<float>(pixel.red) + static_cast<float>(red);
            //cout<<finalGreen<<"cast"<<"other "<< std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
            if (finalRed > 255.0f) {
                //cout<<"max"<<endl;;
                pixel.red = 255;
            } else {
                //cout<<"outher"<<endl;
                pixel.red = static_cast<unsigned char>(finalRed);
            }
            //cout <<"other "<< std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.red))<<endl;

        }

        if(green>0) {
            //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
            float finalGreen = static_cast<float>(pixel.green) + static_cast<float>(green);
            //cout<<finalGreen<<"cast"<<"other "<< std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
            if (finalGreen > 255.0f) {
                //cout<<"max"<<endl;;
                pixel.green = 255;
            } else {
                //cout<<"outher"<<endl;
                pixel.green = static_cast<unsigned char>(finalGreen);
            }
            //cout <<"other "<< std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;

        }

        if(blue>0) {
            //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
            float finalBlue = static_cast<float>(pixel.blue) + static_cast<float>(blue);
            //cout<<finalGreen<<"cast"<<"other "<< std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
            if (finalBlue > 255.0f) {
                //cout<<"max"<<endl;;
                pixel.green = 255;
            } else {
                //cout<<"outher"<<endl;
                pixel.green = static_cast<unsigned char>(finalBlue);
            }
            //cout <<"other "<< std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;

        }
    }
}
//scales all pixels of that color by a number
void Header::scale_color(int red,int green, int blue) {
    for(Pixel& pixel: *this->pixeled_image){
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.blue))<<endl;
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.green))<<endl;
        //cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(pixel.red))<<endl;

        float redNew = pixel.red * red;
        float greenNew = pixel.green*green;
        float blueNew = pixel.blue*blue;

        if(blueNew>255){
            blueNew = 255;
        }
        if(greenNew>255){
            greenNew = 255;
        }
        if(redNew>255){
            redNew = 255;
        }
        pixel.red = redNew;
        pixel.blue = blueNew;
        pixel.green = greenNew;

        //cout<<redNew<<","<<greenNew<<","<<blueNew<<endl;
    }
}

//Splits the color channels
void Header::color_split() {

    Header headers(*this);
    vector <Pixel> red;
    vector <Pixel> green;
    vector <Pixel> blue;

    for(int i = 0; i < this->pixeled_image->size(); i++) {
        Pixel redPixel((*(this->pixeled_image))[i].red, (*(this->pixeled_image))[i].red, (*(this->pixeled_image))[i].red);
        Pixel greenPixel((*(this->pixeled_image))[i].green, (*(this->pixeled_image))[i].green, (*(this->pixeled_image))[i].green);
        Pixel bluePixel((*(this->pixeled_image))[i].blue, (*(this->pixeled_image))[i].blue, (*(this->pixeled_image))[i].blue);
        red.push_back(redPixel);
        green.push_back(greenPixel);
        blue.push_back(bluePixel);
    }

    headers.write_pixel_image("./output/part8r.tga",red);
    headers.write_pixel_image("./output/part8g.tga",green);
    headers.write_pixel_image("./output/part8b.tga",blue);
    //cout<<"amogus"<<endl;
}
//Combines the channels back
void Header::combine(Header& _green, Header& _blue){

    for(int i = 0; i < this->pixeled_image->size(); i++) {
        (*this->pixeled_image)[i].green = (*_green.pixeled_image)[i].green;
        (*this->pixeled_image)[i].blue = (*_blue.pixeled_image)[i].blue;
    }


}
//Reverses the image
void Header::reverse(){
    vector<Pixel>* image2 = new vector<Pixel>();
    for(int i = this->pixeled_image->size()-1;i>=0;i-=1){
        image2->push_back((*this->pixeled_image)[i]);
    }

    this->reversed_image = image2;

}
//Checks equality
bool Header::checkVector(const Header& header2){

    if(this->image == header2.image){
        return true;
    }
    else{
        return false;
    }
    /*
    if(this->image.size() == Vec2->size()){
        for(int i = 0; i < this->image.size(); i += 1){
            cout<<((*this->image.size())[i]==(*Vec2)[i]);
        }
    }
     */

}
//Checks equality
bool Header::check_pixel_Vector(const Header& header2){

    if(this->pixeled_image == header2.pixeled_image){
        return true;
    }
    else{
        return false;
    }
    /*
    if(this->image.size() == Vec2->size()){
        for(int i = 0; i < this->image.size(); i += 1){
            cout<<((*this->image.size())[i]==(*Vec2)[i]);
        }
    }
     */

}

//Copy
Header::Header(const Header& other) {
    idLength = other.idLength;
    colorMapType = other.colorMapType;
    dataTypeCode = other.dataTypeCode;
    colorMapOrigin = other.colorMapOrigin;
    colorMapLength = other.colorMapLength;
    colorMapDepth = other.colorMapDepth;
    xOrigin = other.xOrigin;
    yOrigin = other.yOrigin;
    width = other.width;
    height = other.height;
    bitsPerPixel = other.bitsPerPixel;
    imageDescriptor = other.imageDescriptor;
    pixeled_image = other.pixeled_image;
}