// Contains the code to create each of the parts

mod image;
use crate::parts::image::{*}; // Get access to image manipulation functions
use std::collections::HashMap; // Used to keep parts organized by name
use std::fs::read; // Used to read files

// Reads a file into a vec
pub fn read_as_vec(path: &str) -> Vec<u8> {
    read(path).unwrap()
}

// Load layer1 and pattern1, then multiply them
fn part_1() -> Vec<u8> {
    let image1 = read_as_vec("input/layer1.tga");
    let image2 = read_as_vec("input/pattern1.tga");
    multiply(&image1, &image2)
}

// Load layer2 and car, then subtract them
fn part_2() -> Vec<u8> {
    let image1 = read_as_vec("input/layer2.tga");
    let image2 = read_as_vec("input/car.tga");
    add(&image1, &image2, -1)
}

// Load layer1 and pattern2, then multiply them, then screen text and the product
fn part_3() -> Vec<u8> {
    let image1 = read_as_vec("input/layer1.tga");
    let image2 = read_as_vec("input/pattern2.tga");
    let combination = multiply(&image1, &image2);
    let image3 = read_as_vec("input/text.tga");
    screen(&image3, &combination)
}

// Load layer2 and circles, multiply them, then subtract pattern2 and the product
fn part_4() -> Vec<u8> {
    let image1 = read_as_vec("input/layer2.tga");
    let image2 = read_as_vec("input/circles.tga");
    let combination = multiply(&image1, &image2);
    let image3 = read_as_vec("input/pattern2.tga");
    add(&image3, &combination, -1) // negative for subtraction
}

// Load layer1 and pattern1, then overlay them
fn part_5() -> Vec<u8> {
    let image1 = read_as_vec("input/layer1.tga");
    let image2 = read_as_vec("input/pattern1.tga");
    overlay(&image1, &image2)
}

// Load car, then add 200 to green channel
fn part_6() -> Vec<u8> {
    let image1 = read_as_vec("input/car.tga");
    add_channel(&image1, 1, 200)
}

// Load car, then scale the red channel by 4, and the blue by 0
fn part_7() -> Vec<u8> {
    let image1 = read_as_vec("input/car.tga");
    let scaled_red = scale_channel(&image1, 0, 4.0);
    scale_channel(&scaled_red, 2, 0.0)
}

// Load car, then copy the red channel to green and blue channels
fn part_8_r() -> Vec<u8> {
    let mut image1 = read_as_vec("input/car.tga");
    copy_channel(&mut image1, 0, 1);
    copy_channel(&mut image1, 0, 2);
    image1
}

// Load car, then copy the green channel to red and blue channels
fn part_8_g() -> Vec<u8> {
    let mut image1 = read_as_vec("input/car.tga");
    copy_channel(&mut image1, 1, 0);
    copy_channel(&mut image1, 1, 2);
    image1
}

// Load car, then copy the blue channel to red and green channels
fn part_8_b() -> Vec<u8> {
    let mut image1 = read_as_vec("input/car.tga");
    copy_channel(&mut image1, 2, 0);
    copy_channel(&mut image1, 2, 1);
    image1
}

// Load layer_red, layer_green, and layer_blue, then copy layer_green to green channel of
// layer_red, then copy layer_blue to blue channel of layer_red, then return layer_red
fn part_9() -> Vec<u8> {
    let mut red = read_as_vec("input/layer_red.tga");
    let green = read_as_vec("input/layer_green.tga");
    let blue = read_as_vec("input/layer_blue.tga");
    copy_channel_from_other(&mut red, &green, 0, 1);
    copy_channel_from_other(&mut red, &blue, 0, 2);
    red
}

// Load text2, then rotate it 180 deg
fn part_10() -> Vec<u8> {
    let image1 = read_as_vec("input/text2.tga");
    rotate_180(&image1)
}

// Collage the 4 images in each corner, using image pasting
fn extra_credit() -> Vec<u8> {
    let image1 = read_as_vec("input/car.tga");
    let image2 = read_as_vec("input/circles.tga");
    let image3 = read_as_vec("input/text.tga");
    let image4 = read_as_vec("input/pattern1.tga");
    collage(&image1, &image2, &image3, &image4)
}

// Returns all image Vectors in a hashmap of the parts
pub fn get_parts() -> HashMap<String, Vec<u8>> {
    // Create and insert the new image vecs into a vector
    let mut outputs = HashMap::new();
    outputs.insert(String::from("part1"), part_1());
    outputs.insert(String::from("part2"), part_2());
    outputs.insert(String::from("part3"), part_3());
    outputs.insert(String::from("part4"), part_4());
    outputs.insert(String::from("part5"), part_5());
    outputs.insert(String::from("part6"), part_6());
    outputs.insert(String::from("part7"), part_7());
    outputs.insert(String::from("part8_r"), part_8_r());
    outputs.insert(String::from("part8_g"), part_8_g());
    outputs.insert(String::from("part8_b"), part_8_b());
    outputs.insert(String::from("part9"), part_9());
    outputs.insert(String::from("part10"), part_10());
    outputs.insert(String::from("extracredit"), extra_credit());
    outputs
}