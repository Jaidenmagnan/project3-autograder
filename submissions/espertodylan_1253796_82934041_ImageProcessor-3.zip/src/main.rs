// Gets the edited images from the parts module, and writes them to the output folder

mod parts;
use crate::parts::{get_parts, read_as_vec}; // Used to get the parts and read files
use std::fs::write; // Used to write files

// Ensure that the two images are the same
fn get_equality(part: &str, img1: &Vec<u8>, img2: &Vec<u8>) -> bool {
    let equal = img1 == img2;
    if !equal {
        // Warn if not equal
        println!("Output {part} is NOT equal to example.");
    }
    equal
}

// Use the parts hashmap to write files and check if they are equal to examples
fn main() {
    // Write the files and perform equality checks on examples
    let outputs = get_parts();
    let mut successes = 0;
    for (key, output) in &outputs {
        // Write file
        write(&format!("output/{key}.tga"), output).unwrap();
        // Keep count of success
        successes += {
            // Load the example file
            let example = read_as_vec(&format!("examples/EXAMPLE_{key}.tga"));
            // Check if output file is same as example
            if get_equality(key, output, &example) { 1 } else { 0 }
        }; // Return 1 if success, 0 if fail
    }
    // Print out the successes out of total part checks
    println!("{}/{} tests passed.", successes, outputs.len());
}