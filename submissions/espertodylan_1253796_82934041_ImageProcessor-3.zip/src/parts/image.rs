// Contains code that pertains to image editing

use std::cmp::{min, max}; // Used to clamp values to 0-255

// Clamps value to 0-255
fn clamp_color(n: i32) -> u8 {
    max(0, min(255, n)) as u8
}

// Adds two images, or subtracts if negative 1
pub fn add(img1: &Vec<u8>, img2: &Vec<u8>, sign: i16) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    for i in 18..img1.len() {
        // Add or subtract based on sign
        let sum: i16 = (img1[i] as i16 * sign) + (img2[i] as i16);
        // Clamp values to 0-255
        output[i] = clamp_color(sum as i32);
    }
    output
}

// Where channel is 0-2 for corresponding r,g,b. Intensity is not float.
pub fn add_channel(img1: &Vec<u8>, channel: isize, intensity: i16) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    for i in 18..img1.len() {
        // Ensure channel correct
        if ((i - 18) as isize - (2-channel)) % 3 != 0 {
            continue;
        }
        // Add or subtract based on sign
        let sum: i16 = img1[i] as i16 + intensity;
        // Clamp values to 0-255
        output[i] = clamp_color(sum as i32);
    }
    output
}

// Multiplies two images
pub fn multiply(img1: &Vec<u8>, img2: &Vec<u8>) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    for i in 18..img1.len() {
        // Normalize and multiply
        let product: f32 = (img1[i] as f32 / 255.0) * (img2[i] as f32 / 255.0);
        // Clamp values to 0-255
        output[i] = clamp_color((product * 255.0 + 0.5) as i32);
    }
    output
}

// Multiplies a channel by an intensity
pub fn scale_channel(img1: &Vec<u8>, channel: isize, intensity: f32) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    for i in 18..img1.len() {
        // Ensure channel correct
        if ((i - 18) as isize - (2-channel)) % 3 != 0 {
            continue;
        }
        // Normalize and multiply
        let product: f32 = (img1[i] as f32 / 255.0) * intensity;
        // Clamp values to 0-255
        output[i] = clamp_color((product * 255.0 + 0.5) as i32);
    }
    output
}

// Copies one channel to another on the same image
// Mutates img instead of returning
pub fn copy_channel(img: &mut Vec<u8>, from_channel: usize, to_channel: isize) {
    for i in 18..img.len() {
        // Ensure channel correct to set
        if ((i - 18) as isize - (2 - to_channel)) % 3 != 0 {
            continue;
        }
        // Get pixel to take from
        let pixel = 18 + ((i - 18) / 3) * 3;
        // Add the channel to the pixel index, set new value
        img[i] = img[pixel + (2-from_channel)]
    }
}

// Copies one channel from one image to another channel on another image
// Mutates img instead of returning
pub fn copy_channel_from_other(img1: &mut Vec<u8>, img2: &Vec<u8>, from_channel: usize, to_channel: isize) {
    for i in 18..img1.len() {
        // Ensure channel correct to set
        if ((i - 18) as isize - (2 - to_channel)) % 3 != 0 {
            continue;
        }
        // Get pixel to take from
        let pixel = 18 + ((i - 18) / 3) * 3;
        // Add the channel to the pixel index, set new value
        img1[i] = img2[pixel + (2-from_channel)]
    }
}

// Negative multiplication, known as screen
pub fn screen(img1: &Vec<u8>, img2: &Vec<u8>) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    for i in 18..img1.len() {
        // Do the screen equation here
        let product: f32 = 1.0 - (1.0 - img1[i] as f32 / 255.0) * (1.0 - img2[i] as f32 / 255.0);
        // Turn back to 0-255
        output[i] = clamp_color((product * 255.0 + 0.5) as i32);
    }
    output
}

// Mix of multiply and screen
pub fn overlay(img1: &Vec<u8>, img2: &Vec<u8>) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    for i in 18..img1.len() {
        // Overlay has two different equations, make use of Rust expression
        let product = {
            if (img2[i] as f32 / 255.0) >= 0.5 {
                1.0 - 2.0 * (1.0 - img1[i] as f32 / 255.0) * (1.0 - img2[i] as f32 / 255.0)
            } else {
                2.0 * (img1[i] as f32 / 255.0) * (img2[i] as f32 / 255.0)
            }
        };
        // Convert normalized back to RGB
        output[i] = clamp_color((product * 255.0 + 0.5) as i32);
    }
    output
}

// Mirrors along diagonal axis
pub fn rotate_180(img1: &Vec<u8>) -> Vec<u8> {
    let mut output: Vec<u8> = img1.clone();
    let num_pixels = (img1.len() - 18) / 3;
    for i in 0..num_pixels {
        // Define corresponding indices
        let pixel_index = i * 3 + 18;
        let opposite = (num_pixels - i) * 3 + 18 - 1;
        // Set one value to the opposite corresponding value
        output[pixel_index] = img1[opposite - 2];
        output[pixel_index+1] = img1[opposite - 1];
        output[pixel_index+2] = img1[opposite];
    }
    output
}

// Gets the width and height of the image
pub fn get_size(img1: &Vec<u8>) -> (usize, usize) {
    // Calculate the original width and height using the two bytes each
    let width = u16::from_le_bytes([img1[12], img1[13]]) as usize;
    let height = u16::from_le_bytes([img1[14], img1[15]]) as usize;
    (width, height)
}

// Paste an image at the location specified
// Mutates img1 instead of returning
pub fn paste_image(img1: &mut Vec<u8>, img2: &Vec<u8>, y: usize, x: usize) {
    // The size of the image to paste on to
    let (width1, _) = get_size(&img1);
    // The size of the image to paste
    let (width2, height2) = get_size(&img2);
    // Loop through smaller image (img2)
    for local_y in 0..height2 {
        for local_x in 0..width2 {
            // Calculate index where the pixel should go
            let rel_big = 18 + ((y + local_y) * width1 + (x + local_x)) * 3;
            // Calculate index of where the pixel should come from
            let rel_small = 18 + (local_y * width2 + local_x) * 3;
            for i in 0..3usize {
                img1[rel_big + i] = img2[rel_small + i]
            }
        }
    }
}

// Make a collage given 4 images
pub fn collage(img1: &Vec<u8>, img2: &Vec<u8>, img3: &Vec<u8>, img4: &Vec<u8>) -> Vec<u8> {
    let mut output = Vec::new();
    let (width, height) = get_size(&img1);
    // Make the vec big enough to fit 4 images
    output.resize(width * height * 3 * 4 + 18, 0);
    // Edit size header info
    output[2] = 2; // Image type
    output[13] = 4; // Width
    output[15] = 4; // Height
    output[16] = 24; // Pixel depth
    // Paste the images
    paste_image(&mut output, &img1, height, 0);
    paste_image(&mut output, &img2, height, width);
    paste_image(&mut output, &img3, 0, 0);
    paste_image(&mut output, &img4, 0, width);
    output
}