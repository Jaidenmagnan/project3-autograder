#include "TGAfile.h"


// TGAfile constructor using an existing header
TGAfile::TGAfile(Header headerTemplate) {
    header = headerTemplate;
    size = header.width * header.height;
    pixelData = new Pixel[size];
}


// TGAfile constructor using filename
TGAfile::TGAfile(const string& fileName) {
    ifstream inputFile;
    inputFile.open(fileName, ios::binary);
    if (inputFile.is_open()) {
        inputFile.read(&header.idLength, sizeof(header.idLength));
        inputFile.read(&header.colorMapType, sizeof(header.colorMapType));
        inputFile.read(&header.dataTypeCode, sizeof(header.dataTypeCode));
        inputFile.read(reinterpret_cast<char*>(&header.colorMapOrigin), sizeof(header.colorMapOrigin));
        inputFile.read(reinterpret_cast<char*>(&header.colorMapLength), sizeof(header.colorMapLength));
        inputFile.read(&header.colorMapDepth, sizeof(header.colorMapDepth));
        inputFile.read(reinterpret_cast<char*>(&header.xOrigin), sizeof(header.xOrigin));
        inputFile.read(reinterpret_cast<char*>(&header.yOrigin), sizeof(header.yOrigin));
        inputFile.read(reinterpret_cast<char*>(&header.width), sizeof(header.width));
        inputFile.read(reinterpret_cast<char*>(&header.height), sizeof(header.height));
        inputFile.read(&header.bitsPerPixel, sizeof(header.bitsPerPixel));
        inputFile.read(&header.imageDescriptor, sizeof(header.imageDescriptor));
        size = header.width * header.height;
        pixelData = new Pixel[size];
        for (int i = 0; i < size; i++) {
            inputFile.read(reinterpret_cast<char *>(&pixelData[i].blue), sizeof(pixelData[i].blue));
            inputFile.read(reinterpret_cast<char *>(&pixelData[i].green), sizeof(pixelData[i].green));
            inputFile.read(reinterpret_cast<char *>(&pixelData[i].red), sizeof(pixelData[i].red));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }
    inputFile.close();
}

// multiply blending mode
void TGAfile::multiply (TGAfile file1, TGAfile file2) {
    for (int i = 0; i < size; i++) {
        float blue = (static_cast<float>(static_cast<int>(file1.pixelData[i].blue) * static_cast<int>(file2.pixelData[i].blue))) / 255 + 0.5f;
        float green = (static_cast<float>(static_cast<int>(file1.pixelData[i].green) * static_cast<int>(file2.pixelData[i].green))) / 255 + 0.5f;
        float red = (static_cast<float>(static_cast<int>(file1.pixelData[i].red) * static_cast<int>(file2.pixelData[i].red))) / 255 + 0.5f;

        pixelData[i].blue = (unsigned char)blue;
        pixelData[i].green = (unsigned char)green;
        pixelData[i].red = (unsigned char)red;
    }
}

// subtract blending mode
void TGAfile::subtract (TGAfile file1, TGAfile file2) {
    for (int i = 0; i < size; i++) {
        int blue = (static_cast<int>(file2.pixelData[i].blue)) - (static_cast<int>(file1.pixelData[i].blue));
        int green = (static_cast<int>(file2.pixelData[i].green)) - (static_cast<int>(file1.pixelData[i].green));
        int red = (static_cast<int>(file2.pixelData[i].red)) - (static_cast<int>(file1.pixelData[i].red));

        if (blue < 0) {
            blue = 0;
        }
        if (green < 0) {
            green = 0;
        }
        if (red < 0) {
            red = 0;
        }

        pixelData[i].blue = (unsigned char)blue;
        pixelData[i].green = (unsigned char)green;
        pixelData[i].red = (unsigned char)red;
    }
}


// screen blending mode
void TGAfile::screen (TGAfile file1, TGAfile file2) {
    for (int i = 0; i < size; i++) {
        float blue1 = static_cast<float>(static_cast<int>(file1.pixelData[i].blue))/255.0f;
        float blue2 = static_cast<float>(static_cast<int>(file2.pixelData[i].blue))/255.0f;
        float green1 = static_cast<float>(static_cast<int>(file1.pixelData[i].green))/255.0f;
        float green2 = static_cast<float>(static_cast<int>(file2.pixelData[i].green))/255.0f;
        float red1 = static_cast<float>(static_cast<int>(file1.pixelData[i].red))/255.0f;
        float red2 = static_cast<float>(static_cast<int>(file2.pixelData[i].red))/255.0f;

        pixelData[i].blue = (unsigned char)((1.0f - (1.0f - blue1) * (1.0f - blue2)) * 255.0f +0.5f);
        pixelData[i].green = (unsigned char)((1.0f - (1.0f - green1) * (1.0f - green2)) * 255.0f+0.5f);
        pixelData[i].red = (unsigned char)((1.0f - (1.0f - red1) * (1.0f - red2)) * 255.0f+0.5f);
    }
}

// overlay blending mode
void TGAfile::overlay (TGAfile file1, TGAfile file2) {
    for (int i = 0; i < size; i++) {
        unsigned char x;
        unsigned char y;
        unsigned char z;
        if(file2.pixelData[i].blue/255.0 <= 0.5) {
            x = (2 * (file1.pixelData[i].blue/255.0) * (file2.pixelData[i].blue/255.0)) * 255 +0.5;
        }
        else {
            x = (1 - 2 * (1-(file1.pixelData[i].blue/255.0)) * (1-(file2.pixelData[i].blue/255.0))) * 255 +0.5 ;
        }
        if(file2.pixelData[i].green/255.0 <= 0.5) {
            y = (2 * (file1.pixelData[i].green/255.0) * (file2.pixelData[i].green/255.0)) * 255 +0.5 ;
        }
        else {
            y = (1 - 2 * (1-(file1.pixelData[i].green/255.0)) * (1-(file2.pixelData[i].green/255.0))) * 255 +0.5;
        }
        if(file2.pixelData[i].red/255.0 <= 0.5) {
            z = (2 * (file1.pixelData[i].red/255.0) * (file2.pixelData[i].red/255.0)) * 255 + 0.5;
        }
        else {
            z = (1 - 2 * (1-(file1.pixelData[i].red/255.0)) * (1-(file2.pixelData[i].red/255.0))) * 255 +0.5;
        }
        if (x > 255) {
            x = 255;
        }
        if (y > 255) {
            y = 255;
        }
        if (z > 255) {
            z = 255;
        }
        pixelData[i].blue = x;
        pixelData[i].green = y;
        pixelData[i].red = z;

    }
}
