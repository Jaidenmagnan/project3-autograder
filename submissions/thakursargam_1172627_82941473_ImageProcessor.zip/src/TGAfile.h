#pragma once
#ifndef UNTITLED6_TGAFILE_H
#define UNTITLED6_TGAFILE_H

#include <iostream>
#include <fstream>
#include <string>
#include "Header.h"
#include "Pixel.h"

using namespace std;

class TGAfile {
public:
    Header header;
    Pixel* pixelData;
    int size;
    TGAfile(const string& fileName);
    TGAfile(Header headerTemplate);
    void multiply (TGAfile file1, TGAfile file2);
    void subtract (TGAfile file1, TGAfile file2);
    void screen (TGAfile file1, TGAfile file2);
    void overlay (TGAfile file1, TGAfile file2);
};

#endif //UNTITLED6_TGAFILE_H
