#include <iostream>
#include <fstream>
#include <string>

#include "TGAfile.h"

using namespace std;

// tests
void printHeaderData(const Header& header);
bool compareFiles (const string& fileName1, const string& fileName2, int size);

void writeData(const string& fileName, TGAfile tga);

int main() {
    // part 1
    TGAfile layer1("input/layer1.tga");

    TGAfile pattern1("input/pattern1.tga");

    TGAfile part1(layer1.header);
    part1.multiply(layer1, pattern1);

    writeData("output/part1.tga", part1);

    compareFiles("examples/EXAMPLE_part1.tga","output/part1.tga",part1.size);

    // part 2
    TGAfile layer2("input/layer2.tga");
    TGAfile car("input/car.tga");

    TGAfile part2(layer2.header);
    part2.subtract(layer2, car);

    writeData("output/part2.tga", part2);

    compareFiles("examples/EXAMPLE_part2.tga","output/part2.tga",part2.size);


    // part 3
    TGAfile temp(layer1.header);
    // layer 1 already loaded in part 1
    TGAfile pattern2("input/pattern2.tga");

    TGAfile part3(layer1.header);

    temp.multiply(layer1, pattern2);

    TGAfile text("input/text.tga");
    part3.screen(text, temp);

    writeData("output/part3.tga", part3);

    compareFiles("examples/EXAMPLE_part3.tga", "output/part3.tga", part3.size);


    // part 4
    TGAfile temp2(layer2.header);
    TGAfile circles("input/circles.tga");
    temp2.multiply(layer2, circles);
    TGAfile part4(layer2.header);
    part4.subtract(pattern2, temp2);

    writeData("output/part4.tga", part4);
    compareFiles("examples/EXAMPLE_part4.tga", "C://Users//stawe//Desktop//tempfolder/part4.tga", part4.size);

    // part 5
    TGAfile part5(layer1.header);
    part5.overlay(layer1, pattern1);
    writeData("output/part5.tga", part5);
    compareFiles("examples/EXAMPLE_part5.tga", "output/part5.tga", part5.size);

    // part 6
    TGAfile part6("input/car.tga");
    for (int i = 0; i < part6.size; i++) {
        int g = (int)(part6.pixelData[i].green);
        g += 200;
        if (g > 255) {
            g = 255;
        }
        part6.pixelData[i].green = (unsigned char)(g);
    }
    writeData("output/part6.tga", part6);
    compareFiles("examples/EXAMPLE_part6.tga", "output/part6.tga", part6.size);

    // part 7
    TGAfile part7("input/car.tga");
    for (int i = 0; i < part7.size; i++) {
        int h = (int)(part7.pixelData[i].red);
        h *= 4;
        if (h > 255) {
            h = 255;
        }
        part7.pixelData[i].red = (unsigned char)(h);
        part7.pixelData[i].blue = (unsigned char)(0);
    }
    writeData("output/part7.tga", part7);
    compareFiles("examples/EXAMPLE_part7.tga", "output/part7.tga", part7.size);

    // part 8
    TGAfile temp8("input/car.tga");
    ofstream outputFile("output/part8_r.tga", ios::binary);
    if (outputFile.is_open()) {
        outputFile.write(&temp8.header.idLength, sizeof(temp8.header.idLength));
        outputFile.write(&temp8.header.colorMapType, sizeof(temp8.header.colorMapType));
        outputFile.write(&temp8.header.dataTypeCode, sizeof(temp8.header.dataTypeCode));
        outputFile.write(reinterpret_cast<char*>(&temp8.header.colorMapOrigin), sizeof(temp8.header.colorMapOrigin));
        outputFile.write(reinterpret_cast<char*>(&temp8.header.colorMapLength), sizeof(temp8.header.colorMapLength));
        outputFile.write(&temp8.header.colorMapDepth, sizeof(temp8.header.colorMapDepth));
        outputFile.write(reinterpret_cast<char*>(&temp8.header.xOrigin), sizeof(temp8.header.xOrigin));
        outputFile.write(reinterpret_cast<char*>(&temp8.header.yOrigin), sizeof(temp8.header.yOrigin));
        outputFile.write(reinterpret_cast<char*>(&temp8.header.width), sizeof(temp8.header.width));
        outputFile.write(reinterpret_cast<char*>(&temp8.header.height), sizeof(temp8.header.height));
        outputFile.write(&temp8.header.bitsPerPixel, sizeof(temp8.header.bitsPerPixel));
        outputFile.write(&temp8.header.imageDescriptor, sizeof(temp8.header.imageDescriptor));
        for (int i = 0; i < temp8.size; i++) {
            unsigned char lol = 0;
            outputFile.write(reinterpret_cast<char *>(&temp8.pixelData[i].red), sizeof(temp8.pixelData[i].red));
            outputFile.write(reinterpret_cast<char *>(&temp8.pixelData[i].red), sizeof(temp8.pixelData[i].red));
            outputFile.write(reinterpret_cast<char *>(&temp8.pixelData[i].red), sizeof(temp8.pixelData[i].red));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }
    outputFile.close();
    compareFiles("examples/EXAMPLE_part8_r.tga", "output/part8_r.tga", temp8.size);


    ofstream outputFile2("output/part8_g.tga", ios::binary);
    if (outputFile2.is_open()) {
        outputFile2.write(&temp8.header.idLength, sizeof(temp8.header.idLength));
        outputFile2.write(&temp8.header.colorMapType, sizeof(temp8.header.colorMapType));
        outputFile2.write(&temp8.header.dataTypeCode, sizeof(temp8.header.dataTypeCode));
        outputFile2.write(reinterpret_cast<char*>(&temp8.header.colorMapOrigin), sizeof(temp8.header.colorMapOrigin));
        outputFile2.write(reinterpret_cast<char*>(&temp8.header.colorMapLength), sizeof(temp8.header.colorMapLength));
        outputFile2.write(&temp8.header.colorMapDepth, sizeof(temp8.header.colorMapDepth));
        outputFile2.write(reinterpret_cast<char*>(&temp8.header.xOrigin), sizeof(temp8.header.xOrigin));
        outputFile2.write(reinterpret_cast<char*>(&temp8.header.yOrigin), sizeof(temp8.header.yOrigin));
        outputFile2.write(reinterpret_cast<char*>(&temp8.header.width), sizeof(temp8.header.width));
        outputFile2.write(reinterpret_cast<char*>(&temp8.header.height), sizeof(temp8.header.height));
        outputFile2.write(&temp8.header.bitsPerPixel, sizeof(temp8.header.bitsPerPixel));
        outputFile2.write(&temp8.header.imageDescriptor, sizeof(temp8.header.imageDescriptor));
        for (int i = 0; i < temp8.size; i++) {
            unsigned char lol = 0;
            outputFile2.write(reinterpret_cast<char *>(&temp8.pixelData[i].green), sizeof(temp8.pixelData[i].green));
            outputFile2.write(reinterpret_cast<char *>(&temp8.pixelData[i].green), sizeof(temp8.pixelData[i].green));
            outputFile2.write(reinterpret_cast<char *>(&temp8.pixelData[i].green), sizeof(temp8.pixelData[i].green));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }
    outputFile2.close();
    compareFiles("examples/EXAMPLE_part8_g.tga", "output/part8_g.tga", temp8.size);

    ofstream outputFile3("output/part8_b.tga", ios::binary);
    if (outputFile3.is_open()) {
        outputFile3.write(&temp8.header.idLength, sizeof(temp8.header.idLength));
        outputFile3.write(&temp8.header.colorMapType, sizeof(temp8.header.colorMapType));
        outputFile3.write(&temp8.header.dataTypeCode, sizeof(temp8.header.dataTypeCode));
        outputFile3.write(reinterpret_cast<char*>(&temp8.header.colorMapOrigin), sizeof(temp8.header.colorMapOrigin));
        outputFile3.write(reinterpret_cast<char*>(&temp8.header.colorMapLength), sizeof(temp8.header.colorMapLength));
        outputFile3.write(&temp8.header.colorMapDepth, sizeof(temp8.header.colorMapDepth));
        outputFile3.write(reinterpret_cast<char*>(&temp8.header.xOrigin), sizeof(temp8.header.xOrigin));
        outputFile3.write(reinterpret_cast<char*>(&temp8.header.yOrigin), sizeof(temp8.header.yOrigin));
        outputFile3.write(reinterpret_cast<char*>(&temp8.header.width), sizeof(temp8.header.width));
        outputFile3.write(reinterpret_cast<char*>(&temp8.header.height), sizeof(temp8.header.height));
        outputFile3.write(&temp8.header.bitsPerPixel, sizeof(temp8.header.bitsPerPixel));
        outputFile3.write(&temp8.header.imageDescriptor, sizeof(temp8.header.imageDescriptor));
        for (int i = 0; i < temp8.size; i++) {
            unsigned char lol = 0;
            outputFile3.write(reinterpret_cast<char *>(&temp8.pixelData[i].blue), sizeof(temp8.pixelData[i].blue));
            outputFile3.write(reinterpret_cast<char *>(&temp8.pixelData[i].blue), sizeof(temp8.pixelData[i].blue));
            outputFile3.write(reinterpret_cast<char *>(&temp8.pixelData[i].blue), sizeof(temp8.pixelData[i].blue));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }
    outputFile3.close();
    compareFiles("examples/EXAMPLE_part8_b.tga", "output/part8_b.tga", temp8.size);

    // part 9
    TGAfile layer_red("input/layer_red.tga");
    TGAfile layer_green("input/layer_green.tga");
    TGAfile layer_blue("input/layer_blue.tga");
    ofstream outPart9("output/part9.tga", ios::binary);
    if (outPart9.is_open()) {
        outPart9.write(&layer_red.header.idLength, sizeof(layer_red.header.idLength));
        outPart9.write(&layer_red.header.colorMapType, sizeof(layer_red.header.colorMapType));
        outPart9.write(&layer_red.header.dataTypeCode, sizeof(layer_red.header.dataTypeCode));
        outPart9.write(reinterpret_cast<char*>(&layer_red.header.colorMapOrigin), sizeof(layer_red.header.colorMapOrigin));
        outPart9.write(reinterpret_cast<char*>(&layer_red.header.colorMapLength), sizeof(layer_red.header.colorMapLength));
        outPart9.write(&layer_red.header.colorMapDepth, sizeof(layer_red.header.colorMapDepth));
        outPart9.write(reinterpret_cast<char*>(&layer_red.header.xOrigin), sizeof(layer_red.header.xOrigin));
        outPart9.write(reinterpret_cast<char*>(&layer_red.header.yOrigin), sizeof(layer_red.header.yOrigin));
        outPart9.write(reinterpret_cast<char*>(&layer_red.header.width), sizeof(layer_red.header.width));
        outPart9.write(reinterpret_cast<char*>(&layer_red.header.height), sizeof(layer_red.header.height));
        outPart9.write(&layer_red.header.bitsPerPixel, sizeof(layer_red.header.bitsPerPixel));
        outPart9.write(&layer_red.header.imageDescriptor, sizeof(layer_red.header.imageDescriptor));
        for (int i = 0; i < layer_red.size; i++) {
            outPart9.write(reinterpret_cast<char *>(&layer_blue.pixelData[i].blue), sizeof(layer_blue.pixelData[i].blue));
            outPart9.write(reinterpret_cast<char *>(&layer_green.pixelData[i].blue), sizeof(layer_green.pixelData[i].blue));
            outPart9.write(reinterpret_cast<char *>(&layer_red.pixelData[i].blue), sizeof(layer_red.pixelData[i].blue));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }
    outPart9.close();
    compareFiles("examples/EXAMPLE_part9.tga", "output/part9.tga", layer_red.size);


    // part 10
    TGAfile text2("input/text2.tga");
    ofstream out10("output/part10.tga");

    if (out10.is_open()) {
        out10.write(&text2.header.idLength, sizeof(text2.header.idLength));
        out10.write(&text2.header.colorMapType, sizeof(text2.header.colorMapType));
        out10.write(&text2.header.dataTypeCode, sizeof(text2.header.dataTypeCode));
        out10.write(reinterpret_cast<char*>(&text2.header.colorMapOrigin), sizeof(text2.header.colorMapOrigin));
        out10.write(reinterpret_cast<char*>(&text2.header.colorMapLength), sizeof(text2.header.colorMapLength));
        out10.write(&text2.header.colorMapDepth, sizeof(text2.header.colorMapDepth));
        out10.write(reinterpret_cast<char*>(&text2.header.xOrigin), sizeof(text2.header.xOrigin));
        out10.write(reinterpret_cast<char*>(&text2.header.yOrigin), sizeof(text2.header.yOrigin));
        out10.write(reinterpret_cast<char*>(&text2.header.width), sizeof(text2.header.width));
        out10.write(reinterpret_cast<char*>(&text2.header.height), sizeof(text2.header.height));
        out10.write(&text2.header.bitsPerPixel, sizeof(text2.header.bitsPerPixel));
        out10.write(&text2.header.imageDescriptor, sizeof(text2.header.imageDescriptor));
        for (int i = text2.size-1; i > 0; i--) {
            out10.write(reinterpret_cast<char *>(&text2.pixelData[i].blue), sizeof(text2.pixelData[i].blue));
            out10.write(reinterpret_cast<char *>(&text2.pixelData[i].green), sizeof(text2.pixelData[i].green));
            out10.write(reinterpret_cast<char *>(&text2.pixelData[i].red), sizeof(text2.pixelData[i].red));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }

    out10.close();
    compareFiles("examples/EXAMPLE_part10.tga", "output/part10.tga", text2.size);

    delete[] layer1.pixelData;
    delete[] pattern1.pixelData;
    delete[] part1.pixelData;
    delete[] layer2.pixelData;
    delete[] car.pixelData;
    delete[] part2.pixelData;
    delete[] temp.pixelData;
    delete[] pattern2.pixelData;
    delete[] part3.pixelData;
    delete[] text.pixelData;
    delete[] temp2.pixelData;
    delete[] circles.pixelData;
    delete[] part4.pixelData;
    delete[] part5.pixelData;
    delete[] part6.pixelData;
    delete[] part7.pixelData;
    delete[] temp8.pixelData;
    delete[] layer_red.pixelData;
    delete[] layer_green.pixelData;
    delete[] layer_blue.pixelData;
    delete[] text2.pixelData;

    return 0;
}

bool compareFiles (const string& fileName1, const string& fileName2, int size) {
    ifstream in1;
    ifstream in2;
    in1.open(fileName1, ios::binary);
    in2.open(fileName2, ios::binary);
    if (in1.is_open()) {
        if (in2.is_open()) {
            for(int i = 0; i < size; i++) {
                char temp;
                char temp2;

                in1.read(&temp, sizeof(temp));
                in2.read(&temp2, sizeof(temp2));

                if (temp != temp2) {
                    cout << "files are not the same, the issue is at index i =" << i << endl;
                    cout << static_cast<int>(temp) << " not equal " << static_cast<int>(temp2) << endl;
                    return false;
                }
            }
            in1.close();
            in2.close();
            cout << "files are exactly the same" << endl;
            return true;
        }
        else {
            cerr << "Error opening file 2" << endl;
        }
    }
    else {
        cerr << "Error opening file 1" << endl;
    }
    cout << "files are exactly the same" << endl;
    return true;
}

void printHeaderData(const Header& header) {
    cout << "ID Length: " << static_cast<int>(header.idLength) << endl;
    cout << "Color Map Type: " << static_cast<int>(header.colorMapType) << endl;
    cout << "Data Type Code: " << static_cast<int>(header.dataTypeCode) << endl;
    cout << "Color Map Origin: " << header.colorMapOrigin << endl;
    cout << "Color Map Length: " << header.colorMapLength << endl;
    cout << "Color Map Depth: " << static_cast<int>(header.colorMapDepth) << endl;
    cout << "X Origin: " << header.xOrigin << endl;
    cout << "Y Origin: " << header.yOrigin << endl;
    cout << "Width: " << header.width << endl;
    cout << "Height: " << header.height << endl;
    cout << "Bits per pixel: " << static_cast<int>(header.bitsPerPixel) << endl;
    cout << "Image Descriptor: " << static_cast<int>(header.imageDescriptor) << endl;
}

void writeData(const string& fileName, TGAfile tga) {
    ofstream outputFile(fileName, ios::binary);
    if (outputFile.is_open()) {
        outputFile.write(&tga.header.idLength, sizeof(tga.header.idLength));
        outputFile.write(&tga.header.colorMapType, sizeof(tga.header.colorMapType));
        outputFile.write(&tga.header.dataTypeCode, sizeof(tga.header.dataTypeCode));
        outputFile.write(reinterpret_cast<char*>(&tga.header.colorMapOrigin), sizeof(tga.header.colorMapOrigin));
        outputFile.write(reinterpret_cast<char*>(&tga.header.colorMapLength), sizeof(tga.header.colorMapLength));
        outputFile.write(&tga.header.colorMapDepth, sizeof(tga.header.colorMapDepth));
        outputFile.write(reinterpret_cast<char*>(&tga.header.xOrigin), sizeof(tga.header.xOrigin));
        outputFile.write(reinterpret_cast<char*>(&tga.header.yOrigin), sizeof(tga.header.yOrigin));
        outputFile.write(reinterpret_cast<char*>(&tga.header.width), sizeof(tga.header.width));
        outputFile.write(reinterpret_cast<char*>(&tga.header.height), sizeof(tga.header.height));
        outputFile.write(&tga.header.bitsPerPixel, sizeof(tga.header.bitsPerPixel));
        outputFile.write(&tga.header.imageDescriptor, sizeof(tga.header.imageDescriptor));
        for (int i = 0; i < tga.size; i++) {
            outputFile.write(reinterpret_cast<char *>(&tga.pixelData[i].blue), sizeof(tga.pixelData[i].blue));
            outputFile.write(reinterpret_cast<char *>(&tga.pixelData[i].green), sizeof(tga.pixelData[i].green));
            outputFile.write(reinterpret_cast<char *>(&tga.pixelData[i].red), sizeof(tga.pixelData[i].red));
        }
    }
    else {
        cerr << "Error opening file" << endl;
    }
    outputFile.close();
}