#ifndef UNTITLED6_PIXEL_H
#define UNTITLED6_PIXEL_H

struct Pixel {
    unsigned char blue;
    unsigned char green;
    unsigned char red;
};


#endif //UNTITLED6_PIXEL_H
