//
// Created by 13056 on 10/26/2023.
//

#include <fstream>
#include <iostream>
#include <cmath>

using namespace std;

# pragma pack(push, r1, 1)

struct Header  //initializing struct for the header data of the tga images
{
    char idLength;
    char colorMapType;
    char dataTypeCode;
    short colorMapOrigin;
    short colorMapLength;
    char colorMapDepth;
    short xOrigin;
    short yOrigin;
    short width;
    short height;
    char bitsPerPixel;
    char imageDescriptor;
};

unsigned char* multiply(unsigned char* p1, unsigned char* p2, int size)  // multiply function to multiply 2 different tga images together
{
    unsigned char *p3 = new unsigned char[size];  // create new array of unsigned chars

    for(int i = 0; i < size; i++)  // loop through the size of the array
    {
        unsigned char color1 = static_cast<unsigned char>(p1[i]);
        unsigned char color2 = static_cast<unsigned char>(p2[i]);
        int pixelValue = floor(((int(color1) * int(color2)) / 255.0f) + 0.5f);  // multiply the two colors together
        unsigned char finalColor = static_cast<unsigned char>(pixelValue);
        p3[i] = finalColor;  // add final value back to the new array
    }

    return p3;  // return new array
}

unsigned char* subtract(unsigned char* p1, unsigned char* p2, int size)  // subtract function to subtract 2 different tga images
{
    unsigned char *p3 = new unsigned char[size];

    for(int i = 0; i < size; i++)
    {
        unsigned char color1 = static_cast<unsigned char>(p1[i]);
        unsigned char color2 = static_cast<unsigned char>(p2[i]);
        int pixelValue = int(color2) - int(color1);  // subtract two values from each other
        unsigned char finalColor = static_cast<unsigned char>(pixelValue < 0 ? 0 : (pixelValue > 255 ? 255 : pixelValue));  // clamp the values
        p3[i] = finalColor;  // assign to new array
    }

    return p3;  // return modified array
}

unsigned char* screen(unsigned char* p1, unsigned char* p2, int size)  // function to screen two images together
{
    unsigned char* p3 = new unsigned char[size];

    for(int i = 0; i < size; i++)
    {
        unsigned char color1 = static_cast<unsigned char>(p1[i]);
        unsigned char color2 = static_cast<unsigned char>(p2[i]);
        int pixelValue1 = int(color1);
        int pixelValue2 = int(color2);
        int pixelValue = floor(((1 - (1 - (float(pixelValue1) / 255.0f)) * (1 - (float(pixelValue2) / 255.0f))) * 255) + 0.5f);  // screen the two rgb values together
        unsigned char finalColor = static_cast<unsigned char>(pixelValue < 0 ? 0 : (pixelValue > 255 ? 255 : pixelValue));  // clamp the values
        p3[i] = finalColor;  // assign to new array
    }

    return p3;  // return new array
}

unsigned char* overlay(unsigned char* p1, unsigned char* p2, int size)  // function to overlay two tga images
{
    unsigned char* p3 = new unsigned char[size];

    for(int i = 0; i < size; i++)
    {
        unsigned char color1 = static_cast<unsigned char>(p1[i]);
        unsigned char color2 = static_cast<unsigned char>(p2[i]);
        int pixelValue1 = int(color1);
        int pixelValue2 = int(color2);  // grab the integer values of the rgb values at i
        if((float(pixelValue2) / 255.0f) <= 0.5f)  // test if one or another calculation should be done
        {
            int pixelValue = floor(((2 * (float(pixelValue1) / 255.0f) * (float(pixelValue2) / 255.0f)) * 255) + 0.5f);  // perform the calculation
            unsigned char finalColor = static_cast<unsigned char>(pixelValue < 0 ? 0 : (pixelValue > 255 ? 255 : pixelValue));  // clamp the values
            p3[i] = finalColor;  // assign to new array
        }
        if((float(pixelValue2) / 255.0f) > 0.5f)
        {
            int pixelValue = floor(((1 - (2 * (1 - (float(pixelValue1) / 255.0f)) * (1 - (float(pixelValue2) / 255.0f)))) * 255) + 0.5f);  // perform the calculation
            unsigned char finalColor = static_cast<unsigned char>(pixelValue < 0 ? 0 : (pixelValue > 255 ? 255 : pixelValue));  // clamp the values
            p3[i] = finalColor;  // assign to new array
        }
    }

    return p3;  // return new array
}

unsigned char* addGreen(unsigned char* p1, int size)  // function to add a fixed value to the green channel of any image
{
    unsigned char* p2 = new unsigned char[size];

    for(int i = 0; i < size; i++)  // set all values from original array to new array
    {
        p2[i] = static_cast<unsigned char>(p1[i]);
    }

    for(int i = 1; i < size; i+=3)  // modify every green value by looping through and adding 200 to every third value starting at 1
    {
        int value = int(p1[i]);
        value += 200;
        unsigned char finalColor = static_cast<unsigned char>(value > 255 ? 255 : value);  // clamp the values
        p2[i] = finalColor;  // set to new array
    }

    return p2;  // return new array
}

unsigned char* readFile(string fileName)  // function to read the pixel data of a file
{
    Header headerObject;  // declare a header object

    ifstream file(fileName, ios::binary);
    file.read((char*)&headerObject, sizeof(Header));  // set all values of header object based on image header data

    int pixelDataSize = headerObject.width * headerObject.height * (headerObject.bitsPerPixel / 8);  // get the size of the pixel data
    char *pixelData = new char[pixelDataSize];  // initialize new array with size of pixel data

    file.read(pixelData, pixelDataSize);  // read all the pixel data into the file

    unsigned char *pixelData2 = new unsigned char[pixelDataSize];  // create an unsigned char array to hold all pixel data values

    for(int i = 0; i < pixelDataSize; i++)
    {
        pixelData2[i] = static_cast<unsigned char>(pixelData[i]);  // set all values from pixelData to pixelData2
    }
    delete[] pixelData;  // delete the original pixel data array

    return pixelData2;  // return the array of unsigned char
}

int getSize(string fileName)  // function to get the size of a certain image
{
    Header headerObject;  // declare a header object

    ifstream file(fileName, ios::binary);
    file.read((char *) &headerObject, sizeof(Header));  // initialize the header object with the file loaded

    int pixelDataSize = headerObject.width * headerObject.height * (headerObject.bitsPerPixel / 8);  // get the size of the image

    return pixelDataSize;  // return the size
}

int getBiggerSize(string fileName)  // function to get the size of a certain image
{
    Header headerObject;  // declare a header object

    ifstream file(fileName, ios::binary);
    file.read((char *) &headerObject, sizeof(Header));  // initialize the header object with the file loaded

    int pixelDataSize = (2 * headerObject.width) * (2 * headerObject.height) * (headerObject.bitsPerPixel / 8);  // get the size of the image

    return pixelDataSize;  // return the size
}

int getWidth(string fileName)  // function to get the size of a certain image
{
    Header headerObject;  // declare a header object

    ifstream file(fileName, ios::binary);
    file.read((char *) &headerObject, sizeof(Header));  // initialize the header object with the file loaded

    int pixelDataSize = headerObject.width * (headerObject.bitsPerPixel / 8);  // get the size of the image

    return pixelDataSize;  // return the size
}

bool filesAreEqual(string fileName, string fileName2)  // function to test if two images are equal
{
    auto pixelData = readFile(fileName);
    auto pixelData2 = readFile(fileName2);  // read the files of two images passed in

    int pixelDataSize = getSize(fileName);  // get the size

    for(int i = 0; i < pixelDataSize; i++)  // loop through the rgb values of the 2 images
    {
        if(pixelData[i] != pixelData2[i])  // if two rgb values don't match up
        {
            cout << int(pixelData[i]) << " " << int(pixelData2[i]) << endl;
            delete[] pixelData;
            delete[] pixelData2;  // delete the two pixel data arrays
            return false;  // return false
        }
    }
    delete[] pixelData;
    delete[] pixelData2;  // delete the two pixel data arrays
    return true;  // return true if for loop finishes without any differences caught
}

void writeFile(string fileName, string fileName0, unsigned char* p, int size)  // function to write a file with new pixel data
{
    Header headerObject;  // declare header object

    ifstream file2(fileName0, ios::binary);  // read file2

    ofstream file(fileName, ios::binary);  // writing to file

    file2.read((char*)&headerObject, sizeof(Header));  // initialize header data

    file.write((char*)&headerObject, sizeof(Header));  // write header data into new file

    char *p2 = new char[size];  // create new array of chars
    for(int i = 0; i < size; i++)
    {
        p2[i] = static_cast<char>(p[i]);  // assign all values from p to p2
    }
    file.write(p2, size);  // write in the new pixel data

    delete[] p2; // delete p2

    file2.close();
    file.close();  // close both files
}

void writeBigFile(string fileName, string fileName0, unsigned char* p, int size)  // function to write a file with new pixel data
{
    Header headerObject;  // declare header object

    ifstream file2(fileName0, ios::binary);  // read file2

    ofstream file(fileName, ios::binary);  // writing to file

    file2.read((char*)&headerObject, sizeof(Header));  // initialize header data

    headerObject.width *= 2;
    headerObject.height *= 2;

    file.write((char*)&headerObject, sizeof(Header));  // write header data into new file

    char *p2 = new char[size];  // create new array of chars
    for(int i = 0; i < size; i++)
    {
        p2[i] = static_cast<char>(p[i]);  // assign all values from p to p2
    }
    file.write(p2, size);  // write in the new pixel data

    delete[] p2; // delete p2

    file2.close();
    file.close();  // close both files
}


int main()
{
    auto pixelData = readFile("../input/layer1.tga");  // read layer1
    auto pixelData2 = readFile("../input/pattern1.tga");  // read pattern1

    int size = getSize("../input/layer1.tga");  // get size

    auto p = multiply(pixelData, pixelData2, size);  // multiply the two together

    writeFile("../output/part1.tga", "../input/layer1.tga", p, size);  // write the new file

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;  // delete all arrays using new



    pixelData = readFile("../input/layer2.tga");
    pixelData2 = readFile("../input/car.tga");

    size = getSize("../input/layer2.tga");

    p = subtract(pixelData, pixelData2, size);  // same as block above but using subtract method instead

    writeFile("../output/part2.tga", "../input/layer2.tga", p, size);

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;



    pixelData = readFile("../input/layer1.tga");  // load layer1
    pixelData2 = readFile("../input/pattern2.tga");  // load pattern2

    size = getSize("../input/layer1.tga");

    p = multiply(pixelData, pixelData2, size);  // multiply the two together

    writeFile("../output/part3.tga", "../input/layer1.tga", p, size);  // write the new file

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;  // delete arrays

    pixelData = readFile("../input/text.tga");  // load text
    pixelData2 = readFile("../output/part3.tga");  // load part3

    size = getSize("../input/text.tga");

    p = screen(pixelData, pixelData2, size);  // screen the two together

    writeFile("../output/part3.tga", "../input/text.tga", p, size);  // write the new file with the new data

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;  // delete arrays


    // same process as the one above but using multiply then subtract to combine the files
    pixelData = readFile("../input/layer2.tga");
    pixelData2 = readFile("../input/circles.tga");

    size = getSize("../input/layer2.tga");

    p = multiply(pixelData, pixelData2, size);

    writeFile("../output/part4.tga", "../input/layer2.tga", p, size);

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;

    pixelData = readFile("../input/pattern2.tga");
    pixelData2 = readFile("../output/part4.tga");

    size = getSize("../input/pattern2.tga");

    p = subtract(pixelData, pixelData2, size);

    writeFile("../output/part4.tga", "../input/pattern2.tga", p, size);

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;



    pixelData = readFile("../input/layer1.tga");
    pixelData2 = readFile("../input/pattern1.tga");

    size = getSize("../input/layer1.tga");

    p = overlay(pixelData, pixelData2, size);  // same process as first block, but using overlay method

    writeFile("../output/part5.tga", "../input/layer1.tga", p, size);

    delete[] pixelData;
    delete[] pixelData2;
    delete [] p;



    pixelData = readFile("../input/car.tga");  // load car

    size = getSize("../input/car.tga");

    p = addGreen(pixelData, size);  // add 200 to green channel

    writeFile("../output/part6.tga", "../input/car.tga", p, size);  // write new file

    delete[] pixelData;
    delete[] p;  // delete arrays



    pixelData = readFile("../input/car.tga");  // load car

    size = getSize("../input/car.tga");

    for(int i = 0; i < size; i += 3)  // for loop to set all the blue channel to 0
    {
        int value = int(pixelData[i]);  // grab value
        value *= 0;  // perform calculation
        unsigned char finalColor = static_cast<unsigned char>(value < 0 ? 0 : (value > 255 ? 255 : value));  // clamp values
        pixelData[i] = finalColor;  // set to the pixelData array
    }
    for(int i = 2; i < size; i += 3)  // for loop to multiply the red channel by 4
    {
        int value = int(pixelData[i]);
        value *= 4;
        unsigned char finalColor = static_cast<unsigned char>(value < 0 ? 0 : (value > 255 ? 255 : value));
        pixelData[i] = finalColor;
    }

    writeFile("../output/part7.tga", "../input/car.tga", pixelData, size);  // write the new file

    delete[] pixelData;  // delete the array



    pixelData = readFile("../input/car.tga");  // load car

    size = getSize("../input/car.tga");

    for(int i = 0; i < size; i += 3)  // grab all the blue values and set them to pixelData
    {
        pixelData[i] = pixelData[i];
        int value = int(pixelData[i]);
        unsigned char finalColor = static_cast<unsigned char>(value < 0 ? 0 : (value > 255 ? 255 : value));  // grab color value
        pixelData[i+1] = finalColor;  // set it to the other two positions when incrementing by 3
        pixelData[i+2] = finalColor;
    }

    writeFile("../output/part8_b.tga", "../input/car.tga", pixelData, size);  // write the blue channel file for car

    delete[] pixelData;


    // same as above but writing the green channel instead
    pixelData = readFile("../input/car.tga");

    size = getSize("../input/car.tga");

    for(int i = 1; i < size; i += 3)
    {
        pixelData[i] = pixelData[i];
        int value = int(pixelData[i]);
        unsigned char finalColor = static_cast<unsigned char>(value < 0 ? 0 : (value > 255 ? 255 : value));
        pixelData[i-1] = finalColor;
        pixelData[i+1] = finalColor;
    }

    writeFile("../output/part8_g.tga", "../input/car.tga", pixelData, size);

    delete[] pixelData;


    // same as above but writing the red channel instead
    pixelData = readFile("../input/car.tga");

    size = getSize("../input/car.tga");

    for(int i = 2; i < size; i += 3)
    {
        pixelData[i] = pixelData[i];
        int value = int(pixelData[i]);
        unsigned char finalColor = static_cast<unsigned char>(value < 0 ? 0 : (value > 255 ? 255 : value));
        pixelData[i-1] = finalColor;
        pixelData[i-2] = finalColor;
    }

    writeFile("../output/part8_r.tga", "../input/car.tga", pixelData, size);

    delete[] pixelData;



    pixelData = readFile("../input/layer_red.tga");  // load layer red
    pixelData2 = readFile("../input/layer_green.tga");  // load layer green
    auto pixelData3 = readFile("../input/layer_blue.tga");  // load layer blue

    size = getSize("../input/layer_red.tga");

    unsigned char *newImage = new unsigned char[size];  // declare and initialize new array of unsigned chars

    for(int i = 0; i < size; i+=3)
    {
        newImage[i] = pixelData3[i];
        newImage[i+1] = pixelData2[i];
        newImage[i+2] = pixelData[i];  // set the values of rgb from the layers of red, green, and blue from the files loaded
    }

    writeFile("../output/part9.tga", "../input/layer_green.tga", newImage, size);  // write the new file

    delete[] pixelData;
    delete[] pixelData2;
    delete[] pixelData3;
    delete[] newImage;  // delete all the arrays



    pixelData = readFile("../input/text2.tga");  // load text2

    size = getSize("../input/text2.tga");

    int j = size - 1;  // create a counter to go from the bottom to the top of the image

    newImage = new unsigned char[size];

    for(int i = 0; i < size; i+=3)  // for loop to flip the image in a complete 180
    {
        newImage[i + 2] = pixelData[j];
        newImage[i + 1] = pixelData[j - 1];
        newImage[i] = pixelData[j - 2];
        j -= 3;
    }

    writeFile("../output/part10.tga", "../input/text2.tga", newImage, size);  // write the new file

    delete[] pixelData;
    delete[] newImage;  // delete the arrays



    pixelData = readFile("../input/car.tga");
    pixelData2 = readFile("../input/circles.tga");
    pixelData3 = readFile("../input/text.tga");
    auto pixelData4 = readFile("../input/pattern1.tga");  // load all the images

    size = getSize("../input/car.tga");  // get size
    int sizeB = getBiggerSize("../input/car.tga");  // get size of bigger image
    int width = getWidth("../input/car.tga");  // get width

    newImage = new unsigned char[sizeB];  // allocate memory size of bigger image

    int x = 0;  // counter

    for(int i = 0; i < size; i += width)  // cycle through size incrementing by width
    {
        for(int j = 0; j < width; j++)
        {
            newImage[x] = pixelData3[j + i];  // add images to the file
            x++;
        }
        for(int j = 0; j < width; j++)
        {
            newImage[x] = pixelData4[j + i];  // add images to the file
            x++;
        }
    }
    for(int i = 0; i < size; i += width)  // same thing as above with other two images
    {
        for(int j = 0; j < width; j++)
        {
            newImage[x] = pixelData[j + i];
            x++;
        }
        for(int j = 0; j < width; j++)
        {
            newImage[x] = pixelData2[j + i];
            x++;
        }
    }

    writeBigFile("../output/extracredit.tga", "../input/car.tga", newImage, sizeB);  // write the big file

    delete[] pixelData;
    delete[] pixelData2;
    delete[] pixelData3;
    delete[] pixelData4;
    delete[] newImage;  // delete arrays




    bool test1 = filesAreEqual("../output/part1.tga", "../examples/EXAMPLE_part1.tga");  // test if part1 and example1 are equal
    if(test1)
    {
        cout << "Test #1...... Passed!" << endl;
    }
    else
    {
        cout << "Test #1...... Failed!" << endl;
    }
    bool test2 = filesAreEqual("../output/part2.tga", "../examples/EXAMPLE_part2.tga");  // test if part2 and example2 are equal
    if(test2)
    {
        cout << "Test #2...... Passed!" << endl;
    }
    else
    {
        cout << "Test #2...... Failed!" << endl;
    }
    bool test3 = filesAreEqual("../output/part3.tga", "../examples/EXAMPLE_part3.tga");  // test if part3 and example3 are equal
    if(test3)
    {
        cout << "Test #3...... Passed!" << endl;
    }
    else
    {
        cout << "Test #3...... Failed!" << endl;
    }
    bool test4 = filesAreEqual("../output/part4.tga", "../examples/EXAMPLE_part4.tga");  // test if part4 and example4 are equal
    if(test4)
    {
        cout << "Test #4...... Passed!" << endl;
    }
    else
    {
        cout << "Test #4...... Failed!" << endl;
    }
    bool test5 = filesAreEqual("../output/part5.tga", "../examples/EXAMPLE_part5.tga");  // test if part5 and example5 are equal
    if(test5)
    {
        cout << "Test #5...... Passed!" << endl;
    }
    else
    {
        cout << "Test #5...... Failed!" << endl;
    }
    bool test6 = filesAreEqual("../output/part6.tga", "../examples/EXAMPLE_part6.tga");  // test if part6 and example6 are equal
    if(test6)
    {
        cout << "Test #6...... Passed!" << endl;
    }
    else
    {
        cout << "Test #6...... Failed!" << endl;
    }
    bool test7 = filesAreEqual("../output/part7.tga", "../examples/EXAMPLE_part7.tga");  // test if part7 and example7 are equal
    if(test7)
    {
        cout << "Test #7...... Passed!" << endl;
    }
    else
    {
        cout << "Test #7...... Failed!" << endl;
    }
    bool test8 = filesAreEqual("../output/part8_b.tga", "../examples/EXAMPLE_part8_b.tga");  // test if part8b and example8b are equal
    if(test8)
    {
        cout << "Test #8...... Passed!" << endl;
    }
    else
    {
        cout << "Test #8...... Failed!" << endl;
    }
    bool test9 = filesAreEqual("../output/part8_g.tga", "../examples/EXAMPLE_part8_g.tga");  // test if part8g and example8g are equal
    if(test9)
    {
        cout << "Test #9...... Passed!" << endl;
    }
    else
    {
        cout << "Test #9...... Failed!" << endl;
    }
    bool test10 = filesAreEqual("../output/part8_r.tga", "../examples/EXAMPLE_part8_r.tga");  // test if part8r and example8r are equal
    if(test10)
    {
        cout << "Test #10...... Passed!" << endl;
    }
    else
    {
        cout << "Test #10...... Failed!" << endl;
    }
    bool test11 = filesAreEqual("../output/part9.tga", "../examples/EXAMPLE_part9.tga");  // test if part9 and example9 are equal
    if(test11)
    {
        cout << "Test #11...... Passed!" << endl;
    }
    else
    {
        cout << "Test #11...... Failed!" << endl;
    }
    bool test12 = filesAreEqual("../output/part10.tga", "../examples/EXAMPLE_part10.tga");  // test if part10 and example10 are equal
    if(test12)
    {
        cout << "Test #12...... Passed!" << endl;
    }
    else
    {
        cout << "Test #12...... Failed!" << endl;
    }
    bool test13 = filesAreEqual("../output/extracredit.tga", "../examples/EXAMPLE_extracredit.tga");  // test if extracredit and example_extracredit are equal
    if(test13)
    {
        cout << "Test #13...... Passed!" << endl;
    }
    else
    {
        cout << "Test #13...... Failed!" << endl;
    }

    return 0;
}