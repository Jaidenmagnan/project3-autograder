// Import items for file operations
use std::fs::{File, write};
use std::io::{Result, Read, Seek, SeekFrom};

// The Pixel type makes binary image data more intuitive to work with
#[derive(Clone)]
struct Pixel {
    blue: u8,
    green: u8,
    red: u8,
}

// Implement the Extend trait for Vec<u8> so vectors of Pixel can be concatenated with vectors of u8
// Using lifetimes makes references work
impl<'a> Extend<&'a Pixel> for Vec<u8> {
    fn extend<T: IntoIterator<Item = &'a Pixel>>(&mut self, iter: T) {
        for elem in iter {
            self.push(elem.blue);
            self.push(elem.green);
            self.push(elem.red);
        }
    }
}

/* Takes an image file and returns a vector of Pixel containing the pixel data of that file
 * Parameter: image_file: a mutable reference to a .tga image
 * Returns: An Option which contains a vector of Pixel
 */
fn create_pixel_vector(image_file: &mut File) -> Option<Vec<Pixel>> {
    // Create a vector of u8 called image_data which contains the binary data of the image pixels
    let mut image_data = Vec::new();
    image_file.seek(SeekFrom::Start(18)).ok();
    image_file.read_to_end(&mut image_data).ok();

    // Create a vector of Pixel based on image_data
    let mut image_pixels: Vec<Pixel> = Vec::new();
    for i in (0..image_data.len() - 3).step_by(3) {
        image_pixels.push(
            Pixel {
                blue: image_data[i],
                green: image_data[i + 1],
                red: image_data[i + 2]
            });
    }
    Some(image_pixels)
}

/* Creates image files by combining two vectors image_header and image_pixels
 * Parameters:
 *      image_header: a reference to a vector of u8, contains the 18-byte header to be used in the image file
 *      image_pixels: a reference to a vector of Pixel, contains the pixel data to be used in the image file
 *      file_name: the name of the resulting .tga file
 * Returns: a Result indicating if the operation was successful
 */
fn write_image_file(image_header: &Vec<u8>, image_pixels: &Vec<Pixel>, file_name: &str) -> Result<()> {
    let mut output_image: Vec<u8> = Vec::new();
    output_image.extend(image_header);
    output_image.extend(image_pixels);
    write("output/".to_owned() + file_name + ".tga", output_image)?;
    Ok(())
}

/* Takes an i16 as input and ensures that it is within the value range of u8
 * Parameter: input: an i16 that may be outside the value range of u8
 * Returns: a u8
 */
fn clamp(input: i16) -> u8 {
    if input > u8::MAX as i16 {
        u8::MAX
    } else if input < u8::MIN as i16 {
        u8::MIN
    } else {
        input as u8
    }
}

/* Subtracts top_layer from bottom_layer
 * Parameters:
 *      top_layer: a reference to a vector of Pixel
 *      bottom_layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn subtract_layers(top_layer: &Vec<Pixel>, bottom_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut subtracted_layer = Vec::new();
    for i in 0..bottom_layer.len() {
        subtracted_layer.push(
            Pixel {
                blue: clamp(i16::from(bottom_layer[i].blue) - i16::from(top_layer[i].blue)),
                green: clamp(i16::from(bottom_layer[i].green) - i16::from(top_layer[i].green)),
                red: clamp(i16::from(bottom_layer[i].red) - i16::from(top_layer[i].red))
            });
    }
    subtracted_layer
}

/* Converts values of a 0-255 range to a 0-1 range, thereby normalizing the value
 * Parameter: value: a reference to a u8
 * Returns: an f64
 */
fn normalize(value: &u8) -> f64 {
    f64::from(*value) / f64::from(u8::MAX)
}

/* Multiplies top_layer with bottom_layer
 * Parameters:
 *      top_layer: a reference to a vector of Pixel
 *      bottom_layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn multiply_layers(top_layer: &Vec<Pixel>, bottom_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut multiplied_layer = Vec::new();
    for i in 0..bottom_layer.len() {
        multiplied_layer.push(
            Pixel {
                // Convert each pixel attribute to a floating point value, normalize, multiply, and cast to u8
                blue: (normalize(&bottom_layer[i].blue) * f64::from(top_layer[i].blue) + 0.5) as u8,
                green: (normalize(&bottom_layer[i].green) * f64::from(top_layer[i].green) + 0.5) as u8,
                red: (normalize(&bottom_layer[i].red) * f64::from(top_layer[i].red) + 0.5) as u8
            });
    }
    multiplied_layer
}

/* Screens top_layer with bottom_layer
 * Parameters:
 *      top_layer: a reference to a vector of Pixel
 *      bottom_layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn screen_layers(top_layer: &Vec<Pixel>, bottom_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut screened_layer = Vec::new();
    for i in 0..bottom_layer.len() {
        screened_layer.push(
            Pixel {
                // Convert each pixel attribute to a floating point value, normalize, screen, and cast to u8
                blue: ((1.0 - (1.0 - normalize(&bottom_layer[i].blue)) * (1.0 - normalize(&top_layer[i].blue))) * f64::from(u8::MAX) + 0.5) as u8,
                green: ((1.0 - (1.0 - normalize(&bottom_layer[i].green)) * (1.0 - normalize(&top_layer[i].green))) * f64::from(u8::MAX) + 0.5) as u8,
                red: ((1.0 - (1.0 - normalize(&bottom_layer[i].red)) * (1.0 - normalize(&top_layer[i].red))) * f64::from(u8::MAX) + 0.5) as u8
            });
    }
    screened_layer
}

/* Overlays top_value onto bottom_value
 * Parameters:
 *      top_value: a reference to a u8, represents an individual color channel
 *      bottom_value: a reference to a u8, represents an individual color channel
 * Returns: a u8
 */
fn overlay(top_value: &u8, bottom_value: &u8) -> u8 {
    if bottom_value <= &(u8::MAX / 2) {
        // Multiply and double the values of a color channel if the bottom_layer is less or equal to 0.5
        (2.0 * normalize(top_value) * f64::from(*bottom_value) + 0.5) as u8
    } else {
        // Screen and double the values of a color channel if the bottom_layer is more than 0.5
        ((1.0 - 2.0 * (1.0 - normalize(bottom_value)) * (1.0 - normalize(top_value))) * f64::from(u8::MAX) + 0.5) as u8
    }
}

/* Overlays top_layer onto bottom_layer
 * Parameters:
 *      top_layer: a reference to a vector of Pixel
 *      bottom_layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn overlay_layers(top_layer: &Vec<Pixel>, bottom_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut overlaid_layer = Vec::new();
    for i in 0..bottom_layer.len() {
        overlaid_layer.push(
            Pixel {
                blue: overlay(&top_layer[i].blue, &bottom_layer[i].blue),
                green: overlay(&top_layer[i].green, &bottom_layer[i].green),
                red: overlay(&top_layer[i].red, &bottom_layer[i].red)
            });
    }
    overlaid_layer
}

/* Increases the green channel by 200
 * Parameters:
 *      layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn boost_green(layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut boosted_layer = Vec::new();
    for i in 0..layer.len() {
        boosted_layer.push(
            Pixel {
                blue: layer[i].blue,
                green: clamp(i16::from(layer[i].green) + 200),
                red: layer[i].red
            });
    }
    boosted_layer
}

/* Multiplies the red channel by 4 and the blue channel by zero
 * Parameters:
 *      layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn red_yes_blue_no(layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut altered_layer = Vec::new();
    for i in 0..layer.len() {
        altered_layer.push(
            Pixel {
                blue: 0,
                green: layer[i].green,
                red: clamp(i16::from(layer[i].red) * 4)
            });
    }
    altered_layer
}

/* Splits a single layer into three greyscale layers representing each color channel
 * Parameters:
 *      layer: a reference to a vector of Pixel
 * Returns: a tuple with three elements, each being a vector of Pixel
 */
fn split_layer(layer: &Vec<Pixel>) -> (Vec<Pixel>, Vec<Pixel>, Vec<Pixel>) {
    let mut layer_r = Vec::new();
    let mut layer_g = Vec::new();
    let mut layer_b = Vec::new();
    for i in 0..layer.len() {
        layer_r.push(
            Pixel {
                blue: layer[i].red,
                green: layer[i].red,
                red: layer[i].red
            });
        layer_g.push(
            Pixel {
                blue: layer[i].green,
                green: layer[i].green,
                red: layer[i].green
            });
        layer_b.push(
            Pixel {
                blue: layer[i].blue,
                green: layer[i].blue,
                red: layer[i].blue
            });
    }
    (layer_r, layer_g, layer_b)
}

/* Combines three greyscale layers representing each color channel into a single layer
 * Parameters:
 *      red_layer: a reference to a vector of Pixel
 *      green_layer: a reference to a vector of Pixel
 *      blue_layer: a reference to a vector of Pixel
 * Returns: a vector of Pixel
 */
fn combine_layers(red_layer: &Vec<Pixel>, green_layer: &Vec<Pixel>, blue_layer: &Vec<Pixel>) -> Vec<Pixel> {
    let mut combined_layer = Vec::new();
    for i in 0..red_layer.len() {
        combined_layer.push(
            Pixel {
                blue: blue_layer[i].blue,
                green: green_layer[i].green,
                red: red_layer[i].red
            });
    }
    combined_layer
}

/* Rotates a layer by 180 degrees, thereby flipping it upside-down
 * Parameters:
 *      layer: a reference to a vector of Pixel
 *      fudge_factor: a reference to a usize representing the position of a single pixel that is confoundingly required for proper alignment
 * Returns: a vector of Pixel
 */
fn rotate_180(layer: &Vec<Pixel>, fudge_factor: &usize) -> Vec<Pixel> {
    let mut rotated_layer = Vec::new();
    for i in (1..layer.len()).rev() {
        // Once the fudge_factor pixel is reached, append it to the existing rotated_layer vector
        if i == *fudge_factor {
            rotated_layer.push(
                Pixel {
                    blue: layer[i].blue,
                    green: layer[i].green,
                    red: layer[i].red
                });
        }
        // Append the rest of the Pixel structs normally
        rotated_layer.push(
            Pixel {
                blue: layer[i].blue,
                green: layer[i].green,
                red: layer[i].red
            });
    }
    rotated_layer
}

// IT'S BEAUTIFUL, but sadly it is not the desired output
// Implements the functionality required to combine four images into one (form over function arc)
fn two_by_two(
              bottom_left_layer: &Vec<Pixel>,
              bottom_right_layer: &Vec<Pixel>,
              top_left_layer: &Vec<Pixel>,
              top_right_layer: &Vec<Pixel>,
              layer_dimension: &usize) -> Vec<Pixel> {
    let mut ec_layer = Vec::new();

    for i in 1..*layer_dimension {
        for j in 0..*layer_dimension {
            ec_layer.push(
                Pixel {
                    blue: bottom_left_layer[i * j].blue,
                    green: bottom_left_layer[i * j].green,
                    red: bottom_left_layer[i * j].red
                });
        }
        for j in 0..*layer_dimension {
            ec_layer.push(
                Pixel {
                    blue: bottom_right_layer[i * j].blue,
                    green: bottom_right_layer[i * j].green,
                    red: bottom_right_layer[i * j].red
                });
        }
    }

    for i in 0..*layer_dimension {
        for j in 0..*layer_dimension {
            ec_layer.push(
                Pixel {
                    blue: top_left_layer[i * j].blue,
                    green: top_left_layer[i * j].green,
                    red: top_left_layer[i * j].red
                });
        }
        for j in 0..*layer_dimension {
            ec_layer.push(
                Pixel {
                    blue: top_right_layer[i * j].blue,
                    green: top_right_layer[i * j].green,
                    red: top_right_layer[i * j].red
                });
        }
    }

    ec_layer
}


fn main() -> Result<()> {
    // Create image files
    let mut image_file_l1 = File::open("input/layer1.tga")?;
    let mut image_file_l_red = File::open("input/layer_red.tga")?;
    let mut image_file_txt2 = File::open("input/text2.tga")?;

    // Create vectors containing the binary data of a given image header
    let mut image_header = vec![0u8; 18];
    image_file_l1.read_exact(&mut image_header)?;
    let mut image_header_tri = vec![0u8; 18];
    image_file_l_red.read_exact(&mut image_header_tri)?;
    let mut image_header_txt2 = vec![0u8; 18];
    image_file_txt2.read_exact(&mut image_header_txt2)?;
    println!("Image headers created");

    // Create vectors of Pixel representing the pixel data of the images that were inputted
    let image_pixels_l1 = create_pixel_vector(&mut image_file_l1);
    let image_pixels_l2 = create_pixel_vector(&mut File::open("input/layer2.tga")?);
    let image_pixels_p1 = create_pixel_vector(&mut File::open("input/pattern1.tga")?);
    let image_pixels_p2 = create_pixel_vector(&mut File::open("input/pattern2.tga")?);
    let image_pixels_car = create_pixel_vector(&mut File::open("input/car.tga")?);
    let image_pixels_txt = create_pixel_vector(&mut File::open("input/text.tga")?);
    let image_pixels_cir = create_pixel_vector(&mut File::open("input/circles.tga")?);
    let image_pixels_l_r = create_pixel_vector(&mut image_file_l_red);
    let image_pixels_l_g = create_pixel_vector(&mut File::open("input/layer_green.tga")?);
    let image_pixels_l_b = create_pixel_vector(&mut File::open("input/layer_blue.tga")?);
    let image_pixels_txt2 = create_pixel_vector(&mut image_file_txt2);
    println!("Image pixel vectors created");

    // Create vectors of Pixel representing the pixel data of the images to be outputted
    let image_pixels_a = multiply_layers(&image_pixels_l1.as_ref().unwrap(), &image_pixels_p1.as_ref().unwrap());
    let image_pixels_b = subtract_layers(&image_pixels_l2.as_ref().unwrap(),&image_pixels_car.as_ref().unwrap());
    let image_pixels_c = multiply_layers(&image_pixels_l1.as_ref().unwrap(),&image_pixels_p2.as_ref().unwrap());
    let image_pixels_c = screen_layers(&image_pixels_c.as_ref(), image_pixels_txt.as_ref().unwrap());
    let image_pixels_d = multiply_layers(&image_pixels_l2.as_ref().unwrap(), &image_pixels_cir.as_ref().unwrap());
    let image_pixels_d = subtract_layers(&image_pixels_p2.as_ref().unwrap(), &image_pixels_d.as_ref());
    let image_pixels_e = overlay_layers(&image_pixels_l1.as_ref().unwrap(), &image_pixels_p1.as_ref().unwrap());
    let image_pixels_f = boost_green(&image_pixels_car.as_ref().unwrap());
    let image_pixels_g = red_yes_blue_no(&image_pixels_car.as_ref().unwrap());
    let (image_pixels_h_r, image_pixels_h_g, image_pixels_h_b) = split_layer(&image_pixels_car.as_ref().unwrap());
    let image_pixels_i = combine_layers(&image_pixels_l_r.as_ref().unwrap(), &image_pixels_l_g.as_ref().unwrap(), &image_pixels_l_b.as_ref().unwrap());
    let image_pixels_j = rotate_180(&image_pixels_txt2.as_ref().unwrap(), &70638);
    let image_pixels_ec = two_by_two(
        &image_pixels_txt.as_ref().unwrap(),
        &image_pixels_p1.as_ref().unwrap(),
        &image_pixels_car.as_ref().unwrap(),
        &image_pixels_cir.as_ref().unwrap(), &512usize);
    println!("Image operations complete");

    // Create output image files based on the image_pixels vectors
    write_image_file(&image_header, &image_pixels_a, &"part1")?;
    write_image_file(&image_header, &image_pixels_b, &"part2")?;
    write_image_file(&image_header, &image_pixels_c, &"part3")?;
    write_image_file(&image_header, &image_pixels_d, &"part4")?;
    write_image_file(&image_header, &image_pixels_e, &"part5")?;
    write_image_file(&image_header, &image_pixels_f, &"part6")?;
    write_image_file(&image_header, &image_pixels_g, &"part7")?;
    write_image_file(&image_header, &image_pixels_h_r, &"part8_r")?;
    write_image_file(&image_header, &image_pixels_h_g, &"part8_g")?;
    write_image_file(&image_header, &image_pixels_h_b, &"part8_b")?;
    write_image_file(&image_header_tri, &image_pixels_i, &"part9")?;
    write_image_file(&image_header_txt2, &image_pixels_j, &"part10")?;

    // Modify header dimensions for extracredit.tga
    image_header[13] = 4u8;
    image_header[15] = 4u8;

    // Write extracredit.tga to output/
    write_image_file(&image_header, &image_pixels_ec, &"extracredit")?;
    println!("Success! All files written");

    Ok(())
}
