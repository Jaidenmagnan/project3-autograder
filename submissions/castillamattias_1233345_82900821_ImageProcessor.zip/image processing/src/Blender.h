/*
===================================
Author: Mattias Castilla
Date: 11/14/2023
Descriptions: Image blending mode functions
===================================

ᓚᘏᗢ
*/

#pragma once

#include "Image.h"

/* 
Used to clamp an inputted value between a min and max
Only used for this Blender source so its just here
*/
int clamp(int value, int min, int max);

// Return new image that is top multiplied with bottom
Image* multiply(Image* topLayer, Image* bottomLayer);

// Return new image that is bottom subtracted from top
Image* subtract(Image* topLayer, Image* bottomLayer);

// Return new image using screen blending mode
Image* screen(Image* topLayer, Image* bottomLayer);

// Return new image using overlay blending mode
Image* overlay(Image* topLayer, Image* bottomLayer);

// Return new image adding values to specific channels
Image* addToColorChannel(Image* image, int red, int green, int blue);

// Return new image scaling specific color channels
Image* scaleColorChannel(Image* image, int red, int green, int blue);

// Return new image of just one particular color channel
Image* extractColorChannel(Image* image, Color color);

// Return new image of merged color channel images
Image* mergeImageColorChannels(Image* imageRedChannel, Image* imageGreenChannel, Image* imageBlueChannel);

// Rotate an image by 180 degrees
Image* flip(Image* image);

// Collage images into one large image
Image* collageImages(Image* imageTopLeft, Image* imageTopRight, Image* imageBottomLeft, Image* imageBottomRight);