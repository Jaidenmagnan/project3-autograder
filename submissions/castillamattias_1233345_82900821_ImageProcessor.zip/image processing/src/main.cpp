/*
===================================
Author: Mattias Castilla
Date: 11/14/2023
Descriptions: Main entry point
===================================

ᓚᘏᗢ
*/

#include "./ImageTests.h"


int main(int argc, char** argv){
    
    writeTaskImages();
    runTestCases();

    return 0;
}

