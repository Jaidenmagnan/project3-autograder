/*
===================================
Author: Mattias Castilla
Date: 11/14/2023
Descriptions: Specifically used for testing the program
===================================

ᓚᘏᗢ
*/

#include "ImageTests.h"
#include "Image.h"
#include "Blender.h"

void writeTaskImages(){

    Image* car = loadImage("./input/car.tga");

    Image* circles = loadImage("./input/circles.tga");

    Image* layer_blue = loadImage("./input/layer_blue.tga");
    Image* layer_green = loadImage("./input/layer_green.tga");
    Image* layer_red = loadImage("./input/layer_red.tga");


    Image* layer1 = loadImage("./input/layer1.tga");
    Image* layer2 = loadImage("./input/layer2.tga");
    
    Image* pattern1 = loadImage("./input/pattern1.tga");
    Image* pattern2 = loadImage("./input/pattern2.tga");

    Image* text = loadImage("./input/text.tga");
    Image* text2 = loadImage("./input/text2.tga");
    
    // Task 1
    auto task1 = multiply(pattern1, layer1);
    writeImage(task1, "./output/task1.tga");

    // Task 2
    auto task2 = subtract(layer2, car);
    writeImage(task2, "./output/task2.tga");

    // Task 3
    auto task3 = screen(text, multiply(layer1, pattern2));
    writeImage(task3, "./output/task3.tga");

    // Task 4
    auto task4 = subtract(pattern2, multiply(layer2, circles));
    writeImage(task4, "./output/task4.tga");

    // Task 5
    auto task5 = overlay(layer1, pattern1);
    writeImage(task5, "./output/task5.tga");

    // Task 6
    auto task6 = addToColorChannel(car, 0, 200, 0);
    writeImage(task6, "./output/task6.tga");

    //Task 7
    auto task7 = scaleColorChannel(car, 4, 1, 0);
    writeImage(task7, "./output/task7.tga");

    //Task 8
    // r-channel
    auto rChannel = extractColorChannel(car, RED);
    writeImage(rChannel, "./output/task8_r.tga");
    // g-channel
    auto gChannel = extractColorChannel(car, GREEN);
    writeImage(gChannel, "./output/task8_g.tga");
    // b-channel
    auto bChannel = extractColorChannel(car, BLUE);
    writeImage(bChannel, "./output/task8_b.tga");

    //Task 9
    auto task9 = mergeImageColorChannels(layer_red, layer_green, layer_blue);
    writeImage(task9, "./output/task9.tga");

    //Task 10
    auto task10 = flip(text2);
    writeImage(task10, "./output/task10.tga");

    // Task Extra Credit
    auto taskEC = collageImages(car, circles, text, pattern1);
    writeImage(taskEC, "./output/taskEC.tga");
    
    cout << "Images Written" << "\n";
}


// make comparing the images slightly more neat
bool compareImages(Image* subjectImage, Image* referenceImage){
    if(subjectImage != nullptr && referenceImage != nullptr){
        if((*subjectImage) == referenceImage){
            return true;
        }else return false;
    }else return false;
}

// Returns a vector of tuples containing the image and its test reference
vector<std::tuple<Image*, Image*>>* getTestCaseImages(){
    
    // Where to include produced image and reference image
    string imagePaths[] = {"./output/task1.tga", "./examples/EXAMPLE_part1.tga",
                                "./output/task2.tga", "./examples/EXAMPLE_part2.tga",
                                "./output/task3.tga", "./examples/EXAMPLE_part3.tga",
                                "./output/task4.tga", "./examples/EXAMPLE_part4.tga",
                                "./output/task5.tga", "./examples/EXAMPLE_part5.tga",
                                "./output/task6.tga", "./examples/EXAMPLE_part6.tga",
                                "./output/task7.tga", "./examples/EXAMPLE_part7.tga",
                                "./output/task8_r.tga", "./examples/EXAMPLE_part8_r.tga",
                                "./output/task8_g.tga", "./examples/EXAMPLE_part8_g.tga",
                                "./output/task8_b.tga", "./examples/EXAMPLE_part8_b.tga",
                                "./output/task9.tga", "./examples/EXAMPLE_part9.tga",
                                "./output/task10.tga", "./examples/EXAMPLE_part10.tga",
                                "./output/taskEC.tga", "./examples/EXAMPLE_extracredit.tga"
                                };
    
    auto *images = new vector<std::tuple<Image*, Image*>>(sizeof(imagePaths)/sizeof(imagePaths[0])/2);


    for(int i = 0; i < sizeof(imagePaths)/sizeof(imagePaths[0])/2; i++){
        std::get<0>((*images)[i]) = loadImage(imagePaths[i*2]);
        std::get<1>((*images)[i]) = loadImage(imagePaths[i*2 + 1]);

    }

    return images;

}


void runTestCases(){
    auto images = getTestCaseImages();

    for(int i = 0; i < images->size(); i++){
        bool testResult = compareImages(std::get<0>((*images)[i]), std::get<1>((*images)[i]));

        cout << "Test Case " << i + 1 << " ------ " << (testResult ? "PASSED" : "FAILED") << "\n";
    }

}