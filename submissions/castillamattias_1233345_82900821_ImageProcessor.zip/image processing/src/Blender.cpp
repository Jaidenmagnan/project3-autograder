/*
===================================
Author: Mattias Castilla
Date: 11/14/2023
Descriptions: Blender source
===================================

ᓚᘏᗢ
*/

#include "Blender.h"


int clamp(int value, int min, int max){
    if(value > max){
        return max;
    }else if(value < min){
        return min;
    }else{
        return value;
    }
}

Image* multiply(Image* topLayer, Image* bottomLayer){

    // Catch if any inputted image is null
    if((topLayer == nullptr) || (bottomLayer == nullptr)){
        return nullptr;
    }

    // Check if images are same size
    if((topLayer->getWidth() == bottomLayer->getWidth()) &&  
    ((topLayer->getHeight() == bottomLayer->getHeight()))){
        
        // Initialize dynamic memory for new image's pixel data
        int numPixels = topLayer->getWidth() * topLayer->getHeight();
        vector<Pixel>* data = new vector<Pixel>(numPixels);
        
        Pixel pixel;
        for(int i = 0; i < numPixels; i++){

            /* The pixel data is first casted to an unsigned char because 255 as binary 
            gets converted to -1 instead of 255 without casting it.
            Also scale all color values from 0 to 1
            */
            double redScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].red))/255.0;
            double greenScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].green))/255.0;
            double blueScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].blue))/255.0;

            // 0.5 is added to properly round the number instead of just truncating it
            pixel.red = int(redScaled * double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].red)) + 0.5);
            pixel.green = int(greenScaled * double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].green)) + 0.5);
            pixel.blue = int(blueScaled * double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].blue)) + 0.5);

            (*data)[i] = pixel;
        }


        return new Image(topLayer->getHeader(), data);
    }else{
        return nullptr;
    }


    return nullptr;
}

Image* subtract(Image* topLayer, Image* bottomLayer){
    if((topLayer == nullptr) || (bottomLayer == nullptr)){
        return nullptr;
    }

    if((topLayer->getWidth() == bottomLayer->getWidth()) &&  
    ((topLayer->getHeight() == bottomLayer->getHeight()))){

        int numPixels = topLayer->getWidth() * topLayer->getHeight();
        vector<Pixel>* data = new vector<Pixel>(numPixels);
        
        Pixel pixel;
        for(int i = 0; i < numPixels; i++){

            // Subtract topLayer color channel to bottom layer color channel
            pixel.red = clamp(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].red) - static_cast<unsigned char>((*topLayer->getPixelData())[i].red), 0, 255);
            pixel.green = clamp(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].green) - static_cast<unsigned char>((*topLayer->getPixelData())[i].green), 0, 255);
            pixel.blue = clamp(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].blue) - static_cast<unsigned char>((*topLayer->getPixelData())[i].blue), 0, 255);


            (*data)[i] = pixel;
        }

        return new Image(topLayer->getHeader(), data);

    }else{
        return nullptr;
    }
}

Image* screen(Image* topLayer, Image* bottomLayer){
    if((topLayer == nullptr) || (bottomLayer == nullptr)){
        return nullptr;
    }

    if((topLayer->getWidth() == bottomLayer->getWidth()) &&  
    ((topLayer->getHeight() == bottomLayer->getHeight()))){

        int numPixels = topLayer->getWidth() * topLayer->getHeight();
        vector<Pixel>* data = new vector<Pixel>(numPixels);

        Pixel pixel;
        for(int i = 0; i < numPixels; i++){

            // Scale all color values from 0 to 1
            double redTopScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].red))/255.0;
            double greenTopScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].green))/255.0;
            double blueTopScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].blue))/255.0;

            double redBottomScaled = double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].red))/255.0;
            double greenBottomScaled = double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].green))/255.0;
            double blueBottomScaled = double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].blue))/255.0;

            // Screen formula used is: 1 - (1-Top)*(1-Bottom)
            // Everything is scaled back to 0 - 255 and then 0.5 is added for proper rounding 
            pixel.red = int(((1.0 - (1.0 - redTopScaled)*(1.0 - redBottomScaled)) * 255.0) + 0.5);
            pixel.green = int(((1.0 - (1.0 - greenTopScaled)*(1.0 - greenBottomScaled)) * 255.0) + 0.5);
            pixel.blue = int(((1.0 - (1.0 - blueTopScaled)*(1.0 - blueBottomScaled)) * 255.0) + 0.5);

            (*data)[i] = pixel;
        }

        return new Image(topLayer->getHeader(), data);


    }else{
        return nullptr;
    }
}

Image* overlay(Image* topLayer, Image* bottomLayer){
    if((topLayer == nullptr) || (bottomLayer == nullptr)){
        return nullptr;
    }
    
    if((topLayer->getWidth() == bottomLayer->getWidth()) &&  
    ((topLayer->getHeight() == bottomLayer->getHeight()))){

        int numPixels = topLayer->getWidth() * topLayer->getHeight();
        vector<Pixel>* data = new vector<Pixel>(numPixels);

        Pixel pixel;
        for(int i = 0; i < numPixels; i++){

            // Scale values
            double redTopScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].red))/255.0;
            double greenTopScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].green))/255.0;
            double blueTopScaled = double(static_cast<unsigned char>((*topLayer->getPixelData())[i].blue))/255.0;

            double redBottomScaled = double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].red))/255.0;
            double greenBottomScaled = double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].green))/255.0;
            double blueBottomScaled = double(static_cast<unsigned char>((*bottomLayer->getPixelData())[i].blue))/255.0;

            // Formula for opacity goes
            // bottom <= 0.5: 2*top*bottom
            // bottom > 0.5: 1 - 2*(1-top)*(1-bottom)
            if(redBottomScaled <= 0.5){
                pixel.red = clamp(int((2.0 * redTopScaled * redBottomScaled * 255.0) + 0.5), 0, 255);
            }else{
                pixel.red = clamp(int(((1.0 - (2.0 * (1.0 - redTopScaled)*(1.0 - redBottomScaled))) * 255.0) + 0.5), 0, 255);
            }

            if(greenBottomScaled <= 0.5){
                pixel.green = clamp(int((2.0 * greenTopScaled * greenBottomScaled * 255.0) + 0.5), 0, 255);
            }else{
                pixel.green = clamp(int(((1.0 - (2.0 * (1.0 - greenTopScaled)*(1.0 - greenBottomScaled))) * 255.0) + 0.5), 0, 255);
            }

            if(blueBottomScaled <= 0.5){
                pixel.blue = clamp(int((2.0 * blueTopScaled * blueBottomScaled * 255.0) + 0.5), 0, 255);
            }else{
                pixel.blue = clamp(int(((1.0 - (2.0 * (1.0 - blueTopScaled)*(1.0 - blueBottomScaled))) * 255.0) + 0.5), 0, 255);
            }

            (*data)[i] = pixel;
        }

        return new Image(topLayer->getHeader(), data);

    }else{
        return nullptr;
    }
}

Image* addToColorChannel(Image* image, int red, int green, int blue){
    if(image == nullptr){
        return nullptr;
    }

    int numPixels = image->getWidth() * image->getHeight();
    vector<Pixel>* data = new vector<Pixel>(numPixels);

    Pixel pixel;
    for(int i = 0; i < numPixels; i++){

            // Adds specified amount to specific channel and clamps it in range from 0 to 255
            pixel.red = clamp(int(static_cast<unsigned char>((*image->getPixelData())[i].red) + red + 0.5), 0, 255);
            pixel.green = clamp(int(static_cast<unsigned char>((*image->getPixelData())[i].green) + green + 0.5), 0, 255);
            pixel.blue = clamp(int(static_cast<unsigned char>((*image->getPixelData())[i].blue) + blue + 0.5), 0, 255);


        (*data)[i] = pixel;
    }

    return new Image(image->getHeader(), data);
}

Image* scaleColorChannel(Image* image, int red, int green, int blue){
    if(image == nullptr){
        return nullptr;
    }

    int numPixels = image->getWidth() * image->getHeight();
    vector<Pixel>* data = new vector<Pixel>(numPixels);

    Pixel pixel;
    for(int i = 0; i < numPixels; i++){

            // Scales specific channel and clamps it in range frm 0 to 255
            pixel.red = clamp(int((static_cast<unsigned char>((*image->getPixelData())[i].red) * red) + 0.5), 0, 255);
            pixel.green = clamp(int((static_cast<unsigned char>((*image->getPixelData())[i].green) * green) + 0.5), 0, 255);
            pixel.blue = clamp((int(static_cast<unsigned char>((*image->getPixelData())[i].blue) * blue) + 0.5), 0, 255);


        (*data)[i] = pixel;
    }


    return new Image(image->getHeader(), data);
}

Image* extractColorChannel(Image* image, Color color){
    if(image == nullptr){
        return nullptr;
    }

    int numPixels = image->getWidth() * image->getHeight();
    vector<Pixel>* data = new vector<Pixel>(numPixels);
    
    Pixel pixel;
    for(int i = 0; i < numPixels; i++){

        // Will get value from specific color channel and 
        // assign that value to each color channel of new image
        switch(color){
            case RED:
                pixel.red = (*image->getPixelData())[i].red;
                pixel.green = (*image->getPixelData())[i].red;
                pixel.blue = (*image->getPixelData())[i].red;
                break;
            case GREEN:
                pixel.red = (*image->getPixelData())[i].green;
                pixel.green = (*image->getPixelData())[i].green;
                pixel.blue = (*image->getPixelData())[i].green;
                break;
            case BLUE:
                pixel.red = (*image->getPixelData())[i].blue;
                pixel.green = (*image->getPixelData())[i].blue;
                pixel.blue = (*image->getPixelData())[i].blue;
                break;
            default:
                pixel.red = 0; 
                pixel.green = 0;
                pixel.blue = 0;
        }

        (*data)[i] = pixel;
    }
    return new Image(image->getHeader(), data);
}

Image* mergeImageColorChannels(Image* imageRedChannel, Image* imageGreenChannel, Image* imageBlueChannel){

    if((imageRedChannel == nullptr) || (imageGreenChannel == nullptr) || (imageBlueChannel == nullptr)){
        return nullptr;
    }

    if((imageRedChannel->getWidth() == imageGreenChannel->getWidth()) && (imageRedChannel->getWidth() == imageGreenChannel->getWidth()) &&
        (imageRedChannel->getHeight() == imageGreenChannel->getHeight()) && (imageRedChannel->getHeight() == imageGreenChannel->getHeight())){

        int numPixels = imageRedChannel->getWidth() * imageRedChannel->getHeight();
        vector<Pixel>* data = new vector<Pixel>(numPixels);
        
        Pixel pixel;
        for(int i = 0; i < numPixels; i++){

            // Will merge the three images based on what color channel they represent
            pixel.red = (*imageRedChannel->getPixelData())[i].red;
            pixel.green = (*imageGreenChannel->getPixelData())[i].green;
            pixel.blue = (*imageBlueChannel->getPixelData())[i].blue;



            (*data)[i] = pixel;
        }

        return new Image(imageRedChannel->getHeader(), data);

    }else{
        return nullptr;
    }
}


Image* flip(Image* image){

    if(image == nullptr){
        return nullptr;
    }

    int numPixels = image->getWidth() * image->getHeight();
    vector<Pixel>* data = new vector<Pixel>(numPixels);

    // Flips image 180 by writing the data in reverse from reading
    for(int i = 0; i < numPixels; i++){
        (*data)[(numPixels - 1) - i] = (*image->getPixelData())[i];
    }

    return new Image(image->getHeader(), data);

}

Image* collageImages(Image* imageTopLeft, Image* imageTopRight, Image* imageBottomLeft, Image* imageBottomRight){
    if((imageTopLeft == nullptr) || (imageTopRight == nullptr) || (imageBottomLeft == nullptr) || (imageBottomRight == nullptr)){
        return nullptr;
    }

    if ((imageTopLeft->getWidth() == imageTopRight->getWidth()) &&
        (imageTopLeft->getWidth() == imageBottomLeft->getWidth()) &&
        (imageTopLeft->getWidth() == imageBottomRight->getWidth()) &&
        (imageTopLeft->getHeight() == imageTopRight->getHeight()) &&
        (imageTopLeft->getHeight() == imageBottomLeft->getHeight()) &&
        (imageTopLeft->getHeight() == imageBottomRight->getHeight())) {

        // Create a new header with the same properties as one of the images
        //      except for the dimensions. 
        Header* header = new Header;
        header->idLength = imageTopLeft->getHeader()->idLength;
        header->colorMapType = imageTopLeft->getHeader()->colorMapType;
        header->dataTypeCode = imageTopLeft->getHeader()->dataTypeCode;
        header->colorMapOrigin = imageTopLeft->getHeader()->colorMapOrigin;
        header->colorMapLength = imageTopLeft->getHeader()->colorMapLength;
        header->colorMapDepth = imageTopLeft->getHeader()->colorMapDepth;
        header->xOrigin = imageTopLeft->getHeader()->xOrigin;
        header->yOrigin = imageTopLeft->getHeader()->yOrigin;

        header->width = imageTopLeft->getHeader()->width * 2;
        header->height = imageTopLeft->getHeader()->height * 2;      
        
        header->bitsPerPixel = imageTopLeft->getHeader()->bitsPerPixel;
        header->imageDescriptor = imageTopLeft->getHeader()->imageDescriptor;

        int numPixels = header->width * header->height;
        vector<Pixel>* data = new vector<Pixel>(numPixels);
        
        Pixel pixel;
        for(int row = 0; row < numPixels; row += header->width){

            for(int column = 0; column < header->width; column++){

                // Set image to its respective boundary of the new image
                if(column < header->width/2 && row < numPixels/2){
                    // bottom left corner
                    pixel.red = (*imageBottomLeft->getPixelData())[column + row/2].red;
                    pixel.green = (*imageBottomLeft->getPixelData())[column + row/2].green;
                    pixel.blue = (*imageBottomLeft->getPixelData())[column + row/2].blue;
                }else if(column >= header->width/2 && row < numPixels/2){
                    // bottom right corner
                    pixel.red = (*imageBottomRight->getPixelData())[(column - header->width/2) + row/2].red;
                    pixel.green = (*imageBottomRight->getPixelData())[(column - header->width/2) + row/2].green;
                    pixel.blue = (*imageBottomRight->getPixelData())[(column - header->width/2) + row/2].blue;                
                }else if(column < header->width/2 && row >= numPixels/2){
                    // top left corner
                    pixel.red = (*imageTopLeft->getPixelData())[column + (row - numPixels/2)/2].red;
                    pixel.green = (*imageTopLeft->getPixelData())[column + (row - numPixels/2)/2].green;
                    pixel.blue = (*imageTopLeft->getPixelData())[column + (row - numPixels/2)/2].blue;  
                }else if(column >= header->width/2 && row >= numPixels/2){
                    // top right corner
                    pixel.red = (*imageTopRight->getPixelData())[(column - header->width/2) + (row - numPixels/2)/2].red;
                    pixel.green = (*imageTopRight->getPixelData())[(column - header->width/2) + (row - numPixels/2)/2].green;
                    pixel.blue = (*imageTopRight->getPixelData())[(column - header->width/2) + (row - numPixels/2)/2].blue;  
                }

                (*data)[row + column] = pixel;
            }
        }

        return new Image(header, data);
            
    }else return nullptr;
}