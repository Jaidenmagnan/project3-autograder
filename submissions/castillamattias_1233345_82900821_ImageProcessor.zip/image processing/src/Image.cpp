/*
===================================
Author: Mattias Castilla
Date: 11/14/2023
Descriptions: Image source
===================================

ᓚᘏᗢ
*/

#include "Image.h"

Image::Image(Header* const header, vector<Pixel>* const data) : header(header), data(data){}

short Image::getWidth() const{
    return this->header->width;
}

short Image::getHeight() const{
    return this->header->height;
}

Header* Image::getHeader() const{
    return this->header;
}

vector<Pixel>* Image::getPixelData() const{
    return this->data;
}

Image* const loadImage(string filePath){
    std::ifstream file(filePath, std::ios_base::binary);

    // Instantiate the header for the image
    Header* header = new Header;

    if (!file.is_open()) {
        cerr << "Failed to open the file. --> " << filePath << "\n";
        return nullptr;
    }

    // Read the header info into the header object
    // reinterpret_cast is used to treat the pointer to the header as a pointer to a char 
    if (!file.read(reinterpret_cast<char*>(header), sizeof(*header))) {
        cerr << "Failed to read the header. --> " << filePath << "\n";
        return nullptr;
    }

    // Create the vector containing the pixel data after getting info from header
    int numPixels = header->width * header->height;
    vector<Pixel>* data = new vector<Pixel>(numPixels);    

    for (int i = 0; i < numPixels; i++) {
        Pixel pixel;
        // Read pixel data into pixel object 
        file.read(reinterpret_cast<char*>(&pixel), sizeof(pixel));

        if (!file) {
            cerr << "Failed to read pixel data. --> " << filePath << "\n";
            return nullptr;
        }

        (*data)[i] = (pixel);
    }

    file.close();
    // return a pointer to the image object 
    return new Image(header, data);
}

void writeImage(const Image* image, string filePath){
    
    std::filesystem::path directoryPath = std::filesystem::path(filePath).parent_path();

    // If the output directory does not exist then make one
    if (!std::filesystem::exists(directoryPath)) {
        if (!std::filesystem::create_directories(directoryPath)) {
            std::cerr << "Failed to create the directory: " << directoryPath.string() << "\n";
            return;
        }
    }

    std::ofstream file(filePath, std::ios::binary);

    // Attempt to open file
    if (!file.is_open()) {
        cerr << "Failed to open the TGA file for writing\nCheck if ./output directory exists!. --> " << filePath << "\n";
        return;
    }

    // First write header
    file.write(reinterpret_cast<char*>(image->getHeader()), sizeof(Header));

    // Write data
    vector<Pixel>& pixels = *(image->getPixelData());
    file.write(reinterpret_cast<char*>(pixels.data()), sizeof(Pixel) * pixels.size());

    file.close();
}

// Overriding == operator used specifically for testing purposes
// Prints out what is not equal 
bool Image::operator==(Image* imageB) const{
    if(this->header->idLength != imageB->header->idLength){
        cout << "idlength do not match" << "\n";
        return false;
    }else if(this->header->colorMapType != imageB->header->colorMapType){
        cout << "colorMapType do not match" << "\n";
        return false;
    }else if(this->header->dataTypeCode != imageB->header->dataTypeCode){
        cout << "dataTypeCode do not match" << "\n";
        return false;
    }else if(this->header->colorMapOrigin != imageB->header->colorMapOrigin){
        cout << "colorMapOrigin do not match" << "\n";
        return false;
    }else if(this->header->colorMapLength != imageB->header->colorMapLength){
        cout << "colorMapLength do not match" << "\n";
        return false;
    }else if(this->header->colorMapDepth != imageB->header->colorMapDepth){
        cout << "colorMapDepth do not match" << "\n";
        return false;
    }else if(this->header->xOrigin != imageB->header->xOrigin){
        cout << "xOrigin do not match" << "\n";
        return false;
    }else if(this->header->yOrigin != imageB->header->yOrigin){
        cout << "yOrigin do not match" << "\n";
        return false;
    }else if(this->header->width != imageB->header->width){
        cout << "width do not match" << "\n";
        return false;
    }else if(this->header->height != imageB->header->height){
        cout << "height do not match" << "\n";
        return false;
    }else if(this->header->bitsPerPixel != imageB->header->bitsPerPixel){
        cout << "bitsPerPixel do not match" << "\n";
        return false;
    }else if(this->header->imageDescriptor != imageB->header->imageDescriptor){
        cout << "imageDescriptor do not match" << "\n";
        return false;
    }

    int numPixelsA = (this->header->height * this->header->width);
    int numPixelsB = (imageB->header->height * imageB->header->width);

    if(numPixelsA != numPixelsB){
        cout << "num pixels do not match" << "\n";
        return false;
    }

    for(int i = 0; i < numPixelsA; i++){
        Pixel pixelA = (*this->getPixelData())[i];
        Pixel pixelB = (*imageB->getPixelData())[i];

        if(pixelA.red != pixelB.red){
            cout << "--------------------------------------------" << "\n";
            cout << "\tRed Index: " << i << "\n";

            cout << "\tRed A Value: " << int(static_cast<unsigned char>(pixelA.red)) << "\n";
            cout << "\tRed B Value: " << int(static_cast<unsigned char>(pixelB.red)) << "\n";
            cout << "--------------------------------------------" << "\n";
            
            return false;
        }else if(pixelA.green != pixelB.green){
            cout << "--------------------------------------------" << "\n";
            cout << "\tGreen Index: " << i << "\n";
            
            cout << "\tGreen A Value: " << int(static_cast<unsigned char>(pixelA.green)) << "\n";
            cout << "\tGreen B Value: " << int(static_cast<unsigned char>(pixelB.green)) << "\n";
            cout << "--------------------------------------------" << "\n";
            return false;
        }else if(pixelA.blue != pixelB.blue){
            cout << "--------------------------------------------" << "\n";
            cout << "\tBlue Index: " << i << "\n";

            cout << "\tBlue A Value: " << int(static_cast<unsigned char>(pixelA.blue)) << "\n";
            cout << "\tBlue B Value: " << int(static_cast<unsigned char>(pixelB.blue)) << "\n";
            cout << "--------------------------------------------" << "\n";
            return false;
        }
    }

    return true;
}