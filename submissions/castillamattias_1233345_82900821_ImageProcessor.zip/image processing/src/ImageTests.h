#pragma once

#include "Image.h"
#include <tuple>

void writeTaskImages();

bool compareImages(Image* subjectImage, Image* referenceImage);

std::vector<std::tuple<Image*, Image*>>* getTestCaseImages();

void runTestCases();