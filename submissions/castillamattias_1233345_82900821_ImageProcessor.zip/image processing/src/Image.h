/*
===================================
Author: Mattias Castilla
Date: 11/14/2023
Descriptions: Image class and image properties header
                used throughout the program
===================================

ᓚᘏᗢ
*/

#pragma once

#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <filesystem>

using std::vector, std::string, std::fstream, std::iostream, std::cout, std::cerr;

// Enum used for making some functions for blender more readable 
enum Color{
    RED,
    GREEN,
    BLUE
};

/* 
Pixel data is arranged in blue, green, red order for TGA file format and 
    as such matches order here for loading. 
*For some reason this struct doesn't need the added attribute and 
    is exactly 3 bytes in size unlike the header (。_。).
*/
struct Pixel{
    char blue;
    char green;
    char red;
};

/*
This had some weird behavior
Without __attribute__((packed)) the size of the struct 
    comes out to 20 bytes instead of 18 for the header.
    __attribute__((packed)) removes the 2 byte padding added by the 
    compiler so that the data is properly aligned. 
    
    **__attribute__((packed)) is specifically for GCC. If this is being compiled with Visual Studio
        then #pragma pack(push, 1)  is needed before the struct and #pragma pack(pop) is needed after the struct
            #pragma pack(push, 1) 
            // struct
            #pragma pack(pop)
        
Matches order of data in header for TGA file format
*/
struct __attribute__((packed)) Header{
        char idLength;
        char colorMapType;
        char dataTypeCode;
        short colorMapOrigin;
        short colorMapLength;
        char colorMapDepth;
        short xOrigin;
        short yOrigin;
        short width;
        short height;
        char bitsPerPixel;
        char imageDescriptor;
};

// Image class used to load image files into
// Has a header object and list of Pixel objects
class Image{
    private:
        Header* const header;
        vector<Pixel>* const data;

    public:
        Image(Header* const header, vector<Pixel>* const data);
        ~Image();

        short getWidth() const;
        short getHeight() const;


        Header* getHeader() const;

        vector<Pixel>* getPixelData() const;

        // Overriding solely for testing against the example images
        bool operator==(Image* imageB) const;

};

// Return an image from the specified path
Image* const loadImage(string filePath);

// Write image to specified path
void writeImage(const Image* image, string filePath);

